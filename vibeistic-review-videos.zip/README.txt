VIBEISTIC – Instagram & YouTube video on review pages

1. GitHub Desktop → Fetch origin → Pull origin.
2. Replace these files in your project:
     src/content.config.ts
     src/pages/review/[slug].astro
3. Open src/styles/global.css and paste ADD-TO-END-OF-global.css at the very end.
4. Add the two editor fields from public/admin/ADD-THESE-FIELDS.yml into public/admin/config.yml
   (do NOT replace config.yml – your repo line must stay).
5. Check for stray asterisks:  grep -n '\*\*' src/pages/review/[slug].astro src/content.config.ts
   Only the 3 lines with "**/*.md" and the \*\* in the quick-answer code are expected.
6. npm run build → Commit → Push origin.
7. In /admin open a review → paste the Instagram Reel link and YouTube Short link → Save.
