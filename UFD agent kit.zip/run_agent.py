"""Background agent: collects trends and prepares drafts. It NEVER posts by itself.
Stop it any time with Ctrl+C."""
import os, time, traceback
from dotenv import load_dotenv
from agent import collector, pipeline, db

load_dotenv()
DRAFTS_PER_RUN = int(os.getenv("DRAFTS_PER_RUN", "3"))
MIN_SCORE = float(os.getenv("MIN_SCORE", "30"))


def cycle():
    print(time.strftime("\n[%H:%M:%S] Checking sources..."))
    collector.collect()
    if db.get_setting("paused") == "1":
        print("⏸️ Agent paused from dashboard, no drafts made.")
        return
    made = 0
    for s in collector.top_stories(limit=15, only_undrafted=True):
        if made >= DRAFTS_PER_RUN or s["score"] < MIN_SCORE:
            break
        try:
            did = pipeline.make_draft(s["title"], s["summary"], s["source"], story_id=s["id"])
            print(f"📝 Draft #{did}: {s['title'][:70]} (score {s['score']})")
            made += 1
        except Exception as e:
            print("⚠️ Draft failed:", e)
    print(f"Done: {made} new drafts.")


if __name__ == "__main__":
    minutes = int(collector.load_sources().get("poll_minutes", 10))
    print(f"🌍 UFD agent started. Checking every {minutes} min. Press Ctrl+C to stop.")
    while True:
        try:
            cycle()
        except KeyboardInterrupt:
            break
        except Exception:
            traceback.print_exc()
        try:
            time.sleep(minutes * 60)
        except KeyboardInterrupt:
            break
    print("👋 Agent stopped.")
