# UFD Duniya Agent

Start the dashboard:   cd ~/ufd-agent && source venv/bin/activate && streamlit run dashboard.py
Start the agent:       (new Terminal tab) cd ~/ufd-agent && source venv/bin/activate && python run_agent.py
Stop either one:       Ctrl + C

The agent only creates DRAFTS. Nothing is posted until you click "Approve & Post".

.env settings used:
  IG_POSTING_ENABLED=false   -> true to allow posting from the dashboard
  IG_DAILY_LIMIT=3           -> max API posts per day
  DRAFTS_PER_RUN=3           -> drafts the agent makes every cycle
  MIN_SCORE=30               -> only stories at or above this score get auto-drafted
  OLLAMA_MODEL=llama3.2:3b

Logo: put your logo as assets/logo.png (transparent PNG, ~400x120). Without it a yellow "UFD" badge is used.
Sources: edit config/sources.yaml
