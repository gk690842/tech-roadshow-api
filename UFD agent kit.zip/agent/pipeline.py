"""Story -> AI text -> branded image -> saved draft."""
from . import writer, renderer, db, notifier


def make_draft(title, summary, source, story_id=None, bg_path=None, notify=True):
    d = writer.write(title, summary, source)
    img = renderer.render(d, bg_path=bg_path)
    did = db.add_draft(story_id, d["template"], d, img)
    if story_id:
        c = db.conn()
        c.execute("UPDATE stories SET drafted=1 WHERE id=?", (story_id,))
        c.commit()
    if notify:
        notifier.send_photo(img, f"📝 New UFD draft #{did}\n{d['headline']}\n\nOpen the dashboard to approve.")
    return did
