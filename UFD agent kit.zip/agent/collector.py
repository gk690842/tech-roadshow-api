"""Feature 2: monitor trending sources (RSS + Google Trends + YouTube) and score stories."""
import os, re, time, hashlib, json, yaml, requests, feedparser
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from dotenv import load_dotenv
from . import db

load_dotenv()
ROOT = os.path.join(os.path.dirname(__file__), "..")
UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"}
STOP = set("the a an of to in on for and is are was with by at from as after over new says said will this that be its it".split())


def load_sources():
    with open(os.path.join(ROOT, "config", "sources.yaml")) as f:
        return yaml.safe_load(f)


def clean(text):
    text = re.sub(r"<[^>]+>", " ", text or "")
    return re.sub(r"\s+", " ", text).strip()


def story_key(title):
    """Same story from different sources -> same key (first 6 meaningful words, sorted)."""
    words = [w for w in re.findall(r"[a-z0-9]+", title.lower()) if w not in STOP and len(w) > 2]
    return hashlib.md5(" ".join(sorted(words[:6])).encode()).hexdigest()


def parse_time(entry):
    for k in ("published", "updated"):
        if entry.get(k):
            try:
                return parsedate_to_datetime(entry[k]).astimezone(timezone.utc)
            except Exception:
                pass
    return datetime.now(timezone.utc)


def fetch_rss(url):
    r = requests.get(url, headers=UA, timeout=20)
    feed = feedparser.parse(r.content)
    name = clean(feed.feed.get("title", url))[:40]
    items = []
    for e in feed.entries[:25]:
        title = clean(e.get("title", ""))
        title = re.sub(r"\s+-\s+[^-]{2,40}$", "", title)  # strip " - Publisher" from Google News
        if not title:
            continue
        items.append({"title": title, "summary": clean(e.get("summary", ""))[:600],
                      "link": e.get("link", ""), "source": name, "published": parse_time(e)})
    return items


def fetch_youtube(region="IN"):
    key = os.getenv("YOUTUBE_API_KEY")
    if not key:
        return []
    r = requests.get("https://www.googleapis.com/youtube/v3/videos", timeout=20, params={
        "part": "snippet", "chart": "mostPopular", "regionCode": region, "maxResults": 20, "key": key}).json()
    out = []
    for v in r.get("items", []):
        s = v["snippet"]
        out.append({"title": s["title"], "summary": clean(s.get("description", ""))[:600],
                    "link": f"https://youtu.be/{v['id']}", "source": "YouTube Trending",
                    "published": datetime.fromisoformat(s["publishedAt"].replace("Z", "+00:00"))})
    return out


def score(published, n_sources):
    age_min = max((datetime.now(timezone.utc) - published).total_seconds() / 60, 1)
    freshness = max(0.0, 1 - age_min / 360)          # 0 after 6 hours
    return round(freshness * 50 + (n_sources - 1) * 25, 1)


def collect(log=print):
    cfg = load_sources()
    items = []
    for url in cfg.get("rss", []):
        try:
            items += fetch_rss(url)
        except Exception as e:
            log(f"⚠️ {url[:50]}: {e}")
        time.sleep(1)
    try:
        items += fetch_youtube(cfg.get("youtube_trending_region", "IN"))
    except Exception as e:
        log(f"⚠️ YouTube: {e}")

    c = db.conn()
    new = 0
    for it in items:
        k = story_key(it["title"])
        row = c.execute("SELECT * FROM stories WHERE key=?", (k,)).fetchone()
        if row:
            srcs = set(json.loads(row["sources"]))
            if it["source"] not in srcs:
                srcs.add(it["source"])
                pub = datetime.fromisoformat(row["published"])
                c.execute("UPDATE stories SET sources=?, seen_count=?, score=? WHERE id=?",
                          (json.dumps(list(srcs)), len(srcs), score(pub, len(srcs)), row["id"]))
        else:
            c.execute("""INSERT INTO stories(key,title,summary,link,source,published,first_seen,sources,score)
                         VALUES(?,?,?,?,?,?,?,?,?)""",
                      (k, it["title"], it["summary"], it["link"], it["source"], it["published"].isoformat(),
                       db.now(), json.dumps([it["source"]]), score(it["published"], 1)))
            new += 1
    c.commit()
    log(f"✅ Collected {len(items)} items, {new} new stories")
    return new


def top_stories(limit=30, only_undrafted=False):
    """Re-score on read so freshness decays over time."""
    q = "SELECT * FROM stories " + ("WHERE drafted=0 " if only_undrafted else "") + \
        "ORDER BY id DESC LIMIT 500"
    rows = [dict(r) for r in db.conn().execute(q).fetchall()]
    for r in rows:
        r["score"] = score(datetime.fromisoformat(r["published"]), r["seen_count"])
    rows.sort(key=lambda r: r["score"], reverse=True)
    return rows[:limit]
