"""Sends draft previews to your phone via Telegram."""
import os, requests
from dotenv import load_dotenv

load_dotenv()


def send_photo(path, text):
    tok, chat = os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if not tok or not chat:
        return
    try:
        with open(path, "rb") as f:
            requests.post(f"https://api.telegram.org/bot{tok}/sendPhoto", timeout=30,
                          data={"chat_id": chat, "caption": text[:1000]}, files={"photo": f})
    except Exception as e:
        print("Telegram error:", e)


def send_text(text):
    tok, chat = os.getenv("TELEGRAM_BOT_TOKEN"), os.getenv("TELEGRAM_CHAT_ID")
    if tok and chat:
        try:
            requests.post(f"https://api.telegram.org/bot{tok}/sendMessage", timeout=30,
                          data={"chat_id": chat, "text": text[:4000]})
        except Exception as e:
            print("Telegram error:", e)
