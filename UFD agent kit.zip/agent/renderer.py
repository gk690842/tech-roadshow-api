"""Fills the HTML templates and saves a 1080x1350 JPEG with the UFD branding."""
import os, base64, mimetypes
from datetime import datetime
from jinja2 import Environment, FileSystemLoader
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TPL = os.path.join(ROOT, "templates")
env = Environment(loader=FileSystemLoader(TPL), autoescape=True)


def data_uri(path):
    if not path or not os.path.exists(path):
        return ""
    mime = mimetypes.guess_type(path)[0] or "image/png"
    return f"data:{mime};base64," + base64.b64encode(open(path, "rb").read()).decode()


def _logo():
    for name in ("logo.png", "logo.jpg", "logo.jpeg"):
        p = os.path.join(ROOT, "assets", name)
        if os.path.exists(p):
            return data_uri(p)
    return ""


def render(d, bg_path=None, out_dir=None):
    """d = writer output. Returns the path of the JPEG."""
    tpl = d.get("template", "news")
    head = d.get("headline", "")
    ctx = dict(d, css=open(os.path.join(TPL, "base.css")).read(), logo=_logo(), bg=data_uri(bg_path),
               hsize=110 if len(head) < 30 else 92 if len(head) < 50 else 78,
               fsize=58 if len(d.get("subtext", "")) < 90 else 48)
    html = env.get_template(f"{tpl}.html").render(**ctx)

    out_dir = out_dir or os.path.join(ROOT, "drafts", datetime.now().strftime("%Y-%m-%d"))
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, f"{tpl}_{datetime.now().strftime('%H%M%S%f')}.jpg")
    exe = os.getenv("UFD_CHROMIUM_PATH")  # normally empty
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=exe) if exe else p.chromium.launch()
        page = b.new_page(viewport={"width": 1080, "height": 1350})
        page.set_content(html, wait_until="load")
        page.screenshot(path=out, type="jpeg", quality=92, full_page=False)
        b.close()
    return out
