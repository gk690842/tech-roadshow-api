"""SQLite storage for stories, drafts and posting history."""
import sqlite3, os, json
from datetime import datetime, timezone

DB = os.path.join(os.path.dirname(__file__), "..", "data", "ufd.db")


def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c = sqlite3.connect(DB, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.executescript("""
    CREATE TABLE IF NOT EXISTS stories(
        id INTEGER PRIMARY KEY, key TEXT UNIQUE, title TEXT, summary TEXT, link TEXT,
        source TEXT, published TEXT, first_seen TEXT, seen_count INTEGER DEFAULT 1,
        sources TEXT DEFAULT '[]', score REAL DEFAULT 0, drafted INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS drafts(
        id INTEGER PRIMARY KEY, story_id INTEGER, created TEXT, template TEXT,
        data TEXT, image TEXT, status TEXT DEFAULT 'pending', ig_id TEXT, note TEXT);
    CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
    """)
    return c


def now():
    return datetime.now(timezone.utc).isoformat()


def get_setting(k, default=None):
    r = conn().execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
    return r["v"] if r else default


def set_setting(k, v):
    c = conn()
    c.execute("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", (k, str(v)))
    c.commit()


def add_draft(story_id, template, data, image):
    c = conn()
    cur = c.execute("INSERT INTO drafts(story_id,created,template,data,image) VALUES(?,?,?,?,?)",
                    (story_id, now(), template, json.dumps(data, ensure_ascii=False), image))
    c.commit()
    return cur.lastrowid


def drafts(status):
    rows = conn().execute("SELECT * FROM drafts WHERE status=? ORDER BY id DESC", (status,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["data"] = json.loads(d["data"])
        out.append(d)
    return out


def update_draft(did, **kw):
    c = conn()
    for k, v in kw.items():
        if k == "data":
            v = json.dumps(v, ensure_ascii=False)
        c.execute(f"UPDATE drafts SET {k}=? WHERE id=?", (v, did))
    c.commit()


def posted_today():
    today = datetime.now(timezone.utc).date().isoformat()
    return conn().execute("SELECT COUNT(*) n FROM drafts WHERE status='posted' AND note LIKE ?",
                          (today + "%",)).fetchone()["n"]
