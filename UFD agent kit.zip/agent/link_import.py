"""Feature 1: paste any link -> extract title + text (never re-uses the original media)."""
import json, subprocess, requests, trafilatura
from urllib.parse import urlparse

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"}
VIDEO_SITES = ("youtube.com", "youtu.be", "instagram.com", "x.com", "twitter.com", "facebook.com", "reddit.com")


def extract(url):
    host = urlparse(url).netloc.lower().replace("www.", "")
    if any(host.endswith(s) for s in VIDEO_SITES):
        try:
            out = subprocess.run(["yt-dlp", "--dump-json", "--skip-download", "--no-warnings", url],
                                 capture_output=True, text=True, timeout=60)
            if out.returncode == 0 and out.stdout.strip():
                j = json.loads(out.stdout.splitlines()[0])
                return {"title": j.get("title") or j.get("description", "")[:100],
                        "summary": (j.get("description") or "")[:1500],
                        "source": j.get("uploader") or j.get("extractor_key") or host}
        except Exception:
            pass
    html = requests.get(url, headers=UA, timeout=30).text
    meta = trafilatura.extract_metadata(html)
    text = trafilatura.extract(html) or ""
    title = (meta.title if meta and meta.title else "") or text[:100]
    site = (meta.sitename if meta and meta.sitename else "") or host
    if not title and not text:
        raise RuntimeError("Could not read this link. Paste the text manually in the box below.")
    return {"title": title, "summary": text[:1500], "source": site}
