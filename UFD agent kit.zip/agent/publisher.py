"""Uploads the image to Cloudflare R2 and publishes it to Instagram, with safety limits."""
import os, time, requests, boto3
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
from . import db

load_dotenv()
E = os.getenv


def limits_ok():
    if E("IG_POSTING_ENABLED", "false").lower() != "true":
        return False, "Instagram posting is OFF (IG_POSTING_ENABLED=false in .env)"
    if db.get_setting("paused") == "1":
        return False, "Posting is paused from the dashboard"
    until = db.get_setting("blocked_until")
    if until and datetime.fromisoformat(until) > datetime.now(timezone.utc):
        return False, f"Auto-paused after a Meta error until {until[:16]} UTC"
    cap = int(E("IG_DAILY_LIMIT", "3"))
    if db.posted_today() >= cap:
        return False, f"Daily limit reached ({cap} posts). Change IG_DAILY_LIMIT in .env"
    return True, "OK"


def upload_r2(path):
    s3 = boto3.client("s3", endpoint_url=f"https://{E('R2_ACCOUNT_ID')}.r2.cloudflarestorage.com",
                      aws_access_key_id=E("R2_ACCESS_KEY"), aws_secret_access_key=E("R2_SECRET_KEY"),
                      region_name="auto")
    key = "posts/" + os.path.basename(path)
    s3.upload_file(path, E("R2_BUCKET"), key, ExtraArgs={"ContentType": "image/jpeg"})
    return f"{E('R2_PUBLIC_URL').rstrip('/')}/{key}"


def _check(r):
    if "error" in r:
        db.set_setting("blocked_until", (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat())
        raise RuntimeError("Meta error, posting paused for 24h: " + r["error"].get("message", str(r)))
    return r


def publish_image(path, caption):
    ok, why = limits_ok()
    if not ok:
        raise RuntimeError(why)
    host = E("IG_GRAPH_HOST", "https://graph.facebook.com/v25.0")
    uid, tok = E("IG_USER_ID"), E("IG_ACCESS_TOKEN")
    url = upload_r2(path)
    c = _check(requests.post(f"{host}/{uid}/media", timeout=60,
                             data={"image_url": url, "caption": caption[:2200], "access_token": tok}).json())
    cid = c["id"]
    for _ in range(24):
        s = requests.get(f"{host}/{cid}", params={"fields": "status_code", "access_token": tok}, timeout=30).json()
        if s.get("status_code") == "FINISHED":
            break
        if s.get("status_code") == "ERROR":
            raise RuntimeError(f"Instagram could not process the image: {s}")
        time.sleep(5)
    r = _check(requests.post(f"{host}/{uid}/media_publish", timeout=60,
                             data={"creation_id": cid, "access_token": tok}).json())
    return r["id"]
