"""UFD Duniya approval dashboard.  Run:  streamlit run dashboard.py"""
import os
from datetime import datetime, timezone
import streamlit as st
from dotenv import load_dotenv
from agent import db, collector, pipeline, renderer, writer, publisher, link_import, images

load_dotenv()
st.set_page_config(page_title="UFD Duniya Dashboard", page_icon="🌍", layout="wide")
ROOT = os.path.dirname(os.path.abspath(__file__))
UP = os.path.join(ROOT, "drafts", "uploads")
os.makedirs(UP, exist_ok=True)


def save_upload(f):
    if not f:
        return None
    p = os.path.join(UP, datetime.now().strftime("%H%M%S_") + f.name)
    with open(p, "wb") as out:
        out.write(f.getbuffer())
    return p


# ---------- header ----------
ok, why = publisher.limits_ok()
c1, c2, c3, c4 = st.columns([3, 2, 2, 2])
c1.title("🌍 UFD Duniya")
c2.metric("Pending drafts", len(db.drafts("pending")))
c3.metric("Posted today", f"{db.posted_today()} / {os.getenv('IG_DAILY_LIMIT', '3')}")
paused = db.get_setting("paused") == "1"
if c4.button("▶️ Resume agent" if paused else "⏸️ Pause agent", use_container_width=True):
    db.set_setting("paused", "0" if paused else "1")
    st.rerun()
photo_on = bool(os.getenv("PIXABAY_API_KEY") or os.getenv("PEXELS_API_KEY"))
st.caption(("🟢 Instagram posting ON" if ok else f"🔴 {why}") + (" · ⏸️ Agent paused" if paused else "")
           + (" · 🖼️ Auto photos ON (Pixabay + Openverse)" if photo_on else " · 🖼️ Auto photos: Openverse only (add PIXABAY_API_KEY for better photos)"))

tab_d, tab_l, tab_t, tab_p = st.tabs(["📝 Drafts", "➕ Create from Link", "🔥 Live Trends", "📤 Posted / Ready"])

# ---------- drafts ----------
with tab_d:
    items = db.drafts("pending")
    if not items:
        st.info("No drafts yet. Start the agent (python run_agent.py), pick a story in 🔥 Live Trends, or paste a link.")
    for d in items:
        data, did = d["data"], d["id"]
        with st.container(border=True):
            left, right = st.columns([2, 3])
            if os.path.exists(d["image"]):
                left.image(d["image"], use_container_width=True)
            if data.get("photo_credit"):
                left.caption("🖼️ " + data["photo_credit"])
            with right:
                st.subheader(f"#{did} · {data.get('headline', '')}")
                t = st.selectbox("Template", ["news", "fact", "meme"], key=f"t{did}",
                                 index=["news", "fact", "meme"].index(d["template"]))
                h = st.text_input("Headline", data.get("headline", ""), key=f"h{did}")
                if t == "meme":
                    tt = st.text_input("Top text", data.get("top_text", ""), key=f"tt{did}")
                    bt = st.text_input("Bottom text", data.get("bottom_text", ""), key=f"bt{did}")
                else:
                    tt, bt = data.get("top_text", ""), data.get("bottom_text", "")
                sub = st.text_area("Sub text", data.get("subtext", ""), key=f"s{did}", height=80)
                cap = st.text_area("Caption", data.get("caption", ""), key=f"c{did}", height=120)
                tags = st.text_input("Hashtags", " ".join(data.get("hashtags", [])), key=f"g{did}")
                src = st.text_input("Source credit", data.get("source", ""), key=f"src{did}")

                new = dict(data, template=t, headline=h, top_text=tt, bottom_text=bt, subtext=sub,
                           caption=cap, hashtags=tags.split(), source=src)

                st.markdown("**🖼️ Background photo**")
                bg = st.file_uploader("Upload your own photo (then click 💾 Save & re-render)",
                                      type=["jpg", "jpeg", "png"], key=f"bg{did}")
                up = save_upload(bg)
                if up:
                    new["bg"], new["photo_credit"] = up, ""
                pq = st.text_input("Photo search words (edit if the photo doesn't match)",
                                   data.get("photo_query") or images.keywords(h), key=f"pq{did}")
                p1, p2 = st.columns(2)
                if p1.button("🔄 Next photo", key=f"fp{did}"):
                    idx = int(data.get("photo_index", -1)) + 1 if pq == data.get("photo_query") else 0
                    with st.spinner("Searching free photos..."):
                        path, credit = images.find_photo(pq, idx)
                    if path:
                        new["bg"], new["photo_credit"] = path, credit
                        new["photo_query"], new["photo_index"] = pq, idx
                        db.update_draft(did, data=new, template=t, image=renderer.render(new, bg_path=path))
                        st.rerun()
                    else:
                        st.warning("No photo found. Try simpler search words (e.g. 'rain city'), or upload your own.")
                if p2.button("🚫 Remove photo", key=f"rp{did}"):
                    new.pop("bg", None)
                    new.pop("photo_credit", None)
                    db.update_draft(did, data=new, template=t, image=renderer.render(new))
                    st.rerun()

                b1, b2, b3, b4, b5 = st.columns(5)
                if b1.button("💾 Save & re-render", key=f"r{did}"):
                    db.update_draft(did, data=new, template=t, image=renderer.render(new, bg_path=new.get("bg")))
                    st.rerun()
                if b2.button("🔄 Rewrite with AI", key=f"w{did}"):
                    with st.spinner("AI rewriting..."):
                        nd = writer.write(h, sub + " " + cap, src.replace("Source: ", ""))
                        for k in ("bg", "photo_credit"):
                            if new.get(k):
                                nd[k] = new[k]
                        db.update_draft(did, data=nd, template=nd["template"],
                                        image=renderer.render(nd, bg_path=nd.get("bg")))
                    st.rerun()
                if b3.button("✅ Approve & Post", key=f"a{did}", type="primary", disabled=not ok):
                    try:
                        with st.spinner("Posting to Instagram..."):
                            img = d["image"]
                            if new != data:
                                img = renderer.render(new, bg_path=new.get("bg"))
                                db.update_draft(did, data=new, template=t, image=img)
                            ig = publisher.publish_image(img, writer.full_caption(new))
                        db.update_draft(did, data=new, status="posted", ig_id=ig,
                                        note=datetime.now(timezone.utc).isoformat())
                        st.success(f"Posted ✅ (id {ig})")
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))
                if b4.button("📥 Ready (post manually)", key=f"m{did}"):
                    if new != data:
                        db.update_draft(did, data=new, template=t,
                                        image=renderer.render(new, bg_path=new.get("bg")))
                    db.update_draft(did, data=new, status="ready")
                    st.rerun()
                if b5.button("❌ Reject", key=f"x{did}"):
                    db.update_draft(did, status="rejected")
                    st.rerun()

# ---------- create from link ----------
with tab_l:
    st.write("Paste a news / YouTube / Instagram / X link. The AI rewrites it in UFD style. "
             "The original photo or video is **not** reused; a free Pixabay/Openverse photo is added instead.")
    url = st.text_input("Link")
    manual = st.text_area("…or paste the story text yourself (optional)", height=120)
    bg = st.file_uploader("Optional: your own background photo", type=["jpg", "jpeg", "png"], key="linkbg")
    if st.button("✨ Create draft", type="primary"):
        if not url.strip() and not manual.strip():
            st.warning("Paste a link or some text first.")
        else:
            try:
                with st.spinner("Reading link and writing draft (≈30–90 sec)..."):
                    if manual.strip():
                        info = {"title": manual.strip()[:120], "summary": manual, "source": url or ""}
                    else:
                        info = link_import.extract(url.strip())
                    did = pipeline.make_draft(info["title"], info["summary"], info["source"],
                                              bg_path=save_upload(bg), notify=False)
                st.success(f"Draft #{did} created. Open the 📝 Drafts tab.")
            except Exception as e:
                st.error(str(e))

# ---------- trends ----------
with tab_t:
    a, b = st.columns([1, 4])
    if a.button("🔄 Refresh now"):
        with st.spinner("Checking all sources..."):
            collector.collect(log=st.write)
    b.caption("Score = freshness + how many sources carry the same story. Higher = more viral.")
    for s in collector.top_stories(limit=40):
        x, y, z = st.columns([1, 7, 2])
        x.metric("Score", s["score"])
        y.markdown(f"**{s['title']}**  \n{s['source']} · seen in {s['seen_count']} source(s) · [open]({s['link']})")
        if s["drafted"]:
            z.write("✔️ drafted")
        elif z.button("📝 Make draft", key=f"md{s['id']}"):
            with st.spinner("Writing draft..."):
                pipeline.make_draft(s["title"], s["summary"], s["source"], story_id=s["id"], notify=False)
            st.success("Draft created → 📝 Drafts tab")

# ---------- posted / ready ----------
with tab_p:
    st.subheader("📥 Ready to post manually")
    for d in db.drafts("ready"):
        with st.container(border=True):
            l, r = st.columns([1, 3])
            l.image(d["image"], use_container_width=True)
            with open(d["image"], "rb") as f:
                l.download_button("⬇️ Download image", f, file_name=os.path.basename(d["image"]), key=f"dl{d['id']}")
            r.code(writer.full_caption(d["data"]), language=None)
            if r.button("Mark as posted", key=f"mp{d['id']}"):
                db.update_draft(d["id"], status="posted_manual", note=datetime.now(timezone.utc).isoformat())
                st.rerun()
    st.subheader("📤 Posted")
    for d in db.drafts("posted") + db.drafts("posted_manual"):
        st.write(f"#{d['id']} · {d['data'].get('headline', '')} · {d['note'][:16] if d['note'] else ''} "
                 f"· {'API' if d['status'] == 'posted' else 'manual'}")
