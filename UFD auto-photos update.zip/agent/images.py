"""Automatic, copyright-safe background photos for drafts.
Order: Pixabay (free key, commercial use OK) -> Openverse (no key needed, credit added)
-> Pexels (only if you already have an old key).
The news site's own photo is never used (copyright)."""
import os, re, hashlib, requests
from dotenv import load_dotenv

load_dotenv()
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CACHE = os.path.join(ROOT, "drafts", "photos")
UA = {"User-Agent": "ufd-agent/1.0 (personal Instagram page tool)"}
STOP = set("the a an of to in on for and is are was with by at from as after over new says said will this "
           "that be its it how why what who when your you our has have had into about more than just".split())


def keywords(text, n=3):
    words = [w for w in re.findall(r"[A-Za-z]+", text or "") if w.lower() not in STOP and len(w) > 3]
    return " ".join(words[:n]) or "world news"


def _pixabay(q):
    key = os.getenv("PIXABAY_API_KEY")
    if not key:
        return []
    r = requests.get("https://pixabay.com/api/", timeout=20, params={
        "key": key, "q": q[:100], "image_type": "photo", "orientation": "vertical",
        "safesearch": "true", "per_page": 10})
    if r.status_code != 200:
        return []
    return [(h["largeImageURL"], f"Photo: {h.get('user', 'Pixabay')} / Pixabay") for h in r.json().get("hits", [])]


def _openverse(q):
    r = requests.get("https://api.openverse.org/v1/images/", headers=UA, timeout=20, params={
        "q": q[:100], "license_type": "commercial,modification", "mature": "false", "page_size": 10})
    if r.status_code != 200:
        return []
    out = []
    for h in r.json().get("results", []):
        lic = f"CC {(h.get('license') or '').upper()}".strip()
        out.append((h["url"], f"Photo: {h.get('creator') or 'Unknown'} / {h.get('source') or 'Openverse'} ({lic})"))
    return out


def _pexels(q):
    key = os.getenv("PEXELS_API_KEY")
    if not key:
        return []
    r = requests.get("https://api.pexels.com/v1/search", headers={"Authorization": key}, timeout=20,
                     params={"query": q, "per_page": 10, "orientation": "portrait"})
    if r.status_code != 200:
        return []
    return [(p["src"]["large"], f"Photo: {p['photographer']} / Pexels") for p in r.json().get("photos", [])]


def candidates(text):
    q = keywords(text)
    out = []
    for query in (q, " ".join(q.split()[:2]), q.split()[0]):
        for fn in (_pixabay, _openverse, _pexels):
            try:
                out += fn(query)
            except Exception as e:
                print("Photo search error:", e)
        if len(out) >= 5:
            break
    seen, uniq = set(), []
    for u, c in out:
        if u not in seen:
            seen.add(u)
            uniq.append((u, c))
    return uniq


def _download(url):
    os.makedirs(CACHE, exist_ok=True)
    p = os.path.join(CACHE, hashlib.md5(url.encode()).hexdigest() + ".jpg")
    if not os.path.exists(p):
        r = requests.get(url, headers=UA, timeout=30)
        r.raise_for_status()
        if not r.headers.get("Content-Type", "image").startswith("image"):
            raise ValueError("not an image")
        open(p, "wb").write(r.content)
    return p


def find_photo(text, index=0):
    """Returns (path, credit) for result number `index` (wraps around), or (None, '')."""
    cands = candidates(text)
    for i in range(len(cands)):
        url, credit = cands[(index + i) % len(cands)]
        try:
            return _download(url), credit
        except Exception:
            continue
    return None, ""
