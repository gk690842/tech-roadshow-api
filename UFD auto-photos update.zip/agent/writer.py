"""Local AI (Ollama) turns a story into headline, caption and hashtags."""
import os, json, re, ollama
from dotenv import load_dotenv

load_dotenv()
MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")

PROMPT = """You write posts for the Indian Instagram page UFD Duniya (@ufdduniya), tagline "The world, unfiltered".
Rewrite the story below in YOUR OWN words. Never copy sentences. Stay factual, do not invent details.
Tone: witty, simple English with a light Hinglish touch. No abuse, no politics bashing, no religion jokes.

Pick ONE template:
- "news" for real news/incidents
- "fact" for surprising facts or science
- "meme" only if the story is clearly funny

Return ONLY valid JSON with exactly these keys:
{{"template": "news|fact|meme",
 "headline": "max 8 words, punchy",
 "subtext": "max 25 words, the key detail",
 "top_text": "meme top line, max 8 words (empty if not meme)",
 "bottom_text": "meme punchline, max 8 words (empty if not meme)",
 "emoji": "one emoji",
 "caption": "3-5 short lines explaining the story, end with: Follow @ufdduniya for more 🌍",
 "hashtags": ["12 to 15 relevant hashtags without spaces, include #ufdduniya"]}}

STORY TITLE: {title}
STORY DETAILS: {summary}
SOURCE: {source}"""


def _fix(d, title, source):
    d.setdefault("template", "news")
    if d["template"] not in ("news", "fact", "meme"):
        d["template"] = "news"
    d.setdefault("headline", title[:60])
    for k in ("subtext", "top_text", "bottom_text", "caption"):
        d[k] = str(d.get(k) or "")
    d["emoji"] = str(d.get("emoji") or "🌍")[:4]
    tags = d.get("hashtags") or []
    if isinstance(tags, str):
        tags = tags.split()
    tags = ["#" + re.sub(r"[^\w]", "", t.lstrip("#")) for t in tags if t.strip()]
    if "#ufdduniya" not in [t.lower() for t in tags]:
        tags.insert(0, "#ufdduniya")
    d["hashtags"] = tags[:20]
    d["source"] = f"Source: {source}" if source else ""
    return d


def write(title, summary="", source=""):
    msg = PROMPT.format(title=title, summary=summary[:1500], source=source)
    last_err = None
    for _ in range(2):
        try:
            r = ollama.chat(model=MODEL, format="json", options={"temperature": 0.7},
                            messages=[{"role": "user", "content": msg}])
            return _fix(json.loads(r["message"]["content"]), title, source)
        except Exception as e:
            last_err = e
    raise RuntimeError(f"AI writer failed: {last_err}")


def full_caption(d):
    credits = "\n".join(x for x in (d.get("source", ""), d.get("photo_credit", "")) if x)
    return f"{d['caption'].strip()}\n\n{credits}\n.\n{' '.join(d['hashtags'])}".strip()
