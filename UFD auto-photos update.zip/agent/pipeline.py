"""Story -> AI text -> free background photo -> branded image -> saved draft."""
import os
from . import writer, renderer, db, notifier, images


def make_draft(title, summary, source, story_id=None, bg_path=None, notify=True):
    d = writer.write(title, summary, source)
    if bg_path:
        d["bg"], d["photo_credit"] = bg_path, ""
    elif os.getenv("AUTO_PHOTOS", "true").lower() == "true":
        q = images.keywords(d.get("headline", "") + " " + title)
        path, credit = images.find_photo(q)
        if path:
            d["bg"], d["photo_credit"] = path, credit
            d["photo_query"], d["photo_index"] = q, 0
    img = renderer.render(d, bg_path=d.get("bg"))
    did = db.add_draft(story_id, d["template"], d, img)
    if story_id:
        c = db.conn()
        c.execute("UPDATE stories SET drafted=1 WHERE id=?", (story_id,))
        c.commit()
    if notify:
        notifier.send_photo(img, f"📝 New UFD draft #{did}\n{d['headline']}\n\nOpen the dashboard to approve.")
    return did
