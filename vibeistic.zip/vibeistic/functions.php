<?php
/**
 * Vibeistic theme functions.
 *
 * @package Vibeistic
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'VB_VERSION', '1.0.0' );

/* -------------------------------------------------------------
 * 1. THE SIX PILLARS (edit labels, factors, icons and colours here)
 * ----------------------------------------------------------- */
function vb_pillars() {
	return array(
		'eat'    => array( 'name' => 'Eat',    'hi' => 'Khao',    'icon' => '🍛', 'sub' => 'Restaurants, thalis & street food', 'factors' => array( 'Taste', 'Value', 'Hygiene' ),         'color' => '#f2994a', 'bg' => '#f2994a,#ff5e7e' ),
		'sip'    => array( 'name' => 'Sip',    'hi' => 'Piyo',    'icon' => '☕', 'sub' => 'Cafés, chai & juice bars',          'factors' => array( 'Brew', 'Vibe', 'Value' ),               'color' => '#ff5e7e', 'bg' => '#ff5e7e,#ffb238' ),
		'travel' => array( 'name' => 'Travel', 'hi' => 'Ghoomo',  'icon' => '🧭', 'sub' => 'Places, getaways & treks',          'factors' => array( 'Experience', 'Access', 'Value' ),       'color' => '#e09b14', 'bg' => '#ffb238,#f2994a' ),
		'pray'   => array( 'name' => 'Pray',   'hi' => 'Darshan', 'icon' => '🛕', 'sub' => 'Temples & sacred places',           'factors' => array( 'Darshan', 'Cleanliness', 'Calm' ),     'color' => '#5b2a86', 'bg' => '#5b2a86,#c9407a' ),
		'play'   => array( 'name' => 'Play',   'hi' => 'Khelo',   'icon' => '⚽', 'sub' => 'Gyms, turfs & sports',              'factors' => array( 'Facilities', 'Crowd', 'Value' ),       'color' => '#2e9e6b', 'bg' => '#2e9e6b,#8fd18a' ),
		'stay'   => array( 'name' => 'Stay',   'hi' => 'Raho',    'icon' => '🏨', 'sub' => 'Hotels & homestays',                'factors' => array( 'Room', 'Location', 'Value' ),          'color' => '#1f6fb2', 'bg' => '#1f6fb2,#5b2a86' ),
	);
}

/** Pillar config for a review (slug + term + data). */
function vb_place_pillar( $post_id ) {
	$all   = vb_pillars();
	$terms = get_the_terms( $post_id, 'vb_pillar' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			if ( isset( $all[ $t->slug ] ) ) {
				return array_merge( array( 'slug' => $t->slug, 'term' => $t ), $all[ $t->slug ] );
			}
		}
	}
	return array( 'slug' => '', 'term' => null, 'name' => 'Place', 'hi' => '', 'icon' => '📍', 'sub' => '', 'factors' => array( 'Score 1', 'Score 2', 'Score 3' ), 'color' => '#625b70', 'bg' => '#625b70,#9a93a8' );
}

/** Link to a pillar archive (or empty string). */
function vb_pillar_link( $slug ) {
	$t = get_term_by( 'slug', $slug, 'vb_pillar' );
	return $t ? get_term_link( $t ) : '';
}

/* -------------------------------------------------------------
 * 2. THEME SETUP
 * ----------------------------------------------------------- */
add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'vibeistic', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 280, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'vibeistic' ),
		'footer'  => __( 'Footer – About Links', 'vibeistic' ),
	) );
	add_image_size( 'vb-card', 600, 400, true );
	add_image_size( 'vb-hero', 1280, 720, true );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'vb-fonts', 'https://fonts.googleapis.com/css2?family=Caveat:wght@700&family=Poppins:wght@400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'vb-style', get_stylesheet_uri(), array( 'vb-fonts' ), VB_VERSION );
	wp_enqueue_script( 'vb-main', get_template_directory_uri() . '/assets/main.js', array(), VB_VERSION, true );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
} );

/** Preconnect to Google Fonts for faster mobile loading. */
add_filter( 'wp_resource_hints', function ( $urls, $type ) {
	if ( 'preconnect' === $type ) {
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $urls;
}, 10, 2 );

/** Mobile browser bar colour + favicon fallback (when no Site Icon is set). */
add_action( 'wp_head', function () {
	echo '<meta name="theme-color" content="#5b2a86">' . "\n";
	if ( ! has_site_icon() ) {
		$b = get_template_directory_uri() . '/assets/brand/';
		echo '<link rel="icon" href="' . esc_url( $b . 'favicon.svg' ) . '" type="image/svg+xml">' . "\n";
		echo '<link rel="icon" href="' . esc_url( $b . 'icon-32.png' ) . '" sizes="32x32">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( $b . 'icon-192.png' ) . '">' . "\n";
	}
}, 2 );

/** Inline brand logo (icon + wordmark). Used when no Custom Logo is uploaded. */
function vb_brand( $tag = 'a' ) {
	$icon = '<svg viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="vbg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b2a86"/><stop offset="1" stop-color="#ff5e7e"/></linearGradient></defs>'
		. '<path d="M52 112C52 112 14 74 14 48a38 38 0 0 1 76 0c0 26-38 64-38 64z" fill="url(#vbg)"/>'
		. '<circle cx="52" cy="48" r="19" fill="#fff"/><circle cx="52" cy="48" r="10.5" fill="#ffb238"/>'
		. '<path d="M78 14a32 32 0 0 1 25 25M76 26a20 20 0 0 1 14 14" fill="none" stroke="#ffb238" stroke-width="8" stroke-linecap="round"/></svg>';
	$word = '<span class="word"><span class="w1">vibe</span><span class="w2">istic</span></span>';
	if ( 'a' === $tag ) {
		return '<a href="' . esc_url( home_url( '/' ) ) . '" class="brand" aria-label="' . esc_attr( get_bloginfo( 'name' ) ) . ' – home">' . $icon . $word . '</a>';
	}
	return '<span class="brand">' . $icon . $word . '</span>';
}

/* -------------------------------------------------------------
 * 3. REVIEWS POST TYPE + PILLAR / AREA TAXONOMIES
 * ----------------------------------------------------------- */
function vb_register_types() {
	register_post_type( 'place', array(
		'labels'        => array(
			'name' => 'Reviews', 'singular_name' => 'Review', 'add_new' => 'Add Review', 'add_new_item' => 'Add New Review',
			'edit_item' => 'Edit Review', 'all_items' => 'All Reviews', 'menu_name' => 'Reviews', 'search_items' => 'Search Reviews',
		),
		'public'        => true,
		'has_archive'   => 'reviews',
		'rewrite'       => array( 'slug' => 'review', 'with_front' => false ),
		'menu_icon'     => 'dashicons-location-alt',
		'menu_position' => 5,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments', 'author', 'revisions' ),
		'show_in_rest'  => true,
	) );

	register_taxonomy( 'vb_pillar', 'place', array(
		'labels'            => array( 'name' => 'Pillars', 'singular_name' => 'Pillar', 'menu_name' => 'Pillars (Eat, Sip…)' ),
		'hierarchical'      => true,
		'public'            => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'explore', 'with_front' => false ),
		'query_var'         => 'vb_pillar',
	) );

	register_taxonomy( 'vb_area', 'place', array(
		'labels'            => array( 'name' => 'Areas / Stations', 'singular_name' => 'Area', 'add_new_item' => 'Add New Area' ),
		'hierarchical'      => true,
		'public'            => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'area', 'with_front' => false ),
		'query_var'         => 'vb_area',
	) );
}
add_action( 'init', 'vb_register_types' );

function vb_ensure_pillars() {
	foreach ( vb_pillars() as $slug => $p ) {
		if ( ! term_exists( $slug, 'vb_pillar' ) ) {
			wp_insert_term( $p['name'], 'vb_pillar', array( 'slug' => $slug, 'description' => $p['sub'] ) );
		}
	}
}

/** On activation: create the six pillars and refresh URLs. */
add_action( 'after_switch_theme', function () {
	vb_register_types();
	vb_ensure_pillars();
	flush_rewrite_rules();
} );

/* -------------------------------------------------------------
 * 4. REVIEW DETAILS META BOX
 * ----------------------------------------------------------- */
function vb_meta_fields() {
	return array(
		'badge'   => 'Badge (e.g. Work-friendly, 24×7, Unlimited thali)',
		'price'   => 'Price (e.g. ₹600 for two, ₹2,000 / month, Free entry)',
		'verdict' => 'One-line verdict',
		'address' => 'Address (used for the map)',
		'station' => 'Nearest station + walk time',
		'timings' => 'Timings',
		'bestfor' => 'Best for',
	);
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'vb_details', 'Review Details & Scores', 'vb_render_meta_box', 'place', 'normal', 'high' );
} );

function vb_render_meta_box( $post ) {
	wp_nonce_field( 'vb_save', 'vb_nonce' );
	echo '<style>.vb-mb label{display:block;font-weight:600;margin:10px 0 3px}.vb-mb input{width:100%}.vb-sc{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.vb-help{background:#f6f2fb;padding:8px 10px;border-radius:6px;margin-top:14px}</style><div class="vb-mb">';
	foreach ( vb_meta_fields() as $key => $label ) {
		printf( '<label for="vb_%1$s">%2$s</label><input type="text" id="vb_%1$s" name="vb_%1$s" value="%3$s">',
			esc_attr( $key ), esc_html( $label ), esc_attr( get_post_meta( $post->ID, '_vb_' . $key, true ) ) );
	}
	echo '<p class="vb-help"><strong>Scores (0–10).</strong> Factor names follow the Pillar you pick: ';
	$parts = array();
	foreach ( vb_pillars() as $p ) { $parts[] = esc_html( $p['name'] . ' = ' . implode( ' / ', $p['factors'] ) ); }
	echo implode( ' · ', $parts ) . '</p><div class="vb-sc">';
	for ( $i = 1; $i <= 3; $i++ ) {
		printf( '<div><label for="vb_f%1$d">Factor %1$d</label><input type="number" min="0" max="10" step="0.1" id="vb_f%1$d" name="vb_f%1$d" value="%2$s"></div>',
			$i, esc_attr( get_post_meta( $post->ID, '_vb_f' . $i, true ) ) );
	}
	echo '</div></div>';
}

add_action( 'save_post_place', function ( $post_id ) {
	if ( ! isset( $_POST['vb_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vb_nonce'] ) ), 'vb_save' ) ) { return; }
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
	foreach ( array_keys( vb_meta_fields() ) as $key ) {
		if ( isset( $_POST[ 'vb_' . $key ] ) ) {
			update_post_meta( $post_id, '_vb_' . $key, sanitize_text_field( wp_unslash( $_POST[ 'vb_' . $key ] ) ) );
		}
	}
	for ( $i = 1; $i <= 3; $i++ ) {
		if ( ! isset( $_POST[ 'vb_f' . $i ] ) ) { continue; }
		$raw = sanitize_text_field( wp_unslash( $_POST[ 'vb_f' . $i ] ) );
		if ( '' === $raw ) {
			delete_post_meta( $post_id, '_vb_f' . $i );
		} else {
			update_post_meta( $post_id, '_vb_f' . $i, min( 10, max( 0, round( (float) $raw, 1 ) ) ) );
		}
	}
	vb_update_score( $post_id );
} );

/** Overall score = average of the factors entered. Stored for sorting. */
function vb_update_score( $post_id ) {
	$vals = array();
	for ( $i = 1; $i <= 3; $i++ ) {
		$v = get_post_meta( $post_id, '_vb_f' . $i, true );
		if ( '' !== $v ) { $vals[] = (float) $v; }
	}
	$score = $vals ? round( array_sum( $vals ) / count( $vals ), 1 ) : 0;
	update_post_meta( $post_id, '_vb_score', $score );
	return $score;
}

function vb_score( $post_id ) {
	$s = get_post_meta( $post_id, '_vb_score', true );
	return '' === $s ? vb_update_score( $post_id ) : (float) $s;
}

/** Make sure every review has a score key (so sorting never hides it). */
add_action( 'wp_insert_post', function ( $post_id, $post ) {
	if ( 'place' === $post->post_type && '' === get_post_meta( $post_id, '_vb_score', true ) ) {
		update_post_meta( $post_id, '_vb_score', 0 );
	}
}, 10, 2 );

/* -------------------------------------------------------------
 * 5. QUERIES: archives sorted by score
 * ----------------------------------------------------------- */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) { return; }
	if ( $q->is_post_type_archive( 'place' ) || $q->is_tax( array( 'vb_pillar', 'vb_area' ) ) ) {
		$q->set( 'posts_per_page', 12 );
		$q->set( 'meta_key', '_vb_score' );
		$q->set( 'orderby', array( 'meta_value_num' => 'DESC', 'date' => 'DESC' ) );
	}
	if ( $q->is_search() && 'place' === $q->get( 'post_type' ) ) {
		$q->set( 'posts_per_page', 12 );
	}
} );

/** Hero search with only an area chosen → go straight to that area page. */
add_action( 'template_redirect', function () {
	if ( isset( $_GET['vb_hero'] ) && '' === trim( (string) get_query_var( 's' ) ) ) {
		$area = isset( $_GET['vb_area'] ) ? sanitize_title( wp_unslash( $_GET['vb_area'] ) ) : '';
		$term = $area ? get_term_by( 'slug', $area, 'vb_area' ) : false;
		wp_safe_redirect( $term ? get_term_link( $term ) : get_post_type_archive_link( 'place' ) );
		exit;
	}
} );

/* -------------------------------------------------------------
 * 6. READER RATINGS (1–5 stars on comments)
 * ----------------------------------------------------------- */
add_filter( 'comment_form_defaults', function ( $d ) {
	if ( is_singular( 'place' ) ) {
		$d['title_reply']   = 'Been here? Rate it';
		$d['label_submit']  = 'Submit review';
		$d['comment_notes_before'] = '<p style="font-size:13px;color:var(--muted)">Reviews are checked before they appear. Your email is never shown.</p>';
		$d['comment_field'] = '<p><label for="vb_rating">Your rating *</label><select id="vb_rating" name="vb_rating" required>'
			. '<option value="">Select…</option><option value="5">★★★★★ Excellent</option><option value="4">★★★★ Good</option>'
			. '<option value="3">★★★ Average</option><option value="2">★★ Poor</option><option value="1">★ Bad</option></select></p>'
			. '<p><label for="comment">Your experience *</label><textarea id="comment" name="comment" rows="5" required minlength="30" placeholder="What did you try, how was the wait, would you go again?"></textarea></p>';
	}
	return $d;
} );

/** Require a rating on review pages. */
add_filter( 'preprocess_comment', function ( $data ) {
	if ( isset( $data['comment_post_ID'] ) && 'place' === get_post_type( $data['comment_post_ID'] ) && in_array( $data['comment_type'] ?? '', array( '', 'comment' ), true ) && ! is_admin() ) {
		$r = isset( $_POST['vb_rating'] ) ? (int) $_POST['vb_rating'] : 0;
		if ( ( $r < 1 || $r > 5 ) && empty( $data['comment_parent'] ) ) {
			wp_die( esc_html__( 'Please choose a star rating before submitting your review.', 'vibeistic' ), '', array( 'back_link' => true ) );
		}
	}
	return $data;
} );

add_action( 'comment_post', function ( $comment_id ) {
	if ( isset( $_POST['vb_rating'] ) ) {
		$r = (int) $_POST['vb_rating'];
		if ( $r >= 1 && $r <= 5 ) { add_comment_meta( $comment_id, 'vb_rating', $r ); }
	}
} );

function vb_stars( $n ) {
	$n = max( 0, min( 5, (int) $n ) );
	return '<span class="stars" aria-label="' . esc_attr( $n ) . ' out of 5">' . str_repeat( '★', $n ) . str_repeat( '☆', 5 - $n ) . '</span>';
}

function vb_comment_cb( $comment, $args, $depth ) {
	$rating = get_comment_meta( $comment->comment_ID, 'vb_rating', true ); ?>
	<li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
		<div class="comment-meta"><b><?php comment_author(); ?></b> · <?php echo esc_html( get_comment_date() ); ?>
			<?php if ( $rating ) { echo ' · ' . vb_stars( $rating ); } // phpcs:ignore -- escaped in function ?></div>
		<?php if ( '0' === $comment->comment_approved ) : ?><p><em><?php esc_html_e( 'Thanks! Your review is awaiting approval.', 'vibeistic' ); ?></em></p><?php endif; ?>
		<?php comment_text(); ?>
		<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
	<?php
}

/* -------------------------------------------------------------
 * 7. SEO: Review schema + meta description fallback
 * ----------------------------------------------------------- */
add_action( 'wp_head', function () {
	if ( ! is_singular( 'place' ) ) { return; }
	$id    = get_queried_object_id();
	$score = vb_score( $id );
	if ( ! $score ) { return; }
	$data = array(
		'@context'      => 'https://schema.org',
		'@type'         => 'Review',
		'itemReviewed'  => array( '@type' => 'LocalBusiness', 'name' => get_the_title( $id ), 'address' => get_post_meta( $id, '_vb_address', true ) ),
		'reviewRating'  => array( '@type' => 'Rating', 'ratingValue' => $score, 'bestRating' => 10, 'worstRating' => 0 ),
		'author'        => array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $id ) ) ),
		'publisher'     => array( '@type' => 'Organization', 'name' => get_bloginfo( 'name' ) ),
		'datePublished' => get_the_date( 'c', $id ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data ) . '</script>' . "\n";
} );

/** Basic meta description – skipped automatically if Rank Math or Yoast is active. */
add_action( 'wp_head', function () {
	if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) ) { return; }
	$desc = '';
	if ( is_front_page() ) {
		$desc = get_bloginfo( 'description' );
	} elseif ( is_singular() ) {
		$desc = has_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', get_queried_object_id() ) ), 28, '…' );
	} elseif ( is_tax() || is_category() ) {
		$desc = wp_strip_all_tags( term_description() );
	}
	if ( $desc ) { echo '<meta name="description" content="' . esc_attr( wp_trim_words( $desc, 30, '…' ) ) . '">' . "\n"; }
}, 3 );

/* -------------------------------------------------------------
 * 8. CUSTOMIZER: homepage text + newsletter
 * ----------------------------------------------------------- */
add_action( 'customize_register', function ( $c ) {
	$c->add_section( 'vb_home', array( 'title' => 'Vibeistic – Homepage', 'priority' => 30 ) );
	$fields = array(
		'vb_hero_eyebrow' => array( 'Small label above headline', 'Honest local reviews · Mumbai' ),
		'vb_hero_line1'   => array( 'Headline (before highlight)', 'Find your' ),
		'vb_hero_line2'   => array( 'Highlighted word', 'vibe' ),
		'vb_hero_line3'   => array( 'Headline (after highlight)', 'in the city.' ),
		'vb_hero_text'    => array( 'Hero description', 'First-hand reviews to eat, sip, travel, pray, play and stay — scored on what actually matters and searchable by your nearest station.' ),
		'vb_newsletter'   => array( 'Newsletter form action URL (Mailchimp / MailerLite / Brevo)', '' ),
	);
	foreach ( $fields as $id => $f ) {
		$c->add_setting( $id, array( 'default' => $f[1], 'sanitize_callback' => 'vb_newsletter' === $id ? 'esc_url_raw' : 'sanitize_text_field' ) );
		$c->add_control( $id, array( 'label' => $f[0], 'section' => 'vb_home', 'type' => 'vb_hero_text' === $id ? 'textarea' : 'text' ) );
	}
} );

function vb_mod( $id, $default ) { return get_theme_mod( $id, $default ); }

/* -------------------------------------------------------------
 * 9. HELPERS
 * ----------------------------------------------------------- */
/** Image block: featured image or pillar gradient + icon. */
function vb_place_image( $post_id, $size = 'vb-card', $inner = '' ) {
	$p = vb_place_pillar( $post_id );
	if ( has_post_thumbnail( $post_id ) ) {
		$style = 'background-image:url(' . esc_url( get_the_post_thumbnail_url( $post_id, $size ) ) . ')';
		$icon  = '';
	} else {
		$style = 'background:linear-gradient(135deg,' . esc_attr( $p['bg'] ) . ')';
		$icon  = esc_html( $p['icon'] );
	}
	$alt = esc_attr( get_the_title( $post_id ) );
	return '<div class="ph" role="img" aria-label="' . $alt . '" style="' . $style . '">' . $icon . $inner . '</div>';
}

/** Primary menu fallback: the six pillars. */
function vb_menu_fallback() {
	echo '<ul>';
	foreach ( vb_pillars() as $slug => $p ) {
		$link = vb_pillar_link( $slug );
		if ( $link ) { echo '<li><a href="' . esc_url( $link ) . '">' . esc_html( $p['name'] ) . '</a></li>'; }
	}
	echo '</ul>';
}

/** Breadcrumb for reviews. */
function vb_crumbs( $p = null ) {
	echo '<nav class="crumbs" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a> › ';
	if ( $p && $p['term'] ) {
		echo '<a href="' . esc_url( get_term_link( $p['term'] ) ) . '">' . esc_html( $p['name'] ) . '</a> › ';
	}
	echo '<span>' . esc_html( get_the_title() ) . '</span></nav>';
}

require get_template_directory() . '/inc/ads.php';
require get_template_directory() . '/inc/sample-data.php';
