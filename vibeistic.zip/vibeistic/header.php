<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main">Skip to content</a>
<header class="site-header">
	<div class="nav">
		<?php if ( has_custom_logo() ) { the_custom_logo(); } else { echo vb_brand(); } // phpcs:ignore -- escaped in function ?>
		<nav class="main-nav" aria-label="Primary">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth' => 1, 'fallback_cb' => 'vb_menu_fallback' ) ); ?>
		</nav>
		<div class="nav-actions">
			<a href="<?php echo esc_url( get_post_type_archive_link( 'place' ) ); ?>" class="btn">Explore</a>
			<button class="icon-btn" type="button" data-drawer-open aria-controls="vb-drawer" aria-expanded="false" aria-label="Open menu">☰</button>
		</div>
	</div>
</header>

<div class="drawer" id="vb-drawer" aria-hidden="true">
	<div class="drawer-bg" data-drawer-close></div>
	<div class="drawer-panel" role="dialog" aria-modal="true" aria-label="Menu">
		<div class="drawer-head">
			<?php echo vb_brand( 'span' ); // phpcs:ignore ?>
			<button class="icon-btn" type="button" data-drawer-close aria-label="Close menu" style="display:inline-flex">✕</button>
		</div>
		<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="hidden" name="post_type" value="place">
			<label class="screen-reader-text" for="vb-drawer-s">Search</label>
			<input id="vb-drawer-s" type="search" name="s" placeholder="Search thali, gym, temple…">
			<button class="btn" type="submit" aria-label="Search">🔍</button>
		</form>
		<div class="drawer-pillars">
			<?php foreach ( vb_pillars() as $slug => $p ) : $l = vb_pillar_link( $slug ); if ( ! $l ) { continue; } ?>
				<a href="<?php echo esc_url( $l ); ?>"><span style="font-size:22px"><?php echo esc_html( $p['icon'] ); ?></span><span><?php echo esc_html( $p['name'] ); ?><small><?php echo esc_html( $p['hi'] ); ?></small></span></a>
			<?php endforeach; ?>
		</div>
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) ); ?>
		<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => false ) ); ?>
	</div>
</div>
<main id="main">
