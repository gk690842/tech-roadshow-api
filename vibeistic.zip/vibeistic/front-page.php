<?php
/**
 * Homepage (used automatically as the front page).
 *
 * @package Vibeistic
 */
get_header();

$vb_pillars = vb_pillars();
$vb_count   = (int) wp_count_posts( 'place' )->publish;
$vb_areas   = get_terms( array( 'taxonomy' => 'vb_area', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC' ) );
$vb_areas   = is_wp_error( $vb_areas ) ? array() : $vb_areas;
$vb_reviews = (int) get_comments( array( 'post_type' => 'place', 'status' => 'approve', 'count' => true ) );
?>

<!-- HERO -->
<section class="hero">
	<div class="wrap">
		<span class="eyebrow"><?php echo esc_html( vb_mod( 'vb_hero_eyebrow', 'Honest local reviews · Mumbai' ) ); ?></span>
		<h1><?php echo esc_html( vb_mod( 'vb_hero_line1', 'Find your' ) ); ?> <span><?php echo esc_html( vb_mod( 'vb_hero_line2', 'vibe' ) ); ?></span> <?php echo esc_html( vb_mod( 'vb_hero_line3', 'in the city.' ) ); ?></h1>
		<p><?php echo esc_html( vb_mod( 'vb_hero_text', 'First-hand reviews to eat, sip, travel, pray, play and stay — scored on what actually matters and searchable by your nearest station.' ) ); ?></p>
		<form class="searchbar" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="hidden" name="post_type" value="place">
			<input type="hidden" name="vb_hero" value="1">
			<label class="screen-reader-text" for="vb-q">Search reviews</label>
			<input id="vb-q" type="search" name="s" placeholder="Try “unlimited thali”, “24x7 gym”, “sunset spot”…">
			<label class="screen-reader-text" for="vb-area">Area</label>
			<select id="vb-area" name="vb_area">
				<option value="">All areas</option>
				<?php foreach ( $vb_areas as $a ) : ?>
					<option value="<?php echo esc_attr( $a->slug ); ?>"><?php echo esc_html( $a->name ); ?></option>
				<?php endforeach; ?>
			</select>
			<button class="btn coral" type="submit">Search</button>
		</form>
		<div class="stats">
			<div><b><?php echo esc_html( number_format_i18n( $vb_count ) ); ?></b><span>Places reviewed</span></div>
			<div><b><?php echo esc_html( number_format_i18n( count( $vb_areas ) ) ); ?></b><span>Areas covered</span></div>
			<div><b><?php echo esc_html( number_format_i18n( $vb_reviews ) ); ?></b><span>Reader reviews</span></div>
		</div>
	</div>
</section>

<!-- SIX PILLARS -->
<section>
	<div class="wrap">
		<div class="head"><h2 class="hand-h">Pick your vibe</h2><p>Six ways to know a city — each scored on what matters for it.</p></div>
		<div class="pillars">
			<?php foreach ( $vb_pillars as $slug => $p ) : $l = vb_pillar_link( $slug ); if ( ! $l ) { continue; } ?>
				<a class="pillar" href="<?php echo esc_url( $l ); ?>" style="--pc:<?php echo esc_attr( $p['color'] ); ?>">
					<div class="ico"><?php echo esc_html( $p['icon'] ); ?></div>
					<b><?php echo esc_html( $p['name'] ); ?></b>
					<i><?php echo esc_html( $p['hi'] ); ?></i>
					<span><?php echo esc_html( $p['sub'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!-- TOP RATED -->
<section id="top-rated" style="background:var(--card)">
	<div class="wrap">
		<div class="head">
			<h2 class="hand-h">Top rated</h2>
			<div class="tabs" data-tabs role="tablist">
				<button class="tab active" data-filter="all" role="tab" aria-selected="true">All</button>
				<?php foreach ( $vb_pillars as $slug => $p ) : ?>
					<button class="tab" data-filter="<?php echo esc_attr( $slug ); ?>" role="tab" aria-selected="false"><?php echo esc_html( $p['icon'] . ' ' . $p['name'] ); ?></button>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="grid" data-grid>
			<?php
			$vb_shown = 0;
			foreach ( $vb_pillars as $slug => $p ) {
				$q = new WP_Query( array(
					'post_type'      => 'place',
					'posts_per_page' => 2,
					'meta_key'       => '_vb_score',
					'orderby'        => 'meta_value_num',
					'order'          => 'DESC',
					'tax_query'      => array( array( 'taxonomy' => 'vb_pillar', 'field' => 'slug', 'terms' => $slug ) ),
					'no_found_rows'  => true,
				) );
				while ( $q->have_posts() ) { $q->the_post(); get_template_part( 'parts/card-place' ); $vb_shown++; }
				wp_reset_postdata();
			}
			if ( ! $vb_shown ) {
				echo '<div class="empty">No reviews yet. Add one under <b>Reviews → Add Review</b>, or preview the design via <b>Appearance → Vibeistic Sample Data</b>.</div>';
			}
			?>
		</div>
		<p style="text-align:center;margin-top:24px"><a class="btn light" href="<?php echo esc_url( get_post_type_archive_link( 'place' ) ); ?>">See all reviews →</a></p>
	</div>
</section>

<div class="wrap"><?php echo vb_ad( 'display' ); // phpcs:ignore -- escaped in function ?></div>

<!-- FEATURED STORY (sticky post, else latest post) -->
<?php
$vb_sticky = get_option( 'sticky_posts' );
$vb_fargs  = array( 'post_type' => 'post', 'posts_per_page' => 1, 'ignore_sticky_posts' => true, 'no_found_rows' => true );
if ( $vb_sticky ) { $vb_fargs['post__in'] = $vb_sticky; }
$vb_feat = new WP_Query( $vb_fargs );
if ( $vb_feat->have_posts() ) : $vb_feat->the_post(); ?>
<section>
	<div class="wrap">
		<div class="head"><h2 class="hand-h">Featured story</h2></div>
		<div class="feature">
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="ph" role="img" aria-label="<?php the_title_attribute(); ?>" style="background-image:url(<?php echo esc_url( get_the_post_thumbnail_url( null, 'vb-hero' ) ); ?>)"></div>
			<?php else : ?>
				<div class="ph">🗺️</div>
			<?php endif; ?>
			<div class="feature-body">
				<div class="tag"><?php $vb_c = get_the_category(); echo esc_html( $vb_c ? $vb_c[0]->name : 'Story' ); ?></div>
				<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 36 ) ); ?></p>
				<a href="<?php the_permalink(); ?>" class="btn">Read the story →</a>
			</div>
		</div>
	</div>
</section>
<?php endif; wp_reset_postdata(); ?>

<!-- AREAS -->
<?php if ( $vb_areas ) : ?>
<section id="areas" style="padding-top:0">
	<div class="wrap">
		<div class="head"><h2 class="hand-h">Browse by area</h2><p>Everything worth your time near your station.</p></div>
		<div class="areas">
			<?php foreach ( array_slice( $vb_areas, 0, 24 ) as $a ) : ?>
				<a class="area" href="<?php echo esc_url( get_term_link( $a ) ); ?>">🚉 <?php echo esc_html( $a->name ); ?> <small>(<?php echo (int) $a->count; ?>)</small></a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<!-- HOW WE RATE -->
<section style="background:var(--card)">
	<div class="wrap">
		<div class="head"><h2 class="hand-h">How we rate</h2><p>Trust is the whole point. Here is our promise.</p></div>
		<div class="how">
			<div>🧾<b>We pay our own bills</b><p>No free meals or stays for ratings. Sponsored content is always labelled.</p></div>
			<div>📸<b>Only our own photos</b><p>Every place is visited in person. No stock photos, no copied reviews.</p></div>
			<div>📏<b>Scores that fit</b><p>A gym is judged on crowd and facilities, a temple on darshan and calm.</p></div>
			<div>🔄<b>Re-checked often</b><p>Top picks are revisited, and the “Updated” date means a real re-check.</p></div>
		</div>
	</div>
</section>

<!-- READER REVIEWS -->
<?php
$vb_latest = get_comments( array( 'post_type' => 'place', 'status' => 'approve', 'number' => 3, 'meta_key' => 'vb_rating' ) );
if ( $vb_latest ) : ?>
<section>
	<div class="wrap">
		<div class="head"><h2 class="hand-h">From our readers</h2></div>
		<div class="reviews">
			<?php foreach ( $vb_latest as $cm ) : $vb_ra = get_the_terms( $cm->comment_post_ID, 'vb_area' ); ?>
				<div class="review">
					<div class="who"><div class="avatar"><?php echo esc_html( mb_substr( $cm->comment_author, 0, 1 ) ); ?></div>
						<div><b><?php echo esc_html( $cm->comment_author ); ?></b><small><?php echo esc_html( ( $vb_ra && ! is_wp_error( $vb_ra ) ) ? $vb_ra[0]->name : '' ); ?></small></div></div>
					<?php echo vb_stars( get_comment_meta( $cm->comment_ID, 'vb_rating', true ) ); // phpcs:ignore ?>
					<p><?php echo esc_html( wp_trim_words( $cm->comment_content, 30 ) ); ?></p>
					<div class="on">on <a href="<?php echo esc_url( get_comment_link( $cm ) ); ?>"><?php echo esc_html( get_the_title( $cm->comment_post_ID ) ); ?></a></div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<!-- NEWSLETTER -->
<section style="padding-top:0">
	<div class="wrap">
		<div class="cta">
			<div><h3>Never miss a good vibe.</h3><p>One email a week: new finds, trails and hidden gems. No spam.</p></div>
			<?php $vb_nl = vb_mod( 'vb_newsletter', '' ); ?>
			<form method="post" action="<?php echo esc_url( $vb_nl ? $vb_nl : '#' ); ?>" <?php echo $vb_nl ? 'target="_blank"' : 'data-demo'; ?>>
				<label class="screen-reader-text" for="vb-nl">Email address</label>
				<input id="vb-nl" type="email" name="EMAIL" placeholder="Your email address" required>
				<button class="btn" type="submit">Subscribe</button>
			</form>
		</div>
	</div>
</section>

<?php get_footer();
