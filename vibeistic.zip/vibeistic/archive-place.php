<?php
/** All reviews, pillar pages, area pages and review search results. */
get_header();
$vb_term = is_tax() ? get_queried_object() : null;
if ( is_search() ) {
	$vb_title = 'Results for “' . get_search_query() . '”';
	$vb_a     = get_query_var( 'vb_area' ) ? get_term_by( 'slug', get_query_var( 'vb_area' ), 'vb_area' ) : false;
	if ( $vb_a ) { $vb_title .= ' in ' . $vb_a->name; }
} elseif ( is_tax( 'vb_pillar' ) ) {
	$vb_all   = vb_pillars();
	$vb_pp    = $vb_all[ $vb_term->slug ] ?? null;
	$vb_title = $vb_pp ? $vb_pp['icon'] . ' ' . $vb_pp['name'] . ' · ' . $vb_pp['hi'] : single_term_title( '', false );
} elseif ( is_tax( 'vb_area' ) ) {
	$vb_title = 'Best of ' . single_term_title( '', false );
} else {
	$vb_title = 'All reviews';
}
?>
<div class="wrap">
	<div class="page-head">
		<nav class="crumbs" aria-label="Breadcrumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a> › <span><?php echo esc_html( wp_strip_all_tags( $vb_title ) ); ?></span></nav>
		<h1 class="hand-h"><?php echo esc_html( $vb_title ); ?></h1>
		<?php if ( $vb_term && term_description() ) : ?><div class="sub-meta"><?php echo wp_kses_post( term_description() ); ?></div><?php endif; ?>
	</div>

	<?php if ( ! is_tax( 'vb_pillar' ) ) : ?>
		<div class="tabs" data-tabs role="tablist" style="margin:12px 0 4px">
			<button class="tab active" data-filter="all" role="tab" aria-selected="true">All</button>
			<?php foreach ( vb_pillars() as $slug => $p ) : ?>
				<button class="tab" data-filter="<?php echo esc_attr( $slug ); ?>" role="tab" aria-selected="false"><?php echo esc_html( $p['icon'] . ' ' . $p['name'] ); ?></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<div class="grid" data-grid style="margin:20px 0 10px">
		<?php
		$vb_i = 0;
		if ( have_posts() ) :
			while ( have_posts() ) : the_post();
				get_template_part( 'parts/card-place' );
				$vb_i++;
				if ( 8 === $vb_i ) { $vb_ad = vb_ad( 'display' ); if ( $vb_ad ) { echo '<div style="grid-column:1/-1">' . $vb_ad . '</div>'; } } // phpcs:ignore
			endwhile;
		else : ?>
			<div class="empty">No reviews found yet. Try another search, area or pillar.</div>
		<?php endif; ?>
	</div>
	<div class="pagination"><?php echo paginate_links( array( 'mid_size' => 1 ) ); // phpcs:ignore -- core output ?></div>
</div>
<?php get_footer();
