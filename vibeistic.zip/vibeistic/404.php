<?php
/** Default template: blog posts, pages and other archives. */
get_header(); ?>
<div class="wrap">
	<?php if ( is_singular() ) : while ( have_posts() ) : the_post(); ?>
		<div class="page-head">
			<?php if ( is_single() ) { vb_crumbs(); } ?>
			<h1><?php the_title(); ?></h1>
			<?php if ( is_single() ) : ?><p class="sub-meta"><?php echo esc_html( get_the_date() ); ?> · <?php the_author(); ?></p><?php endif; ?>
		</div>
		<article class="entry page-content">
			<?php if ( has_post_thumbnail() ) : ?><div class="hero-img"><?php the_post_thumbnail( 'vb-hero' ); ?></div><?php endif; ?>
			<?php the_content(); ?>
			<?php wp_link_pages(); ?>
			<?php if ( comments_open() || get_comments_number() ) { comments_template(); } ?>
		</article>
	<?php endwhile; else : ?>
		<div class="page-head"><h1 class="hand-h"><?php
			if ( is_search() ) { echo esc_html( 'Results for “' . get_search_query() . '”' ); }
			elseif ( is_home() ) { echo esc_html__( 'Stories & trails', 'vibeistic' ); }
			elseif ( is_404() ) { echo esc_html__( 'Lost your vibe?', 'vibeistic' ); }
			else { echo wp_kses_post( get_the_archive_title() ); }
		?></h1></div>
		<div class="grid" style="margin:20px 0">
			<?php if ( have_posts() && ! is_404() ) : while ( have_posts() ) : the_post();
				if ( 'place' === get_post_type() ) { get_template_part( 'parts/card-place' ); continue; } ?>
				<article class="card">
					<?php if ( has_post_thumbnail() ) : ?><a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><div class="ph" style="background-image:url(<?php echo esc_url( get_the_post_thumbnail_url( null, 'vb-card' ) ); ?>)"></div></a><?php endif; ?>
					<div class="card-body"><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<p class="loc" style="margin-top:6px"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p></div>
				</article>
			<?php endwhile; else : ?>
				<div class="empty"><?php echo is_404() ? 'This page doesn’t exist. Try the search or one of the six pillars.' : 'Nothing found.'; ?><br><br><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go home</a></div>
			<?php endif; ?>
		</div>
		<div class="pagination"><?php echo paginate_links( array( 'mid_size' => 1 ) ); // phpcs:ignore ?></div>
	<?php endif; ?>
</div>
<?php get_footer();
