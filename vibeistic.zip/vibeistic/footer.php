</main>
<footer class="site-footer">
	<div class="wrap">
		<div class="foot">
			<div>
				<?php echo vb_brand(); // phpcs:ignore ?>
				<p style="margin-top:10px;max-width:340px">Honest, first-hand reviews of places to eat, sip, travel, pray, play and stay. We pay our own bills.</p>
			</div>
			<div><h4>Explore</h4>
				<?php foreach ( vb_pillars() as $slug => $p ) : $l = vb_pillar_link( $slug ); if ( $l ) : ?>
					<a href="<?php echo esc_url( $l ); ?>"><?php echo esc_html( $p['icon'] . ' ' . $p['name'] ); ?></a>
				<?php endif; endforeach; ?>
			</div>
			<div><h4>Popular Areas</h4>
				<?php $areas = get_terms( array( 'taxonomy' => 'vb_area', 'number' => 6, 'orderby' => 'count', 'order' => 'DESC' ) );
				if ( ! is_wp_error( $areas ) ) { foreach ( $areas as $a ) { echo '<a href="' . esc_url( get_term_link( $a ) ) . '">' . esc_html( $a->name ) . '</a>'; } } ?>
			</div>
			<div><h4>About</h4>
				<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'depth' => 1, 'fallback_cb' => function () {
					if ( current_user_can( 'edit_theme_options' ) ) { echo '<a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">Set up the “Footer” menu</a>'; }
				} ) ); ?>
			</div>
		</div>
		<div class="copy">© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?> · All photos are our own unless stated.</div>
	</div>
</footer>

<nav class="bottom-nav" aria-label="Quick navigation">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="<?php echo is_front_page() ? 'is-active' : ''; ?>"><span class="bi">🏠</span>Home</a>
	<a href="<?php echo esc_url( get_post_type_archive_link( 'place' ) ); ?>" class="<?php echo ( is_post_type_archive( 'place' ) || is_tax() ) ? 'is-active' : ''; ?>"><span class="bi">🧭</span>Explore</a>
	<button type="button" data-drawer-open data-focus-search><span class="bi">🔍</span>Search</button>
	<button type="button" data-drawer-open><span class="bi">☰</span>Menu</button>
</nav>
<?php wp_footer(); ?>
</body>
</html>
