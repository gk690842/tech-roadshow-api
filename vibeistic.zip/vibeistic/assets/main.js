/* Vibeistic – small, dependency-free scripts. */
(function () {
  /* Mobile drawer */
  var drawer = document.getElementById('vb-drawer');
  var lastFocus = null;
  function openDrawer(focusSearch) {
    if (!drawer) return;
    lastFocus = document.activeElement;
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
    document.querySelectorAll('[data-drawer-open]').forEach(function (b) { b.setAttribute('aria-expanded', 'true'); });
    var target = focusSearch ? drawer.querySelector('input[type=search]') : drawer.querySelector('[data-drawer-close].icon-btn');
    if (target) setTimeout(function () { target.focus(); }, 250);
  }
  function closeDrawer() {
    if (!drawer) return;
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('no-scroll');
    document.querySelectorAll('[data-drawer-open]').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
    if (lastFocus) lastFocus.focus();
  }
  document.addEventListener('click', function (e) {
    var o = e.target.closest('[data-drawer-open]');
    if (o) { e.preventDefault(); openDrawer(o.hasAttribute('data-focus-search')); return; }
    if (e.target.closest('[data-drawer-close]')) { e.preventDefault(); closeDrawer(); }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && drawer && drawer.classList.contains('open')) closeDrawer();
  });
  window.addEventListener('resize', function () { if (window.innerWidth > 960) closeDrawer(); });

  /* Pillar tabs – filter cards on the page */
  document.querySelectorAll('[data-tabs]').forEach(function (tabs) {
    var scope = tabs.closest('.wrap');
    var grid = scope && scope.querySelector('[data-grid]');
    if (!grid) return;
    tabs.addEventListener('click', function (e) {
      var btn = e.target.closest('.tab');
      if (!btn) return;
      tabs.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      btn.classList.add('active'); btn.setAttribute('aria-selected', 'true');
      btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      var f = btn.getAttribute('data-filter'), shown = 0;
      grid.querySelectorAll('.card').forEach(function (c) {
        var ok = f === 'all' || c.getAttribute('data-cat') === f;
        c.style.display = ok ? '' : 'none';
        if (ok) shown++;
      });
      var empty = grid.querySelector('.vb-empty');
      if (!shown) {
        if (!empty) { empty = document.createElement('div'); empty.className = 'empty vb-empty'; empty.textContent = 'No reviews here yet — coming soon!'; grid.appendChild(empty); }
        empty.style.display = '';
      } else if (empty) { empty.style.display = 'none'; }
    });
  });

  /* Newsletter placeholder (until a form URL is set in the Customizer) */
  document.querySelectorAll('form[data-demo]').forEach(function (f) {
    f.addEventListener('submit', function (e) { e.preventDefault(); f.innerHTML = '<b>Thanks! Connect your newsletter tool in Appearance → Customize → Vibeistic – Homepage.</b>'; });
  });
})();
