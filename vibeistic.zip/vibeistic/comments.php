<?php
if ( post_password_required() ) { return; } ?>
<div id="comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="hand-h" style="font-size:34px;margin-bottom:14px"><?php echo is_singular( 'place' ) ? 'Reader reviews' : 'Comments'; ?> (<?php echo (int) get_comments_number(); ?>)</h2>
		<ol class="comment-list">
			<?php wp_list_comments( array( 'callback' => 'vb_comment_cb', 'style' => 'ol' ) ); ?>
		</ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>
	<?php comment_form(); ?>
</div>
