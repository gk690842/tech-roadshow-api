<?php
/** Pillar and area pages use the reviews archive layout. */
require __DIR__ . '/archive-place.php';
