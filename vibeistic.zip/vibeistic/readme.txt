VIBEISTIC – WordPress theme (v1.0.0)
Six ways to know a city: Eat · Sip · Travel · Pray · Play · Stay
=================================================================

INSTALL (about 10 minutes)
1. WordPress admin → Appearance → Themes → Add New → Upload Theme → vibeistic.zip → Install → Activate.
2. Settings → Permalinks → click "Save Changes" once (creates the clean URLs).
3. Settings → Discussion → tick "Comment must be manually approved" (moderates reader reviews).
4. Settings → General → Site Title: Vibeistic · Tagline: Six ways to know a city. · Timezone: Kolkata.
5. Appearance → Customize → Site Identity → Site Icon: upload assets/brand/icon-512.png
   (a favicon is already built in, this just makes it official).

PREVIEW WITH SAMPLE DATA
Appearance → Vibeistic Sample Data → Import. 12 FICTIONAL reviews (2 per pillar).
Remove them before launch (same screen → Remove sample data).

ADD A REAL REVIEW
Reviews → Add Review:
- Title, your own review text and photos, Featured image (your photo)
- Pillars (right sidebar): tick ONE of Eat / Sip / Travel / Pray / Play / Stay
- Areas / Stations: tick or add the area
- "Review Details & Scores" box: badge, price, verdict, address, station, timings, best for, 3 scores (0–10)
The overall score is worked out automatically.

SCORE FACTORS PER PILLAR
Eat: Taste / Value / Hygiene        Sip: Brew / Vibe / Value
Travel: Experience / Access / Value Pray: Darshan / Cleanliness / Calm
Play: Facilities / Crowd / Value    Stay: Room / Location / Value
Change them in vb_pillars() at the top of functions.php.

URLS
/reviews/              all reviews (sorted by score)
/explore/eat/          one pillar (also /explore/sip/, /explore/travel/ …)
/area/dadar/           one area / station
/review/rajwadi-rasoi/ a single review

MENUS
Appearance → Menus → create "Main" (assign to Primary Menu) and "About" (assign to Footer – About Links).
If no Primary menu is set, the six pillars are shown automatically.

MOBILE
Hamburger menu + slide-in drawer, sticky bottom bar (Home · Explore · Search · Menu),
swipeable pillar tabs, one-column cards, 44px tap targets, 16px inputs (no iPhone zoom).

ADSENSE (when you are ready)
Appearance → Customize → Vibeistic – AdSense
1. Paste your Publisher ID (ca-pub-…) → Publish. This adds Google's verification tag and serves
   https://yoursite/ads.txt automatically. Now apply / request review in AdSense.
2. After approval: tick "Show ads". Auto ads work from your AdSense dashboard.
3. Optional manual units: create an In-article unit and a Display unit in AdSense, paste their
   slot IDs. They appear after paragraph 3 of reviews, in the review sidebar, on the homepage and
   in archive lists. Ads are hidden while you are logged in (avoid accidental self-clicks).
Ads never show on search results, 404, Privacy Policy, Contact or Disclaimer pages.

SEO
Review schema is added on every review page. A basic meta description is added unless Rank Math
or Yoast is installed (then they take over).

BRAND FILES (assets/brand)
logo.svg (full lockup) · icon.svg (pin + vibe waves) · favicon.svg · icon-32/192/512.png
Colours: Violet #5b2a86 · Coral #ff5e7e · Mango #ffb238 · Ink #1d1730
Fonts: Poppins (text) · Caveat (handwritten headings)
