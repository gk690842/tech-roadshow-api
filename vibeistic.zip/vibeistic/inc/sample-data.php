<?php
/**
 * Sample data importer/remover. All names are FICTIONAL.
 * Appearance → Vibeistic Sample Data
 *
 * @package Vibeistic
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function vb_sample_places() {
	// pillar, title, area, badge, price, f1, f2, f3, verdict
	return array(
		array( 'eat', 'Rajwadi Rasoi', 'Andheri', 'Unlimited thali', '₹380 per plate', 9.3, 8.6, 8.8, '22 items and refills arrive before you ask.' ),
		array( 'eat', 'Konkan Coast Kitchen', 'Dadar', 'Seafood', '₹900 for two', 9.1, 8.4, 8.0, 'Order the bombil fry. Expect a 20-min wait on weekends.' ),
		array( 'sip', 'Brew & Banter Café', 'Bandra', 'Work-friendly', '₹600 for two', 8.6, 9.2, 7.8, 'Fast Wi-Fi, plug points at every table, great cold brew.' ),
		array( 'sip', 'Tapri Tales', 'Dadar', 'Chai under ₹50', '₹120 for two', 8.8, 8.0, 9.4, 'Cutting chai and bun maska that beat most cafés.' ),
		array( 'travel', 'Sunset Point Promenade', 'Colaba', 'Sunset spot', 'Free', 9.0, 9.2, 9.8, 'Arrive 30 minutes before sunset for a seat on the wall.' ),
		array( 'travel', 'Misty Ridge Day Trek', 'Outside Mumbai', 'Monsoon trek', '₹1,200 per person', 9.1, 7.2, 8.4, 'Beginner-friendly; carry grip shoes in the rains.' ),
		array( 'pray', 'Shri Sample Ganesh Mandir', 'Dadar', 'Festival hotspot', 'Free entry', 7.0, 8.8, 6.5, 'Go before 7 AM on Tuesdays to skip the long queue.' ),
		array( 'pray', 'Lakeside Devi Temple', 'Thane', 'Peaceful', 'Free entry', 9.2, 8.9, 9.4, 'Quiet lakeside spot; the evening aarti is beautiful.' ),
		array( 'play', 'IronCore Fitness', 'Andheri', '24×7 gym', '₹2,000 / month', 9.0, 6.8, 8.2, 'Great free-weights section. Avoid the 7–9 PM rush.' ),
		array( 'play', 'Skyline Turf Arena', 'Malad', 'Rooftop turf', '₹1,200 / hour', 8.7, 8.0, 8.4, '5-a-side football and box cricket. Book 2 days ahead.' ),
		array( 'stay', 'Harbour View Residency', 'Colaba', 'Sea view', '₹6,500 / night', 8.4, 9.5, 7.2, 'Walk to Gateway of India; ask for an upper-floor room.' ),
		array( 'stay', 'Transit Inn', 'Andheri', 'Near airport', '₹3,200 / night', 7.8, 9.0, 8.5, 'Ideal for early flights. Basic but spotless.' ),
	);
}

function vb_sample_reviews() {
	return array(
		'Rajwadi Rasoi'        => array( 'Priya S.', 5, 'Went on your recommendation — the dal baati alone was worth it. Refill timing was exactly as described.' ),
		'Skyline Turf Arena'   => array( 'Rohit M.', 4, 'Good turf and lighting. Parking is tight on weekends, so come by train if you can.' ),
		'Lakeside Devi Temple' => array( 'Aisha K.', 5, 'Visited for the evening aarti. Peaceful and very clean, just like the review said.' ),
	);
}

add_action( 'admin_menu', function () {
	add_theme_page( 'Vibeistic Sample Data', 'Vibeistic Sample Data', 'manage_options', 'vb-sample', 'vb_sample_page' );
} );

function vb_sample_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$msg = '';
	if ( isset( $_POST['vb_action'] ) && check_admin_referer( 'vb_sample' ) ) {
		$msg = ( 'import' === $_POST['vb_action'] ) ? vb_import_samples() : vb_remove_samples();
	}
	$count = count( get_posts( array( 'post_type' => 'place', 'post_status' => 'any', 'meta_key' => '_vb_sample', 'fields' => 'ids', 'numberposts' => -1 ) ) );
	?>
	<div class="wrap">
		<h1>Vibeistic – Sample Data</h1>
		<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
		<p>Imports 12 <strong>fictional</strong> reviews (2 per pillar), areas and 3 reader reviews so you can preview the design.<br>
		<strong>Remove them before launch</strong> — never publish ratings for places you have not visited.</p>
		<p>Sample reviews on the site now: <strong><?php echo (int) $count; ?></strong></p>
		<form method="post">
			<?php wp_nonce_field( 'vb_sample' ); ?>
			<button class="button button-primary" name="vb_action" value="import">Import sample data</button>
			<button class="button" name="vb_action" value="remove" onclick="return confirm('Delete all sample reviews?')">Remove sample data</button>
		</form>
	</div>
	<?php
}

function vb_import_samples() {
	vb_register_types();
	vb_ensure_pillars();
	$created = 0;
	$ids     = array();
	foreach ( vb_sample_places() as $p ) {
		list( $pillar, $title, $area, $badge, $price, $f1, $f2, $f3, $verdict ) = $p;
		$existing = get_posts( array( 'post_type' => 'place', 'title' => $title, 'post_status' => 'any', 'meta_key' => '_vb_sample', 'fields' => 'ids', 'numberposts' => 1 ) );
		if ( $existing ) { $ids[ $title ] = $existing[0]; continue; }

		$id = wp_insert_post( array(
			'post_type'      => 'place',
			'post_title'     => $title,
			'post_status'    => 'publish',
			'comment_status' => 'open',
			'post_excerpt'   => $verdict,
			'post_content'   => "<!-- wp:paragraph --><p><strong>SAMPLE CONTENT.</strong> Replace this with your own first-hand review.</p><!-- /wp:paragraph -->\n<!-- wp:heading --><h2>My Experience</h2><!-- /wp:heading -->\n<!-- wp:paragraph --><p>Write the story of your visit here: when you went, what you tried or used, and how long you waited.</p><!-- /wp:paragraph -->\n<!-- wp:paragraph --><p>Add 3–4 of your own photos between paragraphs. Readers trust real photos far more than stock images.</p><!-- /wp:paragraph -->\n<!-- wp:heading --><h2>Good to Know</h2><!-- /wp:heading -->\n<!-- wp:list --><ul><li>Best time to visit</li><li>What to try or skip</li><li>How to get there from the station</li></ul><!-- /wp:list -->\n<!-- wp:paragraph --><p>Finish with who this place suits best and whether you would go again.</p><!-- /wp:paragraph -->",
		) );
		if ( is_wp_error( $id ) || ! $id ) { continue; }
		wp_set_object_terms( $id, $pillar, 'vb_pillar' );
		if ( ! term_exists( $area, 'vb_area' ) ) { wp_insert_term( $area, 'vb_area' ); }
		wp_set_object_terms( $id, $area, 'vb_area' );
		$meta = array( 'badge' => $badge, 'price' => $price, 'verdict' => $verdict, 'address' => $area . ', Mumbai', 'station' => $area . ' ([ ] min walk)', 'timings' => '[Add timings]', 'bestfor' => '[Add]', 'f1' => $f1, 'f2' => $f2, 'f3' => $f3, 'sample' => 1 );
		foreach ( $meta as $k => $v ) { update_post_meta( $id, '_vb_' . $k, $v ); }
		vb_update_score( $id );
		$ids[ $title ] = $id;
		$created++;
	}
	foreach ( vb_sample_reviews() as $title => $r ) {
		if ( empty( $ids[ $title ] ) || get_comments( array( 'post_id' => $ids[ $title ], 'count' => true ) ) ) { continue; }
		$cid = wp_insert_comment( array( 'comment_post_ID' => $ids[ $title ], 'comment_author' => $r[0], 'comment_content' => $r[2], 'comment_approved' => 1 ) );
		if ( $cid ) { add_comment_meta( $cid, 'vb_rating', $r[1] ); }
	}
	flush_rewrite_rules();
	return sprintf( 'Imported %d sample reviews.', $created );
}

function vb_remove_samples() {
	$ids = get_posts( array( 'post_type' => 'place', 'post_status' => 'any', 'meta_key' => '_vb_sample', 'fields' => 'ids', 'numberposts' => -1 ) );
	foreach ( $ids as $id ) { wp_delete_post( $id, true ); }
	$terms = get_terms( array( 'taxonomy' => 'vb_area', 'hide_empty' => false ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) { if ( 0 === (int) $t->count ) { wp_delete_term( $t->term_id, 'vb_area' ); } }
	}
	return sprintf( 'Removed %d sample reviews.', count( $ids ) );
}
