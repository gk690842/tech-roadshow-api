<?php
/**
 * Google AdSense integration (off until you add your Publisher ID).
 * Appearance → Customize → Vibeistic – AdSense
 *
 * @package Vibeistic
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'customize_register', function ( $c ) {
	$c->add_section( 'vb_ads', array(
		'title'       => 'Vibeistic – AdSense',
		'priority'    => 31,
		'description' => 'Paste your Publisher ID first (it adds the verification tag and ads.txt). Turn on "Show ads" only after Google approves your site.',
	) );
	$settings = array(
		'vb_ads_client'   => array( 'Publisher ID (ca-pub-XXXXXXXXXXXXXXXX)', 'text', '' ),
		'vb_ads_enabled'  => array( 'Show ads (load AdSense script)', 'checkbox', false ),
		'vb_ads_hide_admin' => array( 'Hide ads when I am logged in (protects against accidental self-clicks)', 'checkbox', true ),
		'vb_slot_article' => array( 'In-article ad unit slot ID (optional)', 'text', '' ),
		'vb_slot_display' => array( 'Display / responsive ad unit slot ID (optional)', 'text', '' ),
		'vb_ads_paragraph'=> array( 'Insert in-article ad after paragraph number', 'number', 3 ),
	);
	foreach ( $settings as $id => $s ) {
		$sanitize = 'checkbox' === $s[1] ? 'vb_sanitize_bool' : ( 'number' === $s[1] ? 'absint' : ( 'vb_ads_client' === $id ? 'vb_sanitize_client' : 'vb_sanitize_slot' ) );
		$c->add_setting( $id, array( 'default' => $s[2], 'sanitize_callback' => $sanitize ) );
		$c->add_control( $id, array( 'label' => $s[0], 'section' => 'vb_ads', 'type' => $s[1] ) );
	}
} );

function vb_sanitize_bool( $v ) { return (bool) $v; }
function vb_sanitize_slot( $v ) { return preg_replace( '/\D/', '', (string) $v ); }
function vb_sanitize_client( $v ) {
	$v = trim( (string) $v );
	if ( preg_match( '/^(ca-)?pub-(\d{10,20})$/', $v, $m ) ) { return 'ca-pub-' . $m[2]; }
	return '';
}

function vb_ads_client() { return vb_sanitize_client( get_theme_mod( 'vb_ads_client', '' ) ); }

/** Should ads be shown on this request? */
function vb_ads_on() {
	if ( ! vb_ads_client() || ! get_theme_mod( 'vb_ads_enabled', false ) ) { return false; }
	if ( get_theme_mod( 'vb_ads_hide_admin', true ) && is_user_logged_in() && current_user_can( 'edit_posts' ) ) { return false; }
	if ( is_404() || is_search() || is_page( array( 'privacy-policy', 'contact', 'disclaimer' ) ) ) { return false; }
	return true;
}

/** Verification meta tag (always, once ID is set) + AdSense script (only when enabled). */
add_action( 'wp_head', function () {
	$client = vb_ads_client();
	if ( ! $client ) { return; }
	echo '<meta name="google-adsense-account" content="' . esc_attr( $client ) . '">' . "\n";
	if ( vb_ads_on() ) {
		echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . esc_attr( $client ) . '" crossorigin="anonymous"></script>' . "\n";
	}
}, 5 );

/** Serve /ads.txt automatically (only if no physical ads.txt file exists). */
add_action( 'init', function () {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
	if ( '/ads.txt' !== $path ) { return; }
	$client = vb_ads_client();
	if ( ! $client ) { return; }
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo 'google.com, ' . esc_html( substr( $client, 3 ) ) . ', DIRECT, f08c47fec0942fa0' . "\n";
	exit;
}, 0 );

/**
 * Print an ad unit.
 * $type: 'display' (homepage / sidebar / archive) or 'article' (inside content).
 * With no slot ID, nothing is printed — Auto ads can still place ads.
 */
function vb_ad( $type = 'display', $class = '' ) {
	if ( ! vb_ads_on() ) { return ''; }
	$client = vb_ads_client();
	$slot   = get_theme_mod( 'article' === $type ? 'vb_slot_article' : 'vb_slot_display', '' );
	if ( ! $slot ) { return ''; }
	if ( 'article' === $type ) {
		$ins = '<ins class="adsbygoogle" style="display:block;text-align:center" data-ad-layout="in-article" data-ad-format="fluid" data-ad-client="' . esc_attr( $client ) . '" data-ad-slot="' . esc_attr( $slot ) . '"></ins>';
	} else {
		$ins = '<ins class="adsbygoogle" style="display:block" data-ad-client="' . esc_attr( $client ) . '" data-ad-slot="' . esc_attr( $slot ) . '" data-ad-format="auto" data-full-width-responsive="true"></ins>';
	}
	return '<div class="vb-ad ' . esc_attr( $class ) . '"><span class="vb-ad-label">Advertisement</span>' . $ins . '<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></div>';
}

/** Insert the in-article ad after paragraph N on reviews and blog posts. */
add_filter( 'the_content', function ( $content ) {
	if ( ! is_singular( array( 'place', 'post' ) ) || ! in_the_loop() || ! is_main_query() ) { return $content; }
	$ad = vb_ad( 'article' );
	if ( ! $ad ) { return $content; }
	$n     = max( 1, (int) get_theme_mod( 'vb_ads_paragraph', 3 ) );
	$parts = explode( '</p>', $content );
	if ( count( $parts ) <= $n + 1 ) { return $content; } // Too short – skip.
	$out  = '';
	$last = count( $parts ) - 1;
	foreach ( $parts as $i => $part ) {
		$out .= $part;
		if ( $i < $last ) { $out .= '</p>'; }
		if ( $i + 1 === $n && $i < $last ) { $out .= $ad; }
	}
	return $out;
}, 20 );
