<?php
/** Review searches use the card grid; other searches use the default list. */
if ( 'place' === get_query_var( 'post_type' ) ) {
	require __DIR__ . '/archive-place.php';
	return;
}
require __DIR__ . '/index.php';
