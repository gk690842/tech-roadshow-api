<?php
/** Single review. */
get_header();
while ( have_posts() ) : the_post();
	$vb_id    = get_the_ID();
	$vb_p     = vb_place_pillar( $vb_id );
	$vb_score = vb_score( $vb_id );
	$vb_areas = get_the_terms( $vb_id, 'vb_area' );
	$vb_area  = ( $vb_areas && ! is_wp_error( $vb_areas ) ) ? $vb_areas[0] : null;
	$vb_addr  = get_post_meta( $vb_id, '_vb_address', true );
	$vb_price = get_post_meta( $vb_id, '_vb_price', true );
	?>
	<div class="wrap">
		<div class="page-head">
			<?php vb_crumbs( $vb_p ); ?>
			<h1><?php the_title(); ?></h1>
			<p class="sub-meta">
				<?php if ( $vb_area ) : ?>📍 <a href="<?php echo esc_url( get_term_link( $vb_area ) ); ?>"><?php echo esc_html( $vb_area->name ); ?></a> · <?php endif; ?>
				Updated <?php echo esc_html( get_the_modified_date() ); ?>
			</p>
			<div class="score-strip">
				<?php if ( $vb_score ) : ?><div class="big"><?php echo esc_html( number_format( $vb_score, 1 ) ); ?><small>/10</small></div><?php endif; ?>
				<span class="chip"><?php echo esc_html( $vb_p['icon'] . ' ' . $vb_p['name'] ); ?></span>
				<?php if ( $vb_price ) : ?><span class="chip">💰 <?php echo esc_html( $vb_price ); ?></span><?php endif; ?>
				<?php $vb_badge = get_post_meta( $vb_id, '_vb_badge', true ); if ( $vb_badge ) : ?><span class="chip">✨ <?php echo esc_html( $vb_badge ); ?></span><?php endif; ?>
			</div>
		</div>
		<div class="single-grid">
			<article class="entry">
				<?php if ( get_post_meta( $vb_id, '_vb_sample', true ) ) : ?>
					<div class="sample-note">⚠️ <b>Sample data</b> for design preview. Remove before launch (Appearance → Vibeistic Sample Data).</div>
				<?php endif; ?>
				<div class="hero-img"><?php echo vb_place_image( $vb_id, 'vb-hero' ); // phpcs:ignore ?></div>
				<?php the_content(); ?>
				<div class="comments"><?php comments_template(); ?></div>
			</article>
			<aside>
				<div class="box">
					<h2>Our score</h2>
					<div class="bars">
						<?php foreach ( $vb_p['factors'] as $i => $label ) :
							$v = get_post_meta( $vb_id, '_vb_f' . ( $i + 1 ), true );
							if ( '' === $v ) { continue; } ?>
							<div class="bar"><span><?php echo esc_html( $label ); ?></span><i style="--w:<?php echo esc_attr( (float) $v * 10 ); ?>%"></i><b><?php echo esc_html( $v ); ?></b></div>
						<?php endforeach; ?>
					</div>
					<?php $vb_vd = get_post_meta( $vb_id, '_vb_verdict', true ); if ( $vb_vd ) : ?><div class="verdict" style="margin-top:10px">💬 <?php echo esc_html( $vb_vd ); ?></div><?php endif; ?>
				</div>
				<div class="box">
					<h2>Quick info</h2>
					<table class="info">
						<?php
						$vb_rows = array( 'price' => '💰 Price', 'timings' => '🕒 Timings', 'station' => '🚉 Nearest station', 'bestfor' => '👥 Best for', 'address' => '📍 Address' );
						foreach ( $vb_rows as $k => $label ) {
							$v = get_post_meta( $vb_id, '_vb_' . $k, true );
							if ( $v ) { echo '<tr><td>' . esc_html( $label ) . '</td><td>' . esc_html( $v ) . '</td></tr>'; }
						}
						?>
					</table>
				</div>
				<?php if ( $vb_addr ) : ?>
				<div class="box map">
					<h2>Location</h2>
					<iframe loading="lazy" title="Map of <?php the_title_attribute(); ?>" referrerpolicy="no-referrer-when-downgrade" src="https://maps.google.com/maps?q=<?php echo rawurlencode( get_the_title() . ', ' . $vb_addr ); ?>&z=15&output=embed"></iframe>
					<p style="margin-top:8px"><a href="https://www.google.com/maps/search/?api=1&query=<?php echo rawurlencode( get_the_title() . ', ' . $vb_addr ); ?>" target="_blank" rel="noopener">Open in Google Maps →</a></p>
				</div>
				<?php endif; ?>
				<?php echo vb_ad( 'display', 'vb-ad-side' ); // phpcs:ignore ?>
				<?php
				if ( $vb_p['term'] ) :
					$vb_rel = new WP_Query( array( 'post_type' => 'place', 'posts_per_page' => 4, 'post__not_in' => array( $vb_id ), 'no_found_rows' => true,
						'meta_key' => '_vb_score', 'orderby' => 'meta_value_num', 'order' => 'DESC',
						'tax_query' => array( array( 'taxonomy' => 'vb_pillar', 'field' => 'term_id', 'terms' => $vb_p['term']->term_id ) ) ) );
					if ( $vb_rel->have_posts() ) : ?>
					<div class="box related"><h2>More to <?php echo esc_html( strtolower( $vb_p['name'] ) ); ?></h2>
						<?php while ( $vb_rel->have_posts() ) : $vb_rel->the_post(); ?>
							<a href="<?php the_permalink(); ?>"><span><?php the_title(); ?></span><b><?php echo esc_html( number_format( vb_score( get_the_ID() ), 1 ) ); ?></b></a>
						<?php endwhile; ?>
					</div>
				<?php endif; wp_reset_postdata(); endif; ?>
			</aside>
		</div>
	</div>
<?php endwhile;
get_footer();
