<?php
/** Review card – homepage, archives, search. */
$vb_id    = get_the_ID();
$vb_p     = vb_place_pillar( $vb_id );
$vb_score = vb_score( $vb_id );
$vb_badge = get_post_meta( $vb_id, '_vb_badge', true );
$vb_areas = get_the_terms( $vb_id, 'vb_area' );
$vb_area  = ( $vb_areas && ! is_wp_error( $vb_areas ) ) ? $vb_areas[0]->name : '';
$vb_inner = ( $vb_badge ? '<span class="badge">' . esc_html( $vb_badge ) . '</span>' : '' )
	. '<span class="pill">' . esc_html( $vb_p['icon'] . ' ' . $vb_p['name'] ) . '</span>'
	. ( $vb_score ? '<span class="score">' . esc_html( number_format( $vb_score, 1 ) ) . '</span>' : '' );
?>
<article class="card" data-cat="<?php echo esc_attr( $vb_p['slug'] ); ?>">
	<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php echo vb_place_image( $vb_id, 'vb-card', $vb_inner ); // phpcs:ignore -- escaped inside ?></a>
	<div class="card-body">
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<?php if ( $vb_area ) : ?><div class="loc">📍 <?php echo esc_html( $vb_area ); ?></div><?php endif; ?>
		<div class="bars">
			<?php foreach ( $vb_p['factors'] as $i => $label ) :
				$v = get_post_meta( $vb_id, '_vb_f' . ( $i + 1 ), true );
				if ( '' === $v ) { continue; } ?>
				<div class="bar"><span><?php echo esc_html( $label ); ?></span><i style="--w:<?php echo esc_attr( (float) $v * 10 ); ?>%"></i><b><?php echo esc_html( $v ); ?></b></div>
			<?php endforeach; ?>
		</div>
		<?php $vb_verdict = get_post_meta( $vb_id, '_vb_verdict', true ); if ( $vb_verdict ) : ?>
			<div class="verdict">💬 <?php echo esc_html( $vb_verdict ); ?></div>
		<?php endif; ?>
		<div class="meta"><span><?php echo esc_html( get_post_meta( $vb_id, '_vb_price', true ) ); ?></span><a href="<?php the_permalink(); ?>">Read review →</a></div>
	</div>
</article>
