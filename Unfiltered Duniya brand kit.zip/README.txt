UNFILTERED DUNIYA - BRAND KIT (Concept 4: Filter Struck)

PROFILE PHOTO (Instagram + Facebook): 01_profile_photo_dark_1080.png
  Alternates: 02 (yellow), 03 (light). 04 = 3000px high-res for print/merch.
FACEBOOK COVER: 05_facebook_cover_1640x624.png
LOGOS (transparent):
  06 white  -> on dark / photo backgrounds
  07 black  -> on light backgrounds
  08 full logo (UD + UNFILTERED DUNIYA), white
  09 / 10 UD mark only, white / black
AGENT LOGO: logo.png -> copy to ~/ufd-agent/assets/logo.png
REELS WATERMARK: 11_watermark_reels_white_60pct.png
STORY HIGHLIGHT COVERS: 12_highlight_*.png
BRAND GUIDE (colours, fonts, rules): 13_brand_guide.png
Colours: Ink Black #111111 · Filter Yellow #FFC83D · White #FFFFFF · Strike Grey #7A7A7A
Font: Outfit (free on Google Fonts)
