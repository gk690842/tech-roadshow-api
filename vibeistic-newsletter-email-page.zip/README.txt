1. Copy src/pages/newsletter-email.astro into vibeistic-astro/src/pages/
2. In astro.config.mjs add '/newsletter-email' to the PRIVATE list (keeps it out of the sitemap).
   In public/robots.txt add:  Disallow: /newsletter-email/
3. npm run build → Commit → Push.
4. Open https://vibeistic.in/newsletter-email/
