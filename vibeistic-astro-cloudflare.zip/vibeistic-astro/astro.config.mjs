// @ts-check
import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

// Change "site" if your main domain is different.
export default defineConfig({
  site: 'https://vibeistic.in',
  output: 'static',
  integrations: [sitemap({ filter: (page) => !page.includes('/admin') })],
});
