# Vibeistic – Astro site for Cloudflare

Six ways to know a city: **Eat · Sip · Travel · Pray · Play · Stay**

A fast static site built with **Astro**, hosted free on **Cloudflare Workers**, with a free
browser-based editor (**Sveltia CMS**) at `/admin/` for writing reviews — no code needed day to day.

```
You write a review in /admin  →  saved to GitHub  →  Cloudflare rebuilds  →  live in ~1–2 min
```

---

## What's inside

| Path | What it is |
|---|---|
| `src/config.ts` | **Site settings**: name, hero text, contact email, newsletter URL, **AdSense**, the six pillars |
| `src/content/reviews/` | One Markdown file per review (12 SAMPLE reviews included) |
| `src/content/posts/` | Stories, trails and "best of" lists (1 sample story) |
| `src/content/pages/` | About, How We Rate, Contact, Privacy Policy, Disclaimer |
| `src/pages/` | Page templates (homepage, pillars, areas, reviews, stories, 404, ads.txt) |
| `src/styles/global.css` | All styling; brand colours at the top |
| `public/admin/` | The editor (Sveltia CMS) and its settings (`config.yml`) |
| `public/uploads/` | Photos you upload through the editor |
| `public/brand/` | Logo, icon and favicon files |
| `wrangler.jsonc` | Cloudflare settings |

### Website addresses (created automatically)

| URL | Page |
|---|---|
| `/` | Homepage |
| `/reviews/` | All reviews, with search, area and pillar filters (`?q=thali&area=dadar`) |
| `/explore/eat/` … `/explore/stay/` | One pillar |
| `/area/dadar/` | One area (created from the "Area" you type in each review) |
| `/review/rajwadi-rasoi/` | One review (score, quick info, map, related) |
| `/stories/`, `/stories/<name>/` | Stories and trails |
| `/about/`, `/contact/`, … | Pages |
| `/sitemap-index.xml`, `/robots.txt`, `/ads.txt` | For Google |

---

## STEP 1 — Install the tools (one time, ~20 min)

Use a **personal computer** (company laptops may need IT approval to install software).

1. **Node.js 22 LTS** – https://nodejs.org (choose the LTS installer)
2. **Git** – https://git-scm.com (default options are fine)
3. **GitHub account** – https://github.com (sign up with your Vibeistic Gmail)
4. *(Optional)* **GitHub Desktop** – https://desktop.github.com (lets you avoid typing git commands)
5. *(Optional)* **VS Code** – https://code.visualstudio.com (to edit files)

Check in PowerShell:
```
node -v      # should show v22.x
git --version
```

## STEP 2 — Run the site on your computer

```
cd path\to\vibeistic-astro
npm install
npm run dev
```
Open **http://localhost:4321** — the full site with sample data. Dashed boxes show where ads will go
(they only appear on your computer, never on the live site).

Stop with `Ctrl + C`. To test the final build: `npm run build` then `npm run preview`.

## STEP 3 — Put the code on GitHub

**With GitHub Desktop:** File → Add local repository → choose the folder → "create a repository" →
name it `vibeistic` → Publish repository (Private is fine).

**Or with commands:**
```
git init
git add .
git commit -m "Vibeistic first version"
git branch -M main
git remote add origin https://github.com/YOUR-GITHUB-USERNAME/vibeistic.git
git push -u origin main
```
(First create an empty repo named `vibeistic` at https://github.com/new — no README.)

## STEP 4 — Connect the editor to your repo

Open `public/admin/config.yml` and change:
```
repo: YOUR-GITHUB-USERNAME/vibeistic
```
Save, commit and push.

## STEP 5 — Deploy on Cloudflare (free)

1. Sign up at https://dash.cloudflare.com (use the same Vibeistic Gmail, turn on 2FA).
2. **Workers & Pages → Create → Import a repository** → connect GitHub → choose `vibeistic`.
3. Settings:
   - **Build command:** `npm run build`
   - **Deploy command:** `npx wrangler deploy`
   - Leave the rest as default → **Deploy**.
4. After ~1–2 minutes you get a free address like `https://vibeistic.<your-name>.workers.dev`.
   Open it and check every page, also on your phone.

From now on **every push to GitHub (including every save in the editor) redeploys automatically.**

> Cloudflare's screens change from time to time. If a label differs, look for "Connect to Git" /
> "Import repository" under Workers & Pages.

## STEP 6 — Connect your domains

### vibeistic.in (main site)
1. Cloudflare dashboard → **Add a domain** → `vibeistic.in` → choose the **Free** plan.
2. Cloudflare shows **two nameservers** (e.g. `xxx.ns.cloudflare.com`).
3. At your domain registrar (Hostinger / GoDaddy / etc.) → domain → **Nameservers → Change → Custom** →
   paste the two Cloudflare nameservers → Save. Wait until Cloudflare says "Active" (minutes to 24 h).
4. **Workers & Pages → vibeistic → Settings → Domains & Routes → Add → Custom domain** →
   add `vibeistic.in`, then add `www.vibeistic.in`.
   HTTPS certificates are created automatically.

### vibeistic.com → redirect to vibeistic.in
1. Add `vibeistic.com` to Cloudflare the same way (Free plan, change nameservers).
2. In the vibeistic.com zone → **DNS → Add record**: Type `A`, Name `@`, IPv4 `192.0.2.1`, **Proxied (orange cloud) ON**.
   Add another: Type `A`, Name `www`, IPv4 `192.0.2.1`, Proxied ON.
   (This placeholder address is never reached; Cloudflare redirects first.)
3. **Rules → Redirect Rules → Create rule**:
   - When: *All incoming requests*
   - Then: **Dynamic**, expression `concat("https://vibeistic.in", http.request.uri.path)`
   - Status code **301**, tick **Preserve query string** → Deploy.
4. Test: `https://vibeistic.com/explore/eat/` should open `https://vibeistic.in/explore/eat/`.

## STEP 7 — Log in to the editor

Open **https://vibeistic.in/admin/** (or your workers.dev address + `/admin/`).

**Easiest: sign in with a GitHub token**
1. GitHub → Settings → Developer settings → **Personal access tokens → Fine-grained tokens → Generate new token**.
2. Repository access: **Only select repositories → vibeistic**.
3. Permissions → Repository → **Contents: Read and write** → Generate. Copy the token.
4. On `/admin/` choose **Sign in with Token** and paste it. Treat the token like a password; set an expiry and renew it.

**Optional: "Sign in with GitHub" button** – deploy Sveltia's free authenticator to Cloudflare
(https://github.com/sveltia/sveltia-cms-auth, has a one-click deploy), then add its URL as
`base_url:` in `public/admin/config.yml`.

**Offline editing on your computer:** run `npm run dev`, open http://localhost:4321/admin/ in Chrome or Edge →
**Work with Local Repository** → select the project folder. Then commit and push.

> The editor's buttons may be named slightly differently in newer Sveltia versions — see https://github.com/sveltia/sveltia-cms.

## STEP 8 — Daily use: add a review

1. `/admin/` → **Reviews → New Review**.
2. Fill in: Place name, Pillar, Area (same spelling every time), 3 scores, verdict, price, station,
   timings, Best for, Address, Main photo, and write your experience.
3. **Publish/Save**. The site updates in ~1–2 minutes.

- **Photos:** compress first (WebP or JPG, under ~200 KB, about 1600 px wide). Big photos slow the site.
- **Videos:** upload to YouTube, then in the review add:
  `<iframe src="https://www.youtube.com/embed/VIDEO_ID" title="Video" allowfullscreen></iframe>`
  (Do not upload big video files to the site.)
- **Hide a review without deleting:** tick **Draft**.
- **Homepage featured story:** tick **Feature on homepage** in a Story.
- **New area page:** just type a new Area name in a review — the page `/area/<name>/` is created automatically.

## STEP 9 — Before launch checklist

- [ ] Delete the 12 sample reviews (Reviews → open each one with "Sample data" ticked → Delete), or delete the files in `src/content/reviews/`
- [ ] Fill in or delete the sample story (`western-line-food-trail`)
- [ ] Edit About, Privacy Policy (review the template carefully) and Disclaimer
- [ ] Check `src/config.ts` (contact email, social links)
- [ ] Test on your phone: ☰ menu, bottom bar, swipeable tabs, search, a review page
- [ ] Google Search Console → add `vibeistic.in` → submit `https://vibeistic.in/sitemap-index.xml`
- [ ] Bing Webmaster Tools (can import from Search Console)
- [ ] Optional: Cloudflare **Web Analytics** (free, no cookie banner needed) – Analytics & Logs → Web Analytics

## STEP 10 — AdSense (later)

Edit `src/config.ts`:
1. Set `client: 'ca-pub-XXXXXXXXXXXXXXXX'` → push. This adds Google's verification tag and creates `/ads.txt`.
   Now add the site in AdSense and request review.
2. After approval set `enabled: true` → push. Turn on Auto ads in AdSense if you want.
3. Optional fixed units: create an **In-article** and a **Display** ad unit in AdSense and paste their slot IDs
   into `slotArticle` and `slotDisplay`. They appear after paragraph 3 of reviews/stories, in the review sidebar,
   on the homepage and on lists. Pages marked "Hide ads" (Contact, Privacy, Disclaimer) and the 404 page load no ads.
4. Never click your own ads. If you get visitors from the EU/UK, turn on Google's consent message in AdSense → Privacy & messaging.

## Change the design

| Change | Where |
|---|---|
| Brand colours | `src/styles/global.css` → `:root` at the top |
| Pillar names, Hindi labels, icons, colours, score factors | `src/config.ts` → `PILLARS` (also update the pillar labels in `public/admin/config.yml`) |
| Hero headline and text | `src/config.ts` → `SITE` |
| Homepage sections | `src/pages/index.astro` |
| Review page layout | `src/pages/review/[slug].astro` |
| Header / footer / mobile menu | `src/layouts/Layout.astro` |
| Logo icon | `src/components/Brand.astro` and `public/brand/` |

After any change: commit and push → Cloudflare redeploys.

## Costs

| Item | Cost |
|---|---|
| Cloudflare hosting (Workers Free: static pages are free and unlimited) | ₹0 |
| GitHub (private repo) | ₹0 |
| Sveltia CMS editor | ₹0 |
| vibeistic.in + vibeistic.com | Only the yearly domain fees |

## Troubleshooting

| Problem | Fix |
|---|---|
| Cloudflare build fails | Open the build log. Most often a review has a missing required field (title, pillar, area, scores, published) or a score above 10. Fix the file and push again. |
| `npm install` fails | Check `node -v` is 20.3 or newer (22 LTS recommended). |
| Editor says "repository not found" | Check `repo:` in `public/admin/config.yml` and that your token has access to that repo. |
| Photo not showing | It must be in `public/uploads/`, and the review's image field must start with `/uploads/`. |
| New review not live | Wait 2 minutes; check Workers & Pages → vibeistic → Deployments. |
| Area page split in two (e.g. "Dadar" and "dadar west") | Use exactly the same Area spelling in every review. |
| Domain not working | Check that Cloudflare shows the domain as **Active** and the custom domain is added to the Worker. |

---
Reader star-ratings/comments are not included in v1 (a static site has no database).
They can be added later with a Cloudflare Worker + D1 database.
