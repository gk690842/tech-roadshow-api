/* Vibeistic – small, dependency-free scripts */
(function () {
  'use strict';

  /* ---------- Mobile drawer ---------- */
  var drawer = document.getElementById('vb-drawer');
  var lastFocus = null;
  function setExpanded(v) {
    document.querySelectorAll('[data-drawer-open]').forEach(function (b) { b.setAttribute('aria-expanded', v ? 'true' : 'false'); });
  }
  function openDrawer(focusSearch) {
    if (!drawer) return;
    lastFocus = document.activeElement;
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
    setExpanded(true);
    var target = focusSearch ? drawer.querySelector('input[type=search]') : drawer.querySelector('[data-drawer-close].icon-btn');
    if (target) setTimeout(function () { target.focus(); }, 250);
  }
  function closeDrawer() {
    if (!drawer || !drawer.classList.contains('open')) return;
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('no-scroll');
    setExpanded(false);
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  document.addEventListener('click', function (e) {
    var o = e.target.closest('[data-drawer-open]');
    if (o) { e.preventDefault(); openDrawer(o.hasAttribute('data-focus-search')); return; }
    if (e.target.closest('[data-drawer-close]')) { e.preventDefault(); closeDrawer(); }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeDrawer(); });
  window.addEventListener('resize', function () { if (window.innerWidth > 960) closeDrawer(); });

  /* ---------- Card filtering (tabs + search + area) ---------- */
  document.querySelectorAll('[data-grid]').forEach(function (grid) {
    var scope = grid.closest('.wrap') || document;
    var tabs = scope.querySelector('[data-tabs]');
    var form = scope.querySelector('[data-filters]');
    var qInput = form && form.querySelector('[name=q]');
    var areaSel = form && form.querySelector('[name=area]');
    var countEl = scope.querySelector('[data-count]');
    var noRes = grid.querySelector('[data-noresults]');
    var cards = Array.prototype.slice.call(grid.querySelectorAll('.card'));
    var pillar = 'all';

    // Read ?q= and ?area= from the URL (homepage search sends them here)
    if (form) {
      var params = new URLSearchParams(location.search);
      if (qInput && params.get('q')) qInput.value = params.get('q').slice(0, 80);
      if (areaSel && params.get('area')) areaSel.value = params.get('area');
    }

    function apply() {
      var q = qInput ? qInput.value.trim().toLowerCase() : '';
      var words = q ? q.split(/\s+/) : [];
      var area = areaSel ? areaSel.value : '';
      var shown = 0;
      cards.forEach(function (c) {
        var text = c.getAttribute('data-search') || '';
        var ok = (pillar === 'all' || c.getAttribute('data-cat') === pillar) &&
                 (!area || c.getAttribute('data-area') === area) &&
                 words.every(function (w) { return text.indexOf(w) > -1; });
        c.hidden = !ok;
        if (ok) shown++;
      });
      if (noRes) noRes.hidden = shown > 0;
      else {
        var em = grid.querySelector('.vb-empty');
        if (!shown && !em) { em = document.createElement('div'); em.className = 'empty vb-empty'; em.textContent = 'No reviews here yet — coming soon!'; grid.appendChild(em); }
        if (em) em.hidden = shown > 0;
      }
      if (countEl) countEl.textContent = shown + (shown === 1 ? ' place found' : ' places found');
      if (form && history.replaceState) {
        var u = new URL(location.href);
        q ? u.searchParams.set('q', q) : u.searchParams.delete('q');
        area ? u.searchParams.set('area', area) : u.searchParams.delete('area');
        history.replaceState(null, '', u);
      }
    }

    if (tabs) tabs.addEventListener('click', function (e) {
      var btn = e.target.closest('.tab');
      if (!btn) return;
      tabs.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      btn.classList.add('active'); btn.setAttribute('aria-selected', 'true');
      if (btn.scrollIntoView) btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      pillar = btn.getAttribute('data-filter') || 'all';
      apply();
    });
    if (qInput) qInput.addEventListener('input', apply);
    if (areaSel) areaSel.addEventListener('change', apply);
    if (form || tabs) apply();
  });

  /* ---------- Move the in-article ad after paragraph 3 ---------- */
  document.querySelectorAll('[data-entry]').forEach(function (entry) {
    var ad = entry.querySelector('[data-ad=article]');
    if (!ad) return;
    var paras = Array.prototype.filter.call(entry.children, function (el) { return el.tagName === 'P'; });
    if (paras.length >= 4) paras[2].after(ad);
  });

  /* ---------- Newsletter placeholder (until a URL is set in src/config.ts) ---------- */
  document.querySelectorAll('form[data-demo]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      f.innerHTML = '<b>Thanks! (Connect your newsletter tool in src/config.ts)</b>';
    });
  });
})();
