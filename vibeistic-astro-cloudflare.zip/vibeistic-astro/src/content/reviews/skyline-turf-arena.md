---
title: "Skyline Turf Arena"
pillar: play
area: "Malad"
badge: "Rooftop turf"
price: "₹1,200 / hour"
verdict: "5-a-side football and box cricket. Book 2 days ahead."
address: "Malad, Mumbai"
station: "Malad ([ ] min walk)"
timings: "[Add timings]"
bestFor: "[Add]"
score1: 8.7
score2: 8.0
score3: 8.4
image: ""
published: 2026-10-10
sample: true
draft: false
---

**SAMPLE CONTENT.** Replace this with your own first-hand review.

## My Experience

Write the story of your visit here: when you went, what you tried or used, and how long you waited.

Add 3–4 of your own photos between paragraphs. Readers trust real photos far more than stock images.

To add a YouTube video, paste its link on its own line using the editor's video/embed option, or add an iframe.

## Good to Know

- Best time to visit
- What to try or skip
- How to get there from the station

Finish with who this place suits best and whether you would go again.
