---
title: "Harbour View Residency"
pillar: stay
area: "Colaba"
badge: "Sea view"
price: "₹6,500 / night"
verdict: "Walk to Gateway of India; ask for an upper-floor room."
address: "Colaba, Mumbai"
station: "Colaba ([ ] min walk)"
timings: "[Add timings]"
bestFor: "[Add]"
score1: 8.4
score2: 9.5
score3: 7.2
image: ""
published: 2026-10-11
sample: true
draft: false
---

**SAMPLE CONTENT.** Replace this with your own first-hand review.

## My Experience

Write the story of your visit here: when you went, what you tried or used, and how long you waited.

Add 3–4 of your own photos between paragraphs. Readers trust real photos far more than stock images.

To add a YouTube video, paste its link on its own line using the editor's video/embed option, or add an iframe.

## Good to Know

- Best time to visit
- What to try or skip
- How to get there from the station

Finish with who this place suits best and whether you would go again.
