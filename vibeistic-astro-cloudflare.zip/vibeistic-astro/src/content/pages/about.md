---
title: "About Vibeistic"
description: "Who we are and why we started Vibeistic."
---

Vibeistic is an independent guide to six ways of knowing a city: **Eat, Sip, Travel, Pray, Play and Stay**.

Every place on this site is visited in person. We pay our own bills, take our own photos and score each place on what actually matters for it.

[Write a few lines about yourself here: who you are, why you started Vibeistic and which areas you cover.]
