---
title: "How We Rate"
description: "Our scoring method and review promise."
---

## Our promise

- **We pay our own bills.** No free meals or stays in exchange for ratings.
- **Only our own photos.** No stock images, no copied reviews.
- **Sponsored content is always labelled.**
- **We re-check our top picks**, and the "Updated" date means a real re-check.

## The scores

Each place gets three scores out of 10, and the overall score is their average.

| Pillar | What we score |
|---|---|
| Eat | Taste · Value · Hygiene |
| Sip | Brew · Vibe · Value |
| Travel | Experience · Access · Value |
| Pray | Darshan · Cleanliness · Calm |
| Play | Facilities · Crowd · Value |
| Stay | Room · Location · Value |
