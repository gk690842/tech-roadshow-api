---
title: "Disclaimer"
description: "Important notes about our reviews."
noAds: true
---

Reviews on Vibeistic are personal opinions based on our own visits on specific dates. Prices, timings, menus and facilities can change, so please check with the place before you go.

We are not responsible for any experience you have at the places we review. Any sponsored content or affiliate link is clearly labelled.
