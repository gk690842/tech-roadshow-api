---
title: "Privacy Policy"
description: "How Vibeistic handles your information."
noAds: true
---

*Starter template — review it carefully and adapt it before launch. This is not legal advice.*

**Last updated:** [date]

## What we collect

We do not ask you to create an account. If you email us, we receive your email address and message. If you subscribe to our newsletter, our email provider stores your email address.

## Cookies and advertising

This site may show ads served by Google AdSense. Google and its partners use cookies to serve ads based on your visits to this and other websites. You can opt out of personalised advertising at Google's Ads Settings page. Third-party vendors may also use cookies.

## Analytics

[If you add Google Analytics or Cloudflare Web Analytics, describe it here.]

## Embedded content

Pages may include embedded YouTube videos and Google Maps, which follow Google's own privacy policy.

## Contact

Questions: [hello@vibeistic.in](mailto:hello@vibeistic.in)
