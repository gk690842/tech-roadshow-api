---
title: "Contact"
description: "Get in touch with Vibeistic."
noAds: true
---

Suggest a place, report something that has changed, or say hello:

**Email:** [hello@vibeistic.in](mailto:hello@vibeistic.in)

**Instagram:** [@vibeistic](https://instagram.com/vibeistic)

We read every message. Businesses: we do not accept payment or free services in exchange for reviews.
