import { ADS } from '../config';

// Builds /ads.txt from your Publisher ID in src/config.ts
export function GET() {
  const body = ADS.client
    ? `google.com, ${ADS.client.replace(/^ca-/, '')}, DIRECT, f08c47fec0942fa0\n`
    : '# Add your AdSense Publisher ID in src/config.ts\n';
  return new Response(body, { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
}
