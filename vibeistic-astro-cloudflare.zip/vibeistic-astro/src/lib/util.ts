import { getCollection, type CollectionEntry } from 'astro:content';

export type Review = CollectionEntry<'reviews'>;
export type Post = CollectionEntry<'posts'>;

export const slugify = (s: string) =>
  s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export const scoreOf = (r: Review) =>
  Math.round(((r.data.score1 + r.data.score2 + r.data.score3) / 3) * 10) / 10;

export const byScore = (a: Review, b: Review) => scoreOf(b) - scoreOf(a);

export async function getReviews() {
  const all = await getCollection('reviews', ({ data }) => !data.draft);
  return all.sort(byScore);
}

export async function getPosts() {
  const all = await getCollection('posts', ({ data }) => !data.draft);
  return all.sort((a, b) => b.data.published.valueOf() - a.data.published.valueOf());
}

export function areasOf(reviews: Review[]) {
  const map = new Map<string, { name: string; slug: string; count: number }>();
  for (const r of reviews) {
    const slug = slugify(r.data.area);
    const a = map.get(slug) ?? { name: r.data.area, slug, count: 0 };
    a.count++;
    map.set(slug, a);
  }
  return [...map.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

export const fmtDate = (d: Date) =>
  d.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
