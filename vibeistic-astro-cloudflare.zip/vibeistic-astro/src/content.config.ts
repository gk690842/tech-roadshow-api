import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const score = z.coerce.number().min(0).max(10);

const reviews = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/reviews' }),
  schema: z.object({
    title: z.string(),
    pillar: z.enum(['eat', 'sip', 'travel', 'pray', 'play', 'stay']),
    area: z.string(),
    badge: z.string().optional().default(''),
    price: z.string().optional().default(''),
    verdict: z.string().optional().default(''),
    address: z.string().optional().default(''),
    station: z.string().optional().default(''),
    timings: z.string().optional().default(''),
    bestFor: z.string().optional().default(''),
    score1: score,
    score2: score,
    score3: score,
    image: z.string().optional().default(''),
    imageAlt: z.string().optional().default(''),
    published: z.coerce.date(),
    updated: z.coerce.date().optional(),
    sample: z.boolean().optional().default(false),
    draft: z.boolean().optional().default(false),
  }),
});

const posts = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/posts' }),
  schema: z.object({
    title: z.string(),
    excerpt: z.string().optional().default(''),
    category: z.string().optional().default('Story'),
    image: z.string().optional().default(''),
    published: z.coerce.date(),
    updated: z.coerce.date().optional(),
    featured: z.boolean().optional().default(false),
    sample: z.boolean().optional().default(false),
    draft: z.boolean().optional().default(false),
  }),
});

const pages = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/pages' }),
  schema: z.object({
    title: z.string(),
    description: z.string().optional().default(''),
    noAds: z.boolean().optional().default(false),
  }),
});

export const collections = { reviews, posts, pages };
