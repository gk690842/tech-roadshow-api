VIBEISTIC – Vibe Tribe page refresh + "Join Us" links

1. GitHub Desktop → Fetch origin → Pull origin.
2. Replace:
     src/pages/vibe-tribe/index.astro   (new compact, interactive Join Us page)
     src/layouts/Layout.astro           (Join Us in header, mobile menu, bottom bar, footer; keeps Google Analytics)
3. Add new file:
     src/components/JoinTribe.astro     (homepage banner)
4. Homepage: open src/pages/index.astro and make 2 edits
   a) In the import lines at the top (between the --- lines), add:
        import JoinTribe from '../components/JoinTribe.astro';
   b) Paste this line just ABOVE the "<!-- AREAS -->" section (or below "Top rated"):
        <JoinTribe />
5. Check: grep -n 'expor\*\|Goog\*' src/layouts/Layout.astro    (should print nothing)
6. npm run build  → "Complete!"  →  Commit → Push origin.
