---
title: "Gandarree Veg Treat, Nigdi (Pradhikaran), Pune"
pillar: eat
area: "Nigdi, Pune"
seoTitle: "Gandarree Veg Treat Nigdi: Menu, Price & Review"
seoDescription: "Gandarree Veg Treat, Sector 32A Pradhikaran Nigdi: pure-veg family restaurant with AC and outdoor seating, free parking and fair prices. What we paid."
quickAnswer: "**Gandarree Veg Treat** is a **pure-vegetarian family restaurant** at **Dhruv Siddhi, Sector 32A, Pradhikaran Nigdi** (Ravet side), about **1.6 km from Akurdi station**. It's open about **8 am–11 pm**, with **AC indoor** and **outdoor seating**, and **free parking in front** for bikes and cars. We paid **₹404** for **aloo paratha, pav bhaji and a dosa**, which is **cheaper than most Pune restaurants**."
badge: "Pure veg · budget-friendly"
price: "₹404 for 3 dishes (our bill)"
verdict: "Good-quality, fairly priced pure-veg food with AC and open-air seating and free parking. A dependable everyday family restaurant."
extraInfo:
  - { icon: "🕒", label: "Hours", value: "About 8 am – 11 pm" }
  - { icon: "🥬", label: "Food", value: "Pure veg: North & South Indian, Chinese, street food" }
  - { icon: "❄️", label: "Seating", value: "AC indoor + outdoor (AC prices may be slightly higher)" }
  - { icon: "🚗", label: "Parking", value: "Free in front, bikes & cars" }
  - { icon: "👨‍👩‍👧", label: "Family", value: "Separate family-friendly seating" }
  - { icon: "🚉", label: "Station", value: "Akurdi, about 1.6 km" }
timings: ""
station: "Akurdi railway station about 1.6 km"
bestFor: "Families, breakfast, budget meals"
address: "Shop No. 2–4, 32/A LC-2, Dhruv Siddhi A, Sector 32A, Pradhikaran Nigdi, Pimpri-Chinchwad, Pune 412101"
score1: 8.0
score2: 9.0
score3: 8.0
image: "/uploads/gandarree-veg-treat-nigdi-outdoor.webp"
imageAlt: "Outdoor and AC seating at Gandarree Veg Treat, Pradhikaran Nigdi"
gallery:
  - { image: "/uploads/gandarree-veg-treat-nigdi-pav-bhaji.webp", caption: "Pav bhaji, dosa and aloo paratha", alt: "Pav bhaji, dosa and aloo paratha at Gandarree Veg Treat Nigdi" }
galleryAfterParagraph: 3
instagramUrl: ""
youtubeUrl: ""
faqs:
  - { question: "What are Gandarree Veg Treat timings?", answer: "About 8 am to 11 pm, seven days a week." }
  - { question: "How much does it cost?", answer: "We paid ₹404 for an aloo paratha, pav bhaji and a dosa, which is lower than many Pune restaurants." }
  - { question: "Is it pure vegetarian?", answer: "Yes, it is a pure-vegetarian restaurant." }
  - { question: "Is there AC seating?", answer: "Yes, there's AC indoor seating and open-air outdoor seating. AC-section prices may be slightly higher." }
  - { question: "Is parking free?", answer: "Yes. Bikes and cars can park for free in front of the restaurant." }
  - { question: "Where is it?", answer: "Dhruv Siddhi A, Sector 32A, Pradhikaran Nigdi, Pimpri-Chinchwad, about 1.6 km from Akurdi railway station." }
published: 2026-11-12
sample: false
draft: true
---

Not every meal needs to be an occasion. Sometimes you just want **good, honest vegetarian food at a fair price**, in a comfortable place with your family. That's exactly what **Gandarree Veg Treat** in Pradhikaran Nigdi delivers.

## My experience

Gandarree is a **pure-vegetarian restaurant** with **two seating options**:

- **AC indoor seating** — cool and comfortable
- **Outdoor seating** — open-air and pleasant in the evenings

**Parking is free** right in front of the restaurant for both **bikes and cars**, which makes it easy for family visits.

The place is **good for family time**, relaxed and unfussy. **Prices are a bit lower than most restaurants in Pune**, and the **food quality was good**.

## What we ordered

| Dish | Notes |
|---|---|
| Aloo paratha | Filling and well spiced |
| Pav bhaji | Buttery and satisfying |
| Dosa | Crisp, with chutney and sambar |
| **Total** | **₹404** |

## What else people order

Regulars and online reviews often mention:

- **Paneer makhanwala** and **masala papad**
- **Manchow soup** and **veg crispy**
- **Dragon roll** and **veg platters**
- **Tandoori starters** like paneer tikka and cheese seekh kebab

The menu spans **North Indian, South Indian, Chinese and street food**, and **breakfast** is served from the morning.

## Good to know

Online reviews praise the **taste, reasonable prices and friendly atmosphere**, while a few mention **slow service at busy times**. Prices in the **AC section can be slightly higher** than outdoors.

## Timings

| Day | Time |
|---|---|
| All days | About 8:00 am – 11:00 pm |

## How to reach

The restaurant is at **Dhruv Siddhi A, Sector 32A, Pradhikaran Nigdi** (on the Ravet side), about **1.6 km from Akurdi railway station**. Don't confuse it with the similarly named *Gayatrree Veg Treat* in Sector 27.

## Who it suits

- **Families** looking for an affordable pure-veg meal
- **Breakfast** seekers — open from 8 am
- **Anyone** who prefers outdoor seating on pleasant evenings

## Our verdict

Gandarree Veg Treat is a **dependable, budget-friendly pure-veg restaurant** with **good food, AC and outdoor seating, and free parking**. It's not fancy, and that's the point: **honest food at an honest price**. Nearby in Nigdi, try [Cafe Buddy's Espresso](/review/cafe-buddys-espresso-brts-nigdi-pune/) for coffee afterwards.
