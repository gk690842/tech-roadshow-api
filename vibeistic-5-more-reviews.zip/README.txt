VIBEISTIC – 5 new reviews (all draft: true)
  Ganesh Bhel (Ravet) · Rio Kitchen & Bar (Hinjewadi) · Greenleaf Resort restaurant (Ganpatipule)
  O'Bake Café (Kiwale–Ravet) · Gandarree Veg Treat (Nigdi)

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy FILES (not folders):
     src/content/reviews/*.md  → vibeistic-astro/src/content/reviews/
     public/uploads/*.webp     → vibeistic-astro/public/uploads/
3. Check: Ganesh Bhel address = the outlet you visit (Ganesh Bhel has more than one Ravet counter).
4. npm run dev → http://localhost:4321/review/<file-name-without-.md>/
5. Replace placeholder photos (same file names; WebP ~1600 px, <200 KB; main photos LANDSCAPE).
6. Untick Draft → request indexing in Search Console.
