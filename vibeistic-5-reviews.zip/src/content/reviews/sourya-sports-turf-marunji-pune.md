---
title: "Sourya Sports Turf, Marunji"
pillar: play
area: "Marunji, Pune"
seoTitle: "Sourya Sports Turf Marunji: Cricket Price & Review"
seoDescription: "Sourya Sports, Marunji near Life Republic: a large, airy new box-cricket turf with good lights. Price per hour, two routes, what to carry and booking tips."
quickAnswer: "**Sourya Sports** in **Marunji, near Life Republic** (Hinjewadi side of Pune) is a **new, underrated box-cricket turf** with a **bigger playing area than most turfs**, **open sides with great airflow** and **new floodlights**. Cricket costs **₹[add price] per hour**. **Bats are provided**; **bring your own tennis ball** or buy one there. You can reach it through **Marunji village road (congested)** or a **rough shortcut from the Life Republic road**."
badge: "Big, airy turf"
price: "Cricket ₹[add price] per hour"
verdict: "An underrated gem: bigger than most turfs, airy, well lit and in great condition. The approach roads are the only downside."
extraInfo:
  - { icon: "🏏", label: "Cricket", value: "₹[add price] per hour" }
  - { icon: "🏏", label: "Equipment", value: "Bats provided; bring or buy tennis ball" }
  - { icon: "💡", label: "Lights", value: "New floodlights, good for night games" }
  - { icon: "🌬️", label: "Feel", value: "Open sides, excellent airflow" }
  - { icon: "🛣️", label: "Route 1", value: "Marunji village road (congested)" }
  - { icon: "🛣️", label: "Route 2", value: "Via Life Republic road (unpaved stretch)" }
  - { icon: "📞", label: "Booking", value: "[add phone / booking app]" }
timings: ""
station: "Marunji, near Life Republic township (Hinjewadi side)"
bestFor: "Friends' cricket games, office teams, night matches"
address: "[Add exact address / Google Maps pin], Marunji, Pune 411057"
score1: 9.0
score2: 8.5
score3: 8.0
image: "/uploads/sourya-sports-marunji-turf.webp"
imageAlt: "Sourya Sports box cricket turf in Marunji, Pune, under floodlights"
gallery:
  - { image: "/uploads/sourya-sports-marunji-cricket.webp", caption: "Box cricket on the big turf", alt: "Friends playing box cricket at Sourya Sports turf Marunji" }
galleryAfterParagraph: 3
instagramUrl: ""
youtubeUrl: ""
faqs:
  - { question: "How much does Sourya Sports Marunji charge for cricket?", answer: "Cricket costs ₹[add price] per hour. Rates may differ for weekends, nights and peak hours, so confirm when booking." }
  - { question: "Do they provide cricket equipment?", answer: "Bats are provided. Bring your own tennis ball, or buy one at the turf." }
  - { question: "How do I reach the turf?", answer: "Through the Marunji village road, which can be congested, or a shortcut from the Life Republic road that has an unpaved stretch. Use a Google Maps pin for the exact route." }
  - { question: "Is it good for night games?", answer: "Yes. The floodlights are new and the turf is well lit." }
  - { question: "Why is it better than other turfs nearby?", answer: "The playing area is bigger than most box turfs, the sides are open with good airflow, and everything is new." }
published: 2026-11-10
sample: false
draft: true
---

Marunji and the Hinjewadi belt have plenty of box-cricket turfs, but **Sourya Sports** is one of the most **underrated**. If you can get past the approach road, you'll find one of the best playing surfaces in the area.

## My experience

The first thing you notice is the **size**. The **turf area is bigger than most turfs** around Hinjewadi and Wakad, so there's real room to run and field.

It's also **open and airy**. With **open sides and great airflow**, you don't feel trapped in a hot cage, which makes a big difference in long evening games.

Because it's a **new turf**, the **lighting and surface are in very good condition**. Night games are bright and clear.

## Equipment

- **Bats are provided**
- **Bring your own tennis ball**, or **buy one there**
- Wear proper sports shoes for the turf

## Price

| Sport | Price |
|---|---|
| Box cricket | ₹[add price] per hour |

Rates often differ on **weekends, nights and peak hours**, so confirm when you book.

## How to reach (two routes)

1. **Marunji village road** — the main way in, but it goes through a **congested road**, so leave extra time at peak hours.
2. **From the Life Republic road** — a shortcut from inside the **Life Republic** side. Part of it is **not properly constructed**, so drive slowly, especially in the rains.

Save the turf's **Google Maps pin** and share it with your team before the game.

## Tips

- **Book in advance** for weekend evenings.
- **Carry a tennis ball** and water.
- **Use the Life Republic route** if the village road is jammed, but avoid it in heavy rain.

## Who it suits

- **Friends and office teams** looking for a bigger turf
- **Night-match regulars**, thanks to the new lights
- **Players tired of cramped, stuffy turfs**

## Our verdict

Sourya Sports is **an underrated gem**: a **big, airy, well-lit turf in excellent condition**. The roads to it need patience, but once you're on the turf, it's one of the best games you'll have around Marunji.
