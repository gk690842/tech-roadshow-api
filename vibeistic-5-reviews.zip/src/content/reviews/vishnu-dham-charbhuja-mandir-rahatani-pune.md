---
title: "Shri Charbhuja Mandir Vishnu Dham, Rahatani, Pune"
pillar: pray
area: "Rahatani, Pune"
seoTitle: "Vishnu Dham Temple Pune: Timings & Parking"
seoDescription: "Shri Charbhuja Mandir Vishnu Dham, Rahatani BRTS Road, Pune: white-marble Vishnu temple, darshan timings, parking charges, crowd tips and how to reach."
quickAnswer: "**Shri Charbhuja Mandir Vishnu Dham** is a **white Makrana-marble temple of Lord Vishnu** in the **Charbhuja (four-armed) form**, at **Kavde Nagar, Rahatani, on the Kalewadi–Rahatani BRTS road** in Pimpri-Chinchwad. It is open roughly **7 am–1 pm and 5–9 pm**, **entry is free**, and nearby **private parking costs about ₹20 for bikes and ₹30 for cars**. Darshan takes **about 10 minutes**, but the peaceful mandap makes you want to **sit for hours**."
badge: "Peaceful marble temple"
price: "Free entry · parking about ₹20 bike / ₹30 car (what we paid)"
verdict: "A small, spotless white-marble Vishnu temple with plenty of space to sit and meditate. Quick darshan, calm on weekdays, and a lovely place to switch off."
extraInfo:
  - { icon: "🕒", label: "Morning", value: "About 7 am – 1 pm" }
  - { icon: "🌙", label: "Evening", value: "About 5 – 9 pm" }
  - { icon: "🪔", label: "Aarti", value: "Around 7:30 am and 7:30 pm" }
  - { icon: "🚗", label: "Parking", value: "Private, about ₹20 bike / ₹30 car" }
  - { icon: "👟", label: "Shoes", value: "Racks at the gate (at your own risk)" }
  - { icon: "👥", label: "Crowd", value: "Busy on weekends, calm on weekdays" }
  - { icon: "⏱️", label: "Darshan time", value: "About 10 minutes" }
  - { icon: "📞", label: "Phone", value: "+91 99605 22121" }
timings: ""
station: "Pimpri railway station about 2.5 km · on the Kalewadi–Rahatani BRTS road"
bestFor: "Families, seniors, meditation and quiet prayer"
address: "Kavde Nagar, Rahatani, near Kalewadi Phata, Pimpri-Chinchwad, Pune 411017"
score1: 9.0
score2: 9.0
score3: 9.5
image: "/uploads/vishnu-dham-rahatani-temple.webp"
imageAlt: "White marble Shri Charbhuja Mandir Vishnu Dham temple in Rahatani, Pune"
gallery:
  - { image: "/uploads/vishnu-dham-rahatani-mandap.webp", caption: "Plenty of space to sit and meditate", alt: "Sitting area inside Vishnu Dham temple Rahatani" }
  - { image: "/uploads/vishnu-dham-rahatani-night.webp", caption: "The temple lit up in the evening", alt: "Vishnu Dham Charbhuja temple Pune illuminated at night" }
galleryAfterParagraph: 4
instagramUrl: ""
youtubeUrl: ""
faqs:
  - { question: "What are Vishnu Dham temple Pune timings?", answer: "About 7 am to 1 pm and 5 pm to 9 pm. Some listings show slightly longer hours (6:30 am and up to 10 pm), and timings change on Janmashtami and Ekadashi, so confirm before a late visit." }
  - { question: "Where is Vishnu Dham temple?", answer: "At Kavde Nagar, Rahatani, near Kalewadi Phata on the Kalewadi–Rahatani BRTS road in Pimpri-Chinchwad, Pune 411017." }
  - { question: "Which god is worshipped here?", answer: "Lord Vishnu in his Charbhuja (four-armed) form, known as Charbhuja Nath. The temple is modelled on the Garhbor Charbhuja temple in Rajasthan." }
  - { question: "Is there parking?", answer: "There is private parking near the temple. We paid about ₹20 for a bike and ₹30 for a car." }
  - { question: "Is there an entry fee?", answer: "No, entry and darshan are free." }
  - { question: "When is it least crowded?", answer: "Weekdays are calm. Weekends and festivals such as Janmashtami, Ram Navami and Ekadashi are busier." }
published: 2026-11-10
sample: false
draft: true
---

In the middle of busy Pimpri-Chinchwad, there's a temple where everything slows down the moment you step inside. **Shri Charbhuja Mandir Vishnu Dham** in Rahatani is small, beautiful and deeply peaceful, and it has become one of my favourite places to sit quietly in Pune.

## Why Vishnu Dham is so special

The temple is dedicated to **Lord Vishnu in his Charbhuja (four-armed) form**, worshipped as **Charbhuja Nath**. The black-stone murti is beautifully dressed with flowers and ornaments.

It was built by Pune's **Rajasthani (Mewari) community** as a tribute to the ancient **Garhbor Charbhuja Nath temple in Rajasthan's Rajsamand district**, so people often call it *Pune's mini Rajasthan*. The whole temple is carved from **white Makrana marble**, with fine traditional carving and elephant statues at the entrance. At night, the lit-up marble is a sight in itself.

Visiting Vishnu is believed to bring **peace, protection and prosperity**, and the temple's calm makes it a natural place for **prayer and dhyan (meditation)**.

## My experience

**Parking:** there's **private parking near the temple**. We paid about **₹20 for a bike and ₹30 for a car**.

At the **main gate there are proper shoe racks**. Keep in mind that **no one is responsible if shoes are misplaced or lost**, so avoid wearing expensive footwear. After entering, you can **wash your feet and hands**.

Inside, there are **dedicated places to sit**. In front of the **Vishnu ji murti there is ample space to sit**, meditate and pray. Nobody rushes you; **you can sit for hours** and simply continue your prayer.

Because the temple isn't very big, you can **pray at every murti** and finish the whole **darshan in about 10 minutes**, then collect **prasad**. Most people, like us, end up staying much longer, just to stay connected with the divine energy.

## Timings

| Session | Time |
|---|---|
| Morning | About 7:00 am – 1:00 pm |
| Evening | About 5:00 pm – 9:00 pm |
| Aarti | Around 7:30 am and 7:30 pm |

The temple closes in the afternoon. Some listings show slightly longer hours, and timings change on **Janmashtami** and **Ekadashi**, so call **+91 99605 22121** to confirm before a late visit.

## Crowd and best time to go

- **Weekdays:** calm, the best time for meditation.
- **Weekends:** crowded, especially in the evening.
- **Festivals** (Janmashtami, Ram Navami, Ekadashi): very busy but beautifully decorated.

**My tip:** go on a weekday evening around 6:30 pm, sit for a while and stay for the evening aarti.

## How to reach

The temple is at **Kavde Nagar, Rahatani, near Kalewadi Phata**, on the **Kalewadi–Rahatani BRTS road**. It is about **2.5 km from Pimpri railway station**, and easy to reach by bike, car, auto or PMPML bus along the BRTS corridor.

## Who it suits

- **Families and seniors** — calm space, short darshan
- **Anyone who meditates** — ample sitting space in front of the murti
- **Rajasthani and Marwari families** in Pune — a little piece of home

## Our verdict

Vishnu Dham is proof that a temple doesn't need to be huge to be powerful. **Spotless white marble, a beautiful Charbhuja murti, quick darshan and space to sit for as long as you like.** Go on a weekday, switch off your phone and give yourself an hour.
