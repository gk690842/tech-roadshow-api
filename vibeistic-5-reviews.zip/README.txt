VIBEISTIC – 5 new reviews (all draft: true)
  Ganpatipule Temple · Vishnu Dham (Rahatani) · Supreme Fitness (Ravet) · Vee Resort (Mahabaleshwar) · Sourya Sports (Marunji)

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy FILES (not folders):
     src/content/reviews/*.md  → vibeistic-astro/src/content/reviews/
     public/uploads/*.webp     → vibeistic-astro/public/uploads/
3. Fill in the [add …] gaps:
     sourya-sports-turf-marunji-pune.md → price, phone/booking app, address
     supreme-fitness-ravet-pune.md      → confirm building name and floor in "address"
4. npm run dev → check each page at http://localhost:4321/review/<file-name-without-.md>/
5. Replace placeholder photos (same file names, WebP, ~1600 px, <200 KB, main photos LANDSCAPE).
6. Paste your Instagram Reel / YouTube Short links in /admin if you have them.
7. Untick Draft → request indexing in Search Console for each page.
