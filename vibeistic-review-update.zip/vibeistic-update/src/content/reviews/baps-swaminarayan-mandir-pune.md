---
title: "BAPS Shri Swaminarayan Mandir, Pune"
pillar: pray
area: "Narhe, Pune"
seoTitle: "BAPS Mandir Pune: Timings, Aarti & Free Parking"
seoDescription: "BAPS Shri Swaminarayan Mandir, Narhe, Pune: darshan 7:15 am–12 pm & 4–8:15 pm, arti times, free parking, dress code and best time to visit. First-hand guide."
quickAnswer: "BAPS Shri Swaminarayan Mandir in Narhe, Pune is open daily with **free entry**. Darshan is from **7:15 am to 12 pm and 4 pm to 8:15 pm**, and parking is **free and spacious**. For the calmest visit, go on a **weekday evening** and stay for the Sandhya Arti."
badge: "Free parking"
price: "Free entry"
verdict: "A calm, spotless stone mandir with free parking, clean washrooms and plenty of places to sit. Go on a weekday evening for the Sandhya Arti."
extraInfo:
  - { icon: "🚗", label: "Parking", value: "Free, spacious" }
  - { icon: "🕒", label: "Darshan", value: "7:15 am–12 pm & 4–8:15 pm" }
  - { icon: "👥", label: "Crowd", value: "Light on weekdays, medium–heavy on weekends" }
  - { icon: "🚻", label: "Facilities", value: "Washrooms, hand & foot taps, seating" }
timings: ""
station: ""
bestFor: "Families, seniors, a peaceful break"
address: "Narhe–Ambegaon Road, off Mumbai–Bengaluru Highway, Narhe, Pune 411046"
score1: 9.0
score2: 9.5
score3: 9.5
image: ""
imageAlt: "BAPS Shri Swaminarayan Mandir Pune, hand-carved pink stone mandir at Narhe"
# Add your photos here (upload them in the editor, or put them in public/uploads):
#   - { image: "/uploads/baps-pune-parking.webp", caption: "Free parking area", alt: "Free parking at BAPS Mandir Pune" }
gallery: []
galleryAfterParagraph: 4
faqs:
  - { question: "Is there an entry fee?", answer: "No, entry is free and open to everyone." }
  - { question: "Is parking free?", answer: "Yes, there is a large parking area with no parking charges." }
  - { question: "What is the best time to visit?", answer: "Weekday evenings, so you can attend the Sandhya Arti with less crowd." }
  - { question: "Is there a dress code?", answer: "Yes. Cover your shoulders and knees; wraps are available at the entrance." }
  - { question: "Are photos allowed?", answer: "Not inside the mandir near the murtis, but you can take photos in the outer areas." }
  - { question: "Are washrooms available?", answer: "Yes, clean washrooms and hand-and-foot washing taps are at the start of the campus." }
published: 2026-11-15
sample: false
draft: true
---

If you've ever felt that the city is too loud and your head is too full, this is the place I would send you. I have visited the BAPS Shri Swaminarayan Mandir several times, and every time I leave lighter than I came in.

## My experience

The first thing you notice is how easy everything is. The parking area is large and **completely free** — no attendant asking for ₹20, no hunting for a spot. Right at the start of the campus there are **clean washrooms** and a row of **taps to wash your hands and feet** before you go in, which I genuinely appreciated after a dusty ride.

Once you walk towards the mandir, the noise of the highway simply disappears. The hand-carved pink stone, the open courtyards and the quiet volunteers create a calm that is hard to find anywhere else in Pune. There are **plenty of places to sit** — on the steps, in the shaded areas and around the lawns — so nobody rushes you.

Being present for the **arti** is the highlight. When the lamps are waved and the prayers begin, you feel something settle inside you. I can only describe it as feeling blessed. Even if you are not religious, sit through one arti; it is a beautiful, peaceful experience.

## Timings (check before you go)

| What | Time |
|---|---|
| Campus open | 7:00 am – 8:30 pm |
| Morning darshan | 7:15 am – 12:00 pm |
| Evening darshan | 4:00 pm – 8:15 pm |
| Mangala Arti | 6:00 am |
| Shangar Arti | 7:30 am |
| Rajbhog Arti | 11:15 am |
| Sandhya Arti | around 7:00 pm |
| Shayan Arti | around 8:30 pm |

Darshan pauses for the thal (food offering) in the late morning and early evening. Timings can change on festival days, so call the mandir or check the official BAPS Pune website before a special visit.

## Who you will have darshan of

- **Bhagwan Swaminarayan** with **Aksharbrahman Gunatitanand Swami**
- **Shri Ghanshyam Maharaj** (the childhood form of Bhagwan Swaminarayan)
- **Shri Harikrishna Maharaj**
- **Bhagwan Shri Krishna** and **Shri Radhaji**

In the **Abhishek Mandapam**, anyone can take part in the abhishek (ritual bathing) of the murti of **Neelkanth Varni**, the young yogi form of Bhagwan Swaminarayan. It takes about 10–15 minutes and is free.

## Crowd: when to go

- **Weekdays:** light crowd — the best time for quiet darshan and sitting peacefully.
- **Weekends:** medium to heavy crowd, especially in the evening.
- **Festivals** (Diwali, Annakut, Janmashtami and others): very busy but beautifully decorated.

**My tip:** reach around 6:15–6:30 pm on a weekday, have darshan, sit for a while and stay for the evening arti.

## Things to know before you visit

- **Dress code:** shoulders and knees must be covered. Wraps are provided at the entrance if needed.
- **Shoes:** removed and kept at the shoe house before entering.
- **Bags:** keep backpacks and belongings in your vehicle.
- **Photography:** not allowed inside the mandir near the murtis. You can take photos in the outer areas.
- **Phones:** keep them on silent and put away inside.
- **Arti seating:** men and women sit in separate sections during the arti.
- **Food:** the Premvati vegetarian food stall and the BAPS book stall are on campus.

## How to reach

The mandir is on the **Narhe–Ambegaon Road, close to the Mumbai–Bengaluru Highway** in south Pune. Road connectivity is good, and it is easiest to reach by **car, bike or cab**. Use Google Maps with "BAPS Shri Swaminarayan Mandir Pune" for the exact route from your area.

## Who it suits

- **Families and seniors** — easy parking, washrooms at the entrance and plenty of seating
- **Anyone feeling stressed** — the calm here is real
- **First-time visitors to a BAPS mandir** — volunteers are welcoming and happy to guide you

## Our verdict

BAPS Shri Swaminarayan Mandir is one of the most peaceful places I know in Pune. Free entry, free parking, clean facilities and a genuinely calming atmosphere make it easy to recommend. Go on a weekday evening, stay for the arti and give yourself time to simply sit.
