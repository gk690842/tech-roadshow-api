VIBEISTIC – review page update (Quick answer, extra Quick info rows, photo row, FAQs, SEO title)

1. GitHub Desktop → Fetch origin → Pull origin (get the editor's latest changes first).
2. Copy these files into your project, replacing the old ones:
     src/content.config.ts
     src/pages/review/[slug].astro
     public/admin/config.yml   ← FIRST copy your existing "repo:" line into this new file!
     src/content/reviews/baps-swaminarayan-mandir-pune.md (new review, saved as Draft)
3. Open src/styles/global.css, scroll to the very end and paste the contents of
   src/styles/ADD-TO-END-OF-global.css. (Do not copy that file itself into the project.)
4. Terminal:  cd ~/Desktop/Projects/vibeistic-astro   then   npm run build   (must end with "Complete!")
   Optional: npm run dev → http://localhost:4321/review/baps-swaminarayan-mandir-pune/
   (Draft reviews are hidden. To preview locally, set draft: false temporarily – don't commit that.)
5. GitHub Desktop → Summary "Review extras" → Commit to main → Push origin.
6. Reload /admin/ (Cmd+Shift+R). The new fields appear in Reviews.
