AKASH MISAL HOUSE, KHED – review (draft: true)

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy FILES (not folders):
     src/content/reviews/akash-misal-house-khed-rajgurunagar.md → vibeistic-astro/src/content/reviews/
     public/uploads/*.webp (6 photos)                          → vibeistic-astro/public/uploads/
3. npm run dev → http://localhost:4321/review/akash-misal-house-khed-rajgurunagar/
4. Check the Samruddhi / Shirdi wording and scores, then untick Draft in /admin and request indexing in Search Console.
