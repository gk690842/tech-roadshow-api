---
title: "Akash Misal House & Pure Veg Restaurant, Khed (Rajgurunagar)"
pillar: eat
area: "Khed (Rajgurunagar), Pune"
seoTitle: "Akash Misal House Khed: Menu, Prices & Review"
seoDescription: "Akash Misal House & Pure Veg, Khed Ghat, Rajgurunagar on the Pune–Nashik highway: free parking, clean washrooms, misal, dosa and paneer. Prices and timings."
quickAnswer: "**Akash Misal House & Pure Veg Restaurant** is a huge, family-friendly pure-veg highway stop **near Khed Ghat on the Pune–Nashik highway (NH 50), Rajgurunagar**, open **about 6:30 am to 11:30 pm**. **Parking is free** and guards help you park, washrooms are **clean**, and the menu runs from **misal and kothimbir vadi to dosa, poha and North Indian meals**. We paid **₹341 for a two-person breakfast** and **₹551 for dinner**. Perfect if you are driving from Pune towards **Shirdi, Nashik or Bhimashankar**."
badge: "Pure veg · free parking"
price: "₹341 breakfast · ₹551 dinner (for two)"
verdict: "A big, spotless, well-run pure-veg halt with free parking, quick ordering and food that is genuinely good. Expect a crowd, and order early on busy mornings."
extraInfo:
  - { icon: "🕒", label: "Hours", value: "About 6:30 am – 11:30 pm, every day" }
  - { icon: "🌱", label: "Food", value: "Pure veg: misal, dosa, poha, North Indian, Chinese" }
  - { icon: "🚗", label: "Parking", value: "Free, large lot with guards helping" }
  - { icon: "🚻", label: "Washrooms", value: "Clean, cleaned continuously" }
  - { icon: "👨‍👩‍👧", label: "Family", value: "Kids' play area, spacious seating" }
  - { icon: "💳", label: "Payment", value: "Cards and UPI accepted" }
  - { icon: "📞", label: "Phone", value: "+91 98810 88066" }
timings: ""
station: "On NH 50 (Pune–Nashik highway), near Khed Ghat, Rajgurunagar"
bestFor: "Road trips, families, breakfast stops on the way to Shirdi, Nashik and Bhimashankar"
address: "Near Khed Ghat, National Highway 50 (Pune–Nashik Highway), Rajgurunagar, Pune district, Maharashtra 410505"
score1: 8.5
score2: 8.5
score3: 9.0
image: "/uploads/akash-misal-house-khed-dining-hall.webp"
imageAlt: "Huge dining hall at Akash Misal House near Khed Ghat with hanging lamps and planters between the tables"
gallery:
  - { image: "/uploads/akash-misal-house-khed-entrance-sign.webp", caption: "The Akash Misal House sign, 'Since 1972'", alt: "Akash Misal House entrance sign with vertical garden of potted plants, Since 1972" }
  - { image: "/uploads/akash-misal-house-khed-kande-pohe.webp", caption: "Kande pohe with sev and peanuts", alt: "Plate of kande pohe topped with sev, peanuts and coriander at Akash Misal House Khed" }
  - { image: "/uploads/akash-misal-house-khed-masala-dosa.webp", caption: "Crisp masala dosa with sambar and coconut chutney", alt: "Masala dosa with sambar and coconut chutney at Akash Misal House Rajgurunagar" }
  - { image: "/uploads/akash-misal-house-khed-paneer-butter-naan.webp", caption: "Dinner: paneer sabji and butter naan", alt: "Paneer sabji with onions and butter naan at Akash Misal House Khed" }
  - { image: "/uploads/akash-misal-house-khed-walkway.webp", caption: "The plant-lined walkway to the restaurant", alt: "Glass-roofed walkway lined with plants leading to Akash Misal House restaurant" }
galleryAfterParagraph: 4
instagramUrl: ""
youtubeUrl: ""
faqs:
  - { question: "Where is Akash Misal House near Khed Ghat?", answer: "On the Pune–Nashik Highway (NH 50) near Khed Ghat, Rajgurunagar, Pune district 410505. It is on the highway side, so you can see the busy parking lot from the road." }
  - { question: "What are Akash Misal House Khed timings?", answer: "Listings show about 6:30 am to 11:30 pm every day; some show a 7 am opening. We were there at 8 am for breakfast and again for dinner." }
  - { question: "Is the restaurant pure vegetarian?", answer: "Yes. The whole menu is vegetarian, with misal, South Indian, Maharashtrian, North Indian and Chinese dishes." }
  - { question: "Is parking free?", answer: "Yes, there is a large free parking lot, and guards help guide cars into spaces." }
  - { question: "How much does a meal cost?", answer: "We paid ₹341 for a two-person breakfast (two teas, masala dosa, poha and more) and ₹551 for a dinner of paneer sabji, butter naan and tea. Listings put a meal at about ₹200–400 per person." }
  - { question: "What should I order?", answer: "The misal is the famous dish, and reviewers also love kothimbir vadi, palak cheese dosa and jalebi with rabdi. We enjoyed the masala dosa, poha, paneer sabji and butter naan." }
  - { question: "Is it good for families with kids?", answer: "Yes. It is spacious, has a kids' play area, and offers a kids' menu according to listings." }
  - { question: "Is it a good stop on the way to Shirdi or the Samruddhi Expressway?", answer: "Yes. It sits on the Pune–Nashik route used to reach Shirdi, and we found it much easier to get a good, clean meal here than further along the road." }
published: 2026-11-20
sample: false
draft: true
---

If you drive from Pune towards Nashik, Shirdi or Bhimashankar, you will notice one place long before you reach it: a parking lot full of cars beside the highway. That is **Akash Misal House**, and the crowd is a good sign. We stopped here twice on the same trip, once for breakfast on the way out and once for dinner on the way back.

## Why this is the stop on the Pune–Nashik route

The restaurant stands **near Khed Ghat on NH 50**, and even from the road it looks like a place worth sitting down in. The sign at the entrance says **"Since 1972"**, and it has grown into a large complex with the main restaurant, a plant-lined walkway and a few small shops around it, so it feels like a proper highway halt rather than a roadside dhaba.

## My experience

We reached around **8 in the morning**. There were dozens of cars already parked, and a few **guards helped us park**, completely **free of charge**.

Before eating we wanted to freshen up. The **washrooms were clean**, and a cleaning staff member was **continuously cleaning** them while we were there. That alone made a good first impression.

Inside, the hall is **enormous**. Warm hanging lamps, large orange ducts overhead and big planters between the tables give it a bright, modern feel, and there were **around 50 staff members**, from waiters and order takers to reception, so ordering was quick. The entrance area was fully packed, but we found a good table further inside, and the **vibe was lively without being chaotic**.

## What we ordered

### Breakfast (about 8 am)

| Dish | Notes |
|---|---|
| Masala dosa | Thin, crisp and golden, with sambar and coconut chutney |
| Kande pohe | Fluffy, topped with sev, peanuts and fresh coriander |
| Tea (2) | Hot and strong |
| More items | Added to the order |
| **Total (2 people)** | **₹341** |

### Dinner (on the way back)

| Dish | Notes |
|---|---|
| Paneer sabji | Rich, well-spiced gravy with onions and pickle on the side |
| Butter naan | Soft, with a buttery char |
| Tea | To finish |
| **Total (2 people)** | **₹551** |

The **taste was good**, **cleanliness was top-notch** and **hygiene was clearly maintained**, both mornings and evenings. We loved the paneer sabji and butter naan at dinner enough that we would order them again.

## Misal and other favourites

The restaurant is named after its **misal**, and diners often call it among the best on the highway. Other dishes that regulars recommend are **kothimbir vadi**, **palak cheese dosa** and **jalebi with rabdi**. We didn't try the misal this time, so that's our reason to return.

## Price

| Meal | Our bill (2 people) |
|---|---|
| Breakfast | ₹341 |
| Dinner | ₹551 |
| Typical range per person (listings) | ₹200 – ₹400 |

For a large, clean restaurant on a highway, the prices are fair.

## Timings

| Day | Time |
|---|---|
| All days | About 6:30 am – 11:30 pm |

Some listings show a 7 am opening. Call **+91 98810 88066** if you need to confirm an early start.

## Good to know

Online reviews are mostly positive, with a few honest complaints:

- **Weekends and festivals get crowded**, and some visitors mention slower service at peak hours.
- **A few guests** found some dishes only average (for example the thali or pav bhaji) and one older review mentions a cold dosa.
- **Strong incense smell** in places, according to one visitor.

We had no such problems on a weekday morning and a normal evening. If you are in a hurry, order early and head to the counter if needed.

## For families and groups

The place is **family-friendly**: spacious seating, a kids' play area, and a kids' menu according to listings. Visitors also mention a life-sized elephant statue, a bullock cart display and a tulsi vrindavan, which kids enjoy.

## How to reach

Akash Misal House is on the **Pune–Nashik Highway (NH 50)**, **near Khed Ghat, Rajgurunagar**. Look for the large lot beside the highway. It is a natural stop when driving from Pune towards **Nashik, Shirdi or Bhimashankar**, and we found it a relief to get a clean, dependable meal here, because good places to eat were harder to find after this stretch.

## Who it suits

- **Road-trippers and families** who want a clean, quick, pure-veg meal
- **Breakfast stops** before a long drive
- **Groups** that need parking and space

## Our verdict

Akash Misal House gets the highway stop right: **free parking, spotless washrooms, a huge and cheerful hall, fast ordering and food that tastes good**. Pay ₹341 for breakfast or ₹551 for dinner and you will leave satisfied. Next time, we're ordering the misal.
