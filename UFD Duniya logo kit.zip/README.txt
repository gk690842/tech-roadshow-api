UFD DUNIYA - LOGO KIT
Instagram profile photo : 01_profile_photo_gold_1080.png  (main)
Facebook profile photo  : 01_profile_photo_gold_1080.png  (same, for consistency)
Facebook cover          : 04_facebook_cover_1640x624.png
Alternate profile looks : 02 (ivory), 03 (black on gold)
Agent watermark         : copy 05_logo_horizontal_gold_transparent.png to ~/ufd-agent/assets/logo.png
White watermark (reels) : 08_watermark_white_transparent_400.png
Story highlight covers  : 09_highlight_*.png
Brand colours & fonts   : 10_brand_sheet_1500x700.png
SVG files (01, 05, 07)  : scalable versions for printing / merch
