VIBEISTIC – Cafe Bambini (Pawna Lake) + Avaia The Beach Escape (Ratnagiri)

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy the FILES (not folders):
     src/content/reviews/*.md   → vibeistic-astro/src/content/reviews/
     public/uploads/*.webp      → vibeistic-astro/public/uploads/
3. Avaia review: fill in the two ₹[add …] amounts in the "What we paid" table.
4. Check locally: npm run dev
     http://localhost:4321/review/cafe-bambini-pawna-lake/
     http://localhost:4321/review/avaia-the-beach-escape-ratnagiri/
5. Replace placeholder photos with your own using the SAME file names (WebP, ~1600px, <200 KB).
   Main photos must be LANDSCAPE. Keep draft: true until the real photos are in.

  cafe-bambini-pawna-lake-view.webp             main – café + lake view
  cafe-bambini-pawna-garden.webp                gallery – garden / flowers
  cafe-bambini-pawna-veg-platter.webp           gallery – veg platter & tea
  cafe-bambini-pawna-panna-cotta.webp           gallery – panna cotta
  avaia-beach-escape-ratnagiri-pool-cottages.webp  main – pool + cottages
  avaia-beach-escape-ratnagiri-cottage.webp     gallery – your cottage
  avaia-beach-escape-ratnagiri-beach.webp       gallery – beach & benches
  avaia-beach-escape-ratnagiri-bonfire.webp     gallery – bonfire / celebration
