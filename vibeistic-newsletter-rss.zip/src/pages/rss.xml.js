// Vibeistic – RSS feed of published reviews (used by Mailchimp to email subscribers)
// Lives at https://vibeistic.in/rss.xml  ·  Drafts are never included.
import rss from '@astrojs/rss';
import { SITE, PILLARS } from '../config';
import { getReviews } from '../lib/util';

const esc = (s) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export async function GET(context) {
  const site = context.site || SITE.url;
  const all = (await getReviews()).filter((r) => !r.data.draft && !r.data.sample);
  const reviews = all
    .sort((a, b) => b.data.published.valueOf() - a.data.published.valueOf())
    .slice(0, 30);

  return rss({
    title: 'Vibeistic – New reviews',
    description: SITE.description,
    site,
    xmlns: { media: 'http://search.yahoo.com/mrss/' },
    items: reviews.map((r) => {
      const d = r.data;
      const url = new URL(`/review/${r.id}/`, site).href;
      const img = d.image ? new URL(d.image, site).href : '';
      const p = PILLARS[d.pillar];
      const score = Math.round(((d.score1 + d.score2 + d.score3) / 3) * 10) / 10;
      const summary = d.seoDescription || d.verdict || `Our honest review of ${d.title} in ${d.area}.`;
      return {
        title: d.title,
        link: url,
        pubDate: d.published,
        description: summary,
        categories: [p ? p.name : d.pillar, d.area],
        content:
          (img ? `<p><a href="${url}"><img src="${img}" alt="${esc(d.imageAlt || d.title)}" width="560" style="max-width:100%;height:auto;border-radius:12px"></a></p>` : '') +
          `<p><b>${esc(p ? p.icon + ' ' + p.name : '')} · ${esc(d.area)} · ${score}/10</b></p>` +
          `<p>${esc(summary)}</p>`,
        customData: img ? `<media:content url="${img}" medium="image" />` : '',
      };
    }),
  });
}
