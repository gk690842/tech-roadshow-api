VIBEISTIC – email subscribers when a new review goes live

1. Copy src/pages/rss.xml.js into vibeistic-astro/src/pages/
2. Terminal:  npm install @astrojs/rss
3. npm run build  →  check dist/rss.xml exists  →  Commit (include package.json + package-lock.json) → Push
4. Open https://vibeistic.in/rss.xml – your published reviews should be listed (no drafts).
5. Mailchimp: use mailchimp/email-body.html as the email content (see chat steps).
