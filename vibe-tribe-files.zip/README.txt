VIBEISTIC – Vibe Tribe page + "Join Us" links

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy into your project (replace when asked):
     src/pages/vibe-tribe.astro      (NEW page → https://vibeistic.in/vibe-tribe/)
     src/layouts/Layout.astro        (adds "Join Us" in header, mobile menu, bottom bar and footer)
3. Check:  grep -n 'expor\*\|Goog\*' src/layouts/Layout.astro src/pages/vibe-tribe.astro   (should print nothing)
4. npm run build → must end with "Complete!"
5. npm run dev → open http://localhost:4321/vibe-tribe/  (check on phone view too)
6. Commit "Add Vibe Tribe page" → Push origin.
7. Search Console → URL inspection → https://vibeistic.in/vibe-tribe/ → Request indexing.
