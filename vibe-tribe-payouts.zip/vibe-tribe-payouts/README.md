# Vibe Tribe payout tool (macOS)

Turns your **AdSense** and **Google Analytics 4** exports into:

| Output | Who it's for |
|---|---|
| `output/<cycle>/Payout_<cycle>.xlsx` – Summary, Pages, Contributors | You |
| `output/<cycle>/statements/<ID>_<name>_<cycle>.html` – one private statement per contributor (others' data hidden) | Each contributor |
| `output/Vibe_Tribe_Ledger.xlsx` – "All cycles" + one sheet per contributor with totals | You |
| `output/dashboard.html` – owner dashboard across all cycles | You |
| `data/ledger.csv` – the source of truth (carry-forward, paid status) | Tool |

> Keep this folder **outside** your website project (e.g. `~/Documents/vibe-tribe-payouts`). It contains private payment data – never push it to GitHub or Cloudflare.

---

## 1. One-time setup (Terminal)

```bash
cd ~/Documents/vibe-tribe-payouts
chmod +x run.sh
./run.sh dashboard          # creates .venv and installs openpyxl the first time
```
Needs Python 3 (already on your Mac with the Xcode Command Line Tools you installed for Git).

## 2. Try the demo (3 contributors A/B/C, 2 pages each, 60/70/50 % shares)

```bash
./run.sh run --cycle 2026-11 --adsense exports/sample/adsense_pages_2026-11.csv --ga exports/sample/ga4_pages_2026-11.csv
```
Then delete `data/ledger.csv` and the `output` folder before your real first run.

## 3. Fill in your contributors (manual, in Numbers or Excel – save as CSV)

**config/contributors.csv**

| contributor_id | name | email | upi_id | share_percent | active | notes |
|---|---|---|---|---|---|---|
| A | Riya Shah | riya@… | riya@upi | 60 | yes | agreed 40:60 by email on 12 Nov |

`share_percent` = **the contributor's** share (60 means they get 60 %, Vibeistic keeps 40 %).

**config/page_owners.csv** – one row per published contributor page

| page_path | contributor_id | page_title | share_percent_override |
|---|---|---|---|
| /review/cafe-bambini-pawna-lake/ | B | Cafe Bambini Pawna Lake | *(blank = use contributor's %)* |

Pages not listed here belong to Vibeistic (100 % yours).

**config/settings.json** – minimum payout (default ₹500), contact email, payout note.

## 4. Each cycle (monthly or quarterly)

**AdSense export**
1. adsense.google.com → **Reports** → **Pages** (or "URL channels"/"Pages" breakdown).
2. Set the date range to the cycle → **Download / Export → CSV**.
3. Save as `exports/adsense_2026-11.csv`.

**GA4 export (recommended – gives accurate page views)**
1. analytics.google.com → **Reports → Engagement → Pages and screens**.
2. Change the dimension to **Page path and screen class**, set the same date range.
3. Share (↗) → **Download File → Download CSV** → save as `exports/ga4_2026-11.csv`.

**Run**
```bash
./run.sh run --cycle 2026-11 --adsense exports/adsense_2026-11.csv --ga exports/ga4_2026-11.csv
```
Optional:
- `--received 1523.40` – the amount AdSense actually paid for the cycle. Page earnings are scaled to it (AdSense estimates vs finalised payment).
- `--method views` – if your AdSense export has no per-page earnings, revenue is split by each page's share of site views.
- Use `--cycle 2026-Q1` for quarterly cycles. Pick one style and stick to it.

The dashboard opens automatically.

## 5. Pay and record

1. Open `output/<cycle>/Payout_<cycle>.xlsx` → **Contributors** → pay everyone with status **Pending** by UPI/bank.
2. Record each payment:
   ```bash
   ./run.sh mark-paid --cycle 2026-11 --id A --ref UPI4471 --date 2026-12-05
   ```
3. Re-create the statements so they show "Paid" (keeps paid status):
   ```bash
   ./run.sh run --cycle 2026-11 --adsense exports/adsense_2026-11.csv --ga exports/ga4_2026-11.csv --force
   ```
4. Send each contributor **only their own** statement: open it in Safari → **File → Export as PDF** (or Print → Save as PDF) → email it from hello@vibeistic.in.

## How the maths works

```
page earnings      = AdSense earnings for that page  (× received ÷ estimated, if --received)
contributor share  = page earnings × contributor %
vibeistic share    = page earnings − contributor share
total due          = this cycle's share + brought forward
payout             = total due  if total due ≥ minimum payout,  else ₹0 and it carries forward
```

Example (demo data): A earns ₹500 on 2 pages × 60 % = ₹300; B ₹400 × 70 % = ₹280; C ₹200 × 50 % = ₹100. All are below ₹500, so they carry forward; next cycle A (₹600) and B (₹560) are paid, C carries ₹200.

## Privacy in statements
Other contributors' pages and numbers are **never written** into a contributor's statement – the ranking table shows them as blurred placeholders only. Each statement contains just that person's pages plus site totals.

## Safety
- Re-running a cycle replaces it; if any payment in it is marked **Paid**, the tool stops unless you add `--force` (paid status is kept).
- Back up `data/ledger.csv` (e.g. to iCloud Drive) after every cycle.
- Don't share screenshots of your AdSense account with contributors – share these statements instead. Check AdSense terms and talk to a CA about tax/TDS before larger payouts.

## Troubleshooting
| Message | Fix |
|---|---|
| `openpyxl is missing` | Use `./run.sh …` (it installs it), or `python3 -m pip install openpyxl` |
| `could not find … columns` | Your CSV headers differ – open it and check it has a Page/URL column and an Earnings column; send the header row for help |
| `⚠ … has no data in either export` | The `page_path` in page_owners.csv doesn't match the site path – copy it exactly from the GA4 export |
| `permission denied: ./run.sh` | `chmod +x run.sh` |
