#!/bin/bash
# Vibe Tribe payout tool – macOS helper.
# First time: chmod +x run.sh
# Usage:  ./run.sh run --cycle 2026-11 --adsense exports/adsense.csv --ga exports/ga4.csv
#         ./run.sh mark-paid --cycle 2026-11 --id A --ref UPI12345
#         ./run.sh dashboard
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "Setting up (first run only)…"
  python3 -m venv .venv
  ./.venv/bin/pip install --quiet --upgrade pip
  ./.venv/bin/pip install --quiet -r requirements.txt
fi
./.venv/bin/python vibe_payout.py "$@"
if [ "$1" = "run" ] || [ "$1" = "dashboard" ] || [ "$1" = "mark-paid" ]; then
  open output/dashboard.html 2>/dev/null || true
fi
