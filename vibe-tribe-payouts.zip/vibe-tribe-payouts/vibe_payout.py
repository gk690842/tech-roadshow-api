#!/usr/bin/env python3
"""
Vibe Tribe payout tool for Vibeistic (runs on macOS / any computer with Python 3.9+).

What it does
  1. Reads an AdSense "Pages" export (CSV) and a Google Analytics 4 "Pages and screens" export (CSV).
  2. Matches each page to its Vibe Tribe contributor (config/page_owners.csv).
  3. Applies each contributor's share (config/contributors.csv, with optional per-page override).
  4. Keeps a running ledger (data/ledger.csv) with carry-forward below the minimum payout.
  5. Writes, for the cycle:
       output/<cycle>/Payout_<cycle>.xlsx            – full owner workbook
       output/<cycle>/statements/<id>.html            – one private statement per contributor
       output/Vibe_Tribe_Ledger.xlsx                  – one sheet per contributor, all cycles
       output/dashboard.html                          – owner dashboard (all cycles)

Commands
  python3 vibe_payout.py run --cycle 2026-11 --adsense exports/adsense.csv --ga exports/ga4.csv
        [--received 1234.56]   amount actually received from AdSense for this cycle (scales estimates)
        [--method auto|adsense|views]
        [--force]              allow re-running a cycle that already has payments marked Paid
  python3 vibe_payout.py mark-paid --cycle 2026-11 --id A --ref UPI12345 [--date 2026-12-10]
  python3 vibe_payout.py dashboard        (rebuild ledger workbook + dashboard only)
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import html
import io
import json
import re
import sys
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("openpyxl is missing. Run:  python3 -m pip install openpyxl   (or use ./run.sh, which sets it up)")

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config"
DATA = ROOT / "data"
OUT = ROOT / "output"
LEDGER = DATA / "ledger.csv"

LEDGER_FIELDS = [
    "cycle", "contributor_id", "name", "pages", "page_views", "page_earnings",
    "share_percent", "cycle_share", "vibeistic_share", "brought_forward", "total_due",
    "payout", "carry_forward", "status", "paid_on", "reference", "site_views",
    "site_earnings", "generated_on",
]

VIOLET, CORAL, MANGO, INK = "5B2A86", "FF5E7E", "FFB238", "1D1730"


# --------------------------------------------------------------------------- helpers
def money(x: float) -> float:
    return round(float(x) + 1e-9, 2)


def to_num(v) -> float:
    if v is None:
        return 0.0
    s = str(v).strip().replace(",", "").replace("₹", "").replace("INR", "").replace("$", "")
    if s in ("", "-", "--"):
        return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def norm_path(p: str) -> str:
    """'https://www.vibeistic.in/Review/X?utm=1' -> '/review/x/'"""
    p = (p or "").strip().lower()
    p = re.sub(r"^[a-z]+://", "", p)
    p = re.sub(r"^(www\.)?[a-z0-9.-]+\.[a-z]{2,}(?=/|$)", "", p)
    p = p.split("?")[0].split("#")[0]
    if not p.startswith("/"):
        p = "/" + p
    if not p.endswith("/") and "." not in p.rsplit("/", 1)[-1]:
        p += "/"
    return p


def read_csv_flexible(path: Path) -> list[dict]:
    """Reads CSVs that may start with '#' comment lines or blank lines (GA4 style)."""
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    lines = [ln for ln in text.splitlines() if ln.strip() and not ln.lstrip().startswith("#")]
    if not lines:
        return []
    rows = list(csv.DictReader(io.StringIO("\n".join(lines))))
    # GA4 sometimes adds a "Grand total" or totals row – drop it.
    return [r for r in rows if not any(str(v).strip().lower() in ("grand total", "total", "totals") for v in list(r.values())[:1])]


def find_col(headers: list[str], *needles: str, avoid: tuple[str, ...] = ()) -> str | None:
    low = {h: h.lower() for h in headers if h}
    for n in needles:
        for h, l in low.items():
            if n in l and not any(a in l for a in avoid):
                return h
    return None


def load_settings() -> dict:
    s = {"site_name": "Vibeistic", "site_url": "https://vibeistic.in", "currency_symbol": "₹",
         "min_payout": 500, "contact_email": "hello@vibeistic.in", "payout_method_note": ""}
    f = CONFIG / "settings.json"
    if f.exists():
        s.update(json.loads(f.read_text(encoding="utf-8")))
    return s


def load_contributors() -> dict[str, dict]:
    out = {}
    with open(CONFIG / "contributors.csv", encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            cid = (r.get("contributor_id") or "").strip()
            if not cid:
                continue
            pct = to_num(r.get("share_percent"))
            if not 0 <= pct <= 100:
                sys.exit(f"contributors.csv: share_percent for {cid} must be 0–100 (got {pct}).")
            out[cid] = {
                "id": cid, "name": (r.get("name") or cid).strip(), "email": (r.get("email") or "").strip(),
                "upi": (r.get("upi_id") or "").strip(), "share": pct,
                "active": (r.get("active") or "yes").strip().lower() not in ("no", "false", "0"),
            }
    return out


def load_page_owners(contributors: dict) -> dict[str, dict]:
    out = {}
    with open(CONFIG / "page_owners.csv", encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            path = norm_path(r.get("page_path", ""))
            cid = (r.get("contributor_id") or "").strip()
            if not cid or path == "/":
                continue
            if cid not in contributors:
                sys.exit(f"page_owners.csv: contributor '{cid}' for {path} is not in contributors.csv.")
            ov = (r.get("share_percent_override") or "").strip()
            share = to_num(ov) if ov else contributors[cid]["share"]
            if not 0 <= share <= 100:
                sys.exit(f"page_owners.csv: share_percent_override for {path} must be 0–100.")
            out[path] = {"cid": cid, "title": (r.get("page_title") or path).strip(), "share": share}
    return out


def load_adsense(path: Path) -> dict[str, dict]:
    rows = read_csv_flexible(path)
    if not rows:
        sys.exit(f"AdSense file is empty: {path}")
    h = list(rows[0].keys())
    c_page = find_col(h, "page", "url", "site")
    c_earn = find_col(h, "estimated earnings", "earnings", "revenue")
    c_views = find_col(h, "page views", "pageviews", "views", avoid=("rpm", "ctr"))
    if not c_page or not c_earn:
        sys.exit(f"AdSense CSV: could not find page/URL and earnings columns. Found: {h}")
    out: dict[str, dict] = {}
    for r in rows:
        p = norm_path(r.get(c_page, ""))
        d = out.setdefault(p, {"earnings": 0.0, "views": 0.0})
        d["earnings"] += to_num(r.get(c_earn))
        if c_views:
            d["views"] += to_num(r.get(c_views))
    return out


def load_ga(path: Path | None) -> dict[str, float]:
    if not path:
        return {}
    rows = read_csv_flexible(path)
    if not rows:
        sys.exit(f"GA4 file is empty: {path}")
    h = list(rows[0].keys())
    c_page = find_col(h, "page path", "page location", "page", "screen")
    c_views = find_col(h, "views", "screen page views", "pageviews", avoid=("per", "average"))
    if not c_page or not c_views:
        sys.exit(f"GA4 CSV: could not find 'Page path' and 'Views' columns. Found: {h}")
    out: dict[str, float] = {}
    for r in rows:
        p = norm_path(r.get(c_page, ""))
        out[p] = out.get(p, 0.0) + to_num(r.get(c_views))
    return out


def read_ledger() -> list[dict]:
    if not LEDGER.exists():
        return []
    with open(LEDGER, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def write_ledger(rows: list[dict]) -> None:
    DATA.mkdir(exist_ok=True)
    with open(LEDGER, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=LEDGER_FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in LEDGER_FIELDS})


def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", s).strip("_") or "x"


# --------------------------------------------------------------------------- core
def compute(cycle, adsense, ga, owners, contributors, received, method, settings):
    site_views = sum(ga.values()) if ga else sum(d["views"] for d in adsense.values())
    est_total = sum(d["earnings"] for d in adsense.values())
    site_earnings = received if received is not None else est_total
    factor = (site_earnings / est_total) if est_total else 0.0

    if method == "auto":
        method = "adsense" if est_total > 0 else "views"
    if method == "views" and not site_views:
        sys.exit("Method 'views' needs page views (GA4 file or AdSense page views).")

    all_paths = set(adsense) | set(ga) | set(owners)
    pages = []
    for p in sorted(all_paths):
        views = ga.get(p, adsense.get(p, {}).get("views", 0.0)) if ga else adsense.get(p, {}).get("views", 0.0)
        if method == "adsense":
            earn = adsense.get(p, {}).get("earnings", 0.0) * factor
        else:
            earn = site_earnings * (views / site_views) if site_views else 0.0
        o = owners.get(p)
        share = o["share"] if o else 0.0
        contrib = earn * share / 100 if o else 0.0
        pages.append({
            "path": p, "title": o["title"] if o else p, "cid": o["cid"] if o else "",
            "owner": contributors[o["cid"]]["name"] if o else "Vibeistic",
            "views": views, "earnings": money(earn), "share": share,
            "contributor_amt": money(contrib), "vibeistic_amt": money(earn - contrib),
        })

    warnings = []
    for p, o in owners.items():
        if p not in adsense and p not in ga:
            warnings.append(f"{p} ({o['cid']}) has no data in either export – check the path spelling.")

    return pages, {"site_views": site_views, "site_earnings": money(site_earnings),
                   "estimated_total": money(est_total), "factor": factor, "method": method}, warnings


def update_ledger(cycle, pages, totals, contributors, settings, force):
    ledger = read_ledger()
    existing = [r for r in ledger if r["cycle"] == cycle]
    if any(r.get("status") == "Paid" for r in existing) and not force:
        sys.exit(f"Cycle {cycle} already has payments marked Paid. Use --force to recalculate anyway.")
    paid_info = {r["contributor_id"]: r for r in existing}
    others = [r for r in ledger if r["cycle"] != cycle]
    min_pay = float(settings["min_payout"])
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")

    new_rows = []
    for cid, c in contributors.items():
        mine = [p for p in pages if p["cid"] == cid]
        if not mine and not c["active"]:
            continue
        prev = [r for r in others if r["contributor_id"] == cid]
        bf = to_num(prev[-1]["carry_forward"]) if prev else 0.0
        earn = sum(p["earnings"] for p in mine)
        share_amt = sum(p["contributor_amt"] for p in mine)
        eff = (share_amt / earn * 100) if earn else c["share"]
        due = share_amt + bf
        payout, carry = (due, 0.0) if due >= min_pay else (0.0, due)
        old = paid_info.get(cid, {})
        status = old.get("status") or ("Pending" if payout > 0 else "Carried forward")
        if old.get("status") == "Paid" and force:
            status = "Paid"
        new_rows.append({
            "cycle": cycle, "contributor_id": cid, "name": c["name"], "pages": len(mine),
            "page_views": int(sum(p["views"] for p in mine)), "page_earnings": money(earn),
            "share_percent": round(eff, 2), "cycle_share": money(share_amt),
            "vibeistic_share": money(earn - share_amt), "brought_forward": money(bf),
            "total_due": money(due), "payout": money(payout), "carry_forward": money(carry),
            "status": status if payout > 0 else "Carried forward",
            "paid_on": old.get("paid_on", ""), "reference": old.get("reference", ""),
            "site_views": int(totals["site_views"]), "site_earnings": totals["site_earnings"],
            "generated_on": now,
        })

    # keep cycle position if it already existed, otherwise append
    if existing:
        idx = ledger.index(existing[0])
        merged = [r for r in ledger[:idx] if r["cycle"] != cycle] + new_rows + [r for r in ledger[idx:] if r["cycle"] != cycle]
    else:
        merged = others + new_rows
    write_ledger(merged)
    return new_rows


# --------------------------------------------------------------------------- Excel
def style_header(ws, row=1):
    for cell in ws[row]:
        cell.font = Font(bold=True, color="FFFFFF", name="Arial")
        cell.fill = PatternFill("solid", start_color=VIOLET)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def autosize(ws, widths=None):
    for i, col in enumerate(ws.columns, 1):
        if widths and i - 1 < len(widths):
            ws.column_dimensions[get_column_letter(i)].width = widths[i - 1]
            continue
        longest = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[get_column_letter(i)].width = min(max(10, longest + 2), 60)


def write_cycle_workbook(cycle, pages, totals, rows, settings, warnings) -> Path:
    cur = settings["currency_symbol"]
    fmt = f'"{cur}"#,##0.00'
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = f"Vibe Tribe payout – {cycle}"
    ws["A1"].font = Font(bold=True, size=14, color=VIOLET, name="Arial")
    info = [
        ("Site page views (cycle)", totals["site_views"], "#,##0"),
        ("AdSense estimated earnings", totals["estimated_total"], fmt),
        ("Revenue used for payouts", totals["site_earnings"], fmt),
        ("Scaling factor (received ÷ estimated)", round(totals["factor"], 4), "0.0000"),
        ("Allocation method", totals["method"], None),
        ("Minimum payout", float(settings["min_payout"]), fmt),
        ("Generated on", dt.datetime.now().strftime("%Y-%m-%d %H:%M"), None),
    ]
    for i, (k, v, f) in enumerate(info, start=3):
        ws.cell(i, 1, k).font = Font(bold=True, name="Arial")
        c = ws.cell(i, 2, v)
        if f:
            c.number_format = f
    r0 = len(info) + 5
    ws.cell(r0 - 1, 1, "Totals").font = Font(bold=True, color=VIOLET, name="Arial")
    contrib_earn = sum(p["earnings"] for p in pages if p["cid"])
    contrib_share = sum(p["contributor_amt"] for p in pages if p["cid"])
    for i, (k, v) in enumerate([
        ("Earnings from Vibe Tribe pages", contrib_earn),
        ("Contributors' share (this cycle)", contrib_share),
        ("Vibeistic keeps from Vibe Tribe pages", contrib_earn - contrib_share),
        ("Earnings from Vibeistic's own pages", totals["site_earnings"] - contrib_earn),
        ("Payouts due now (incl. carry-forward)", sum(float(r["payout"]) for r in rows)),
    ]):
        ws.cell(r0 + i, 1, k)
        ws.cell(r0 + i, 2, money(v)).number_format = fmt
    if warnings:
        wr = r0 + 7
        ws.cell(wr, 1, "Warnings").font = Font(bold=True, color="C0392B", name="Arial")
        for j, w in enumerate(warnings, 1):
            ws.cell(wr + j, 1, w)
    autosize(ws, [44, 22])

    wp = wb.create_sheet("Pages")
    wp.append(["Page path", "Title", "Owner", "Contributor ID", "Page views", "Page earnings",
               "Contributor %", "Contributor amount", "Vibeistic amount"])
    style_header(wp)
    for p in sorted(pages, key=lambda x: -x["earnings"]):
        wp.append([p["path"], p["title"], p["owner"], p["cid"], int(p["views"]), p["earnings"],
                   p["share"] / 100 if p["cid"] else 0, p["contributor_amt"], p["vibeistic_amt"]])
    for row in wp.iter_rows(min_row=2):
        row[4].number_format = "#,##0"
        row[5].number_format = fmt
        row[6].number_format = "0%"
        row[7].number_format = fmt
        row[8].number_format = fmt
    wp.freeze_panes = "A2"
    wp.auto_filter.ref = wp.dimensions
    autosize(wp)

    wc = wb.create_sheet("Contributors")
    heads = ["Contributor ID", "Name", "Pages", "Page views", "Page earnings", "Their %",
             "Their share", "Vibeistic share", "Brought forward", "Total due", "Payout now",
             "Carry forward", "Status", "Paid on", "Reference"]
    wc.append(heads)
    style_header(wc)
    for r in rows:
        wc.append([r["contributor_id"], r["name"], r["pages"], r["page_views"], r["page_earnings"],
                   float(r["share_percent"]) / 100, r["cycle_share"], r["vibeistic_share"],
                   r["brought_forward"], r["total_due"], r["payout"], r["carry_forward"],
                   r["status"], r["paid_on"], r["reference"]])
    for row in wc.iter_rows(min_row=2):
        row[3].number_format = "#,##0"
        for i in (4, 6, 7, 8, 9, 10, 11):
            row[i].number_format = fmt
        row[5].number_format = "0%"
    wc.freeze_panes = "C2"
    autosize(wc)

    d = OUT / cycle
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"Payout_{cycle}.xlsx"
    wb.save(f)
    return f


def write_ledger_workbook(settings) -> Path:
    cur = settings["currency_symbol"]
    fmt = f'"{cur}"#,##0.00'
    ledger = read_ledger()
    wb = Workbook()
    ws = wb.active
    ws.title = "All cycles"
    heads = ["Cycle", "Contributor ID", "Name", "Pages", "Page views", "Page earnings", "Their %",
             "Their share", "Vibeistic share", "Brought forward", "Total due", "Payout",
             "Carry forward", "Status", "Paid on", "Reference"]
    ws.append(heads)
    style_header(ws)
    keys = ["cycle", "contributor_id", "name", "pages", "page_views", "page_earnings", "share_percent",
            "cycle_share", "vibeistic_share", "brought_forward", "total_due", "payout",
            "carry_forward", "status", "paid_on", "reference"]

    def add(sheet, r):
        vals = []
        for k in keys:
            v = r.get(k, "")
            if k in ("pages", "page_views"):
                v = int(to_num(v))
            elif k == "share_percent":
                v = to_num(v) / 100
            elif k in ("page_earnings", "cycle_share", "vibeistic_share", "brought_forward",
                       "total_due", "payout", "carry_forward"):
                v = to_num(v)
            vals.append(v)
        sheet.append(vals)
        row = sheet[sheet.max_row]
        row[4].number_format = "#,##0"
        row[6].number_format = "0%"
        for i in range(7, 13):
            row[i].number_format = fmt
        row[5].number_format = fmt

    for r in ledger:
        add(ws, r)
    ws.freeze_panes = "D2"
    ws.auto_filter.ref = ws.dimensions
    autosize(ws)

    for cid in dict.fromkeys(r["contributor_id"] for r in ledger):
        mine = [r for r in ledger if r["contributor_id"] == cid]
        sh = wb.create_sheet(safe_name(f"{cid} {mine[0]['name']}")[:31])
        sh.append(heads)
        style_header(sh)
        for r in mine:
            add(sh, r)
        n = sh.max_row
        sh.append([])
        tot = sh.max_row + 1
        sh.cell(tot, 1, "Totals").font = Font(bold=True, name="Arial")
        sh.cell(tot, 6, f"=SUM(F2:F{n})").number_format = fmt
        sh.cell(tot, 8, f"=SUM(H2:H{n})").number_format = fmt
        sh.cell(tot, 12, f"=SUM(L2:L{n})").number_format = fmt
        sh.cell(tot + 1, 1, "Paid so far").font = Font(bold=True, name="Arial")
        sh.cell(tot + 1, 12, f'=SUMIFS(L2:L{n},N2:N{n},"Paid")').number_format = fmt
        sh.cell(tot + 2, 1, "Current carry-forward").font = Font(bold=True, name="Arial")
        sh.cell(tot + 2, 12, f"=M{n}").number_format = fmt
        sh.freeze_panes = "B2"
        autosize(sh)

    OUT.mkdir(exist_ok=True)
    f = OUT / "Vibe_Tribe_Ledger.xlsx"
    wb.save(f)
    return f


# --------------------------------------------------------------------------- HTML
CSS = """
:root{--v:#5b2a86;--c:#ff5e7e;--m:#ffb238;--ink:#1d1730;--mu:#625b70;--card:#f8f6fb;--bd:#ebe6f2}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;color:var(--ink);background:#fff;line-height:1.5}
.wrap{max-width:980px;margin:0 auto;padding:24px 18px 40px}
.top{background:linear-gradient(120deg,#3a1a5c,#5b2a86 40%,#c9407a 75%,#ff8a5c);color:#fff;border-radius:18px;padding:22px 24px;margin-bottom:18px}
.top .brand{font-weight:800;font-size:22px}.top .brand span{color:#ffd27a}
.top h1{font-size:26px;margin-top:6px}.top p{opacity:.9}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:14px 0}
.k{background:var(--card);border-radius:14px;padding:14px}.k b{display:block;font-size:22px;color:var(--v)}
.k span{font-size:13px;color:var(--mu)}.k.hl{background:#e3f4ea}.k.hl b{color:#1f7a4a}
h2{font-size:18px;margin:22px 0 8px;color:var(--v)}
table{width:100%;border-collapse:collapse;font-size:14px}th,td{padding:9px 10px;border-bottom:1px solid var(--bd);text-align:left}
th{background:var(--card);font-weight:600}td.n,th.n{text-align:right}
tr.me td{background:#fff3dc;font-weight:600}
.blur{filter:blur(4px);user-select:none;color:#9a93a8}
.split{display:flex;height:26px;border-radius:999px;overflow:hidden;margin:8px 0;font-size:12px;color:#fff;font-weight:600}
.split div{display:flex;align-items:center;justify-content:center;white-space:nowrap}
.note{background:#fff3dc;border-left:4px solid var(--m);border-radius:0 10px 10px 0;padding:10px 14px;font-size:13.5px;margin-top:16px}
.bar{height:10px;background:var(--bd);border-radius:6px;overflow:hidden}.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--m),var(--c))}
.tag{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600}
.Paid{background:#e3f4ea;color:#1f7a4a}.Pending{background:#fff3dc;color:#8a5a00}.Carried{background:#efe7f7;color:var(--v)}
.foot{font-size:12px;color:var(--mu);margin-top:22px;text-align:center}
a{color:var(--v)}
@media print{.top{-webkit-print-color-adjust:exact;print-color-adjust:exact}.k,.note,th,tr.me td,.split div{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
"""


def esc(s) -> str:
    return html.escape(str(s))


def fm(v, cur) -> str:
    return f"{cur}{to_num(v):,.2f}"


def write_statements(cycle, pages, totals, rows, settings) -> list[Path]:
    cur = settings["currency_symbol"]
    d = OUT / cycle / "statements"
    d.mkdir(parents=True, exist_ok=True)
    ranked = sorted([p for p in pages if p["views"] > 0], key=lambda x: -x["views"])
    site_views = totals["site_views"] or 1
    files = []
    for r in rows:
        cid = r["contributor_id"]
        mine = [p for p in pages if p["cid"] == cid]
        my_views = sum(p["views"] for p in mine)
        pct_site = my_views / site_views * 100
        their = to_num(r["share_percent"])
        ours = 100 - their

        page_rows = "".join(
            f"<tr><td>{esc(p['title'])}<br><small style='color:#625b70'>{esc(p['path'])}</small></td>"
            f"<td class='n'>{int(p['views']):,}</td><td class='n'>{fm(p['earnings'], cur)}</td>"
            f"<td class='n'>{p['share']:.0f}%</td><td class='n'><b>{fm(p['contributor_amt'], cur)}</b></td></tr>"
            for p in sorted(mine, key=lambda x: -x["earnings"])
        ) or "<tr><td colspan='5'>No published pages in this cycle.</td></tr>"

        lb = []
        for i, p in enumerate(ranked[:15], 1):
            if p["cid"] == cid:
                lb.append(f"<tr class='me'><td>#{i}</td><td>{esc(p['title'])} (you)</td><td class='n'>{int(p['views']):,}</td></tr>")
            else:
                lb.append(f"<tr><td>#{i}</td><td><span class='blur'>████████ ██████</span></td><td class='n'><span class='blur'>█,███</span></td></tr>")
        my_ranks = [ranked.index(p) + 1 for p in mine if p in ranked]
        extra = ""
        if my_ranks and min(my_ranks) > 15:
            extra = f"<p style='font-size:13px;color:#625b70;margin-top:6px'>Your best page is ranked #{min(my_ranks)} of {len(ranked)}.</p>"

        if to_num(r["payout"]) > 0:
            pay_line = f"<div class='k hl'><span>Payout this cycle</span><b>{fm(r['payout'], cur)}</b></div>"
            status = f"Status: <b>{esc(r['status'])}</b>" + (f" on {esc(r['paid_on'])} (ref {esc(r['reference'])})" if r.get("paid_on") else "")
        else:
            pay_line = f"<div class='k'><span>Carried to next cycle</span><b>{fm(r['carry_forward'], cur)}</b></div>"
            status = f"Your balance is below the minimum payout of {cur}{float(settings['min_payout']):,.0f}, so it carries forward."

        doc = f"""<!doctype html><html lang="en-IN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Vibe Tribe statement – {esc(r['name'])} – {esc(cycle)}</title><style>{CSS}</style></head><body><div class="wrap">
<div class="top"><div class="brand">vibe<span>istic</span> · Vibe Tribe</div>
<h1>Earnings statement – {esc(cycle)}</h1><p>Prepared for <b>{esc(r['name'])}</b> ({esc(cid)}) · Private &amp; confidential</p></div>

<h2>Traffic</h2>
<div class="grid">
 <div class="k"><span>Whole site page views</span><b>{int(site_views):,}</b></div>
 <div class="k"><span>Your pages' views</span><b>{int(my_views):,}</b></div>
 <div class="k"><span>Your share of site traffic</span><b>{pct_site:.1f}%</b></div>
 <div class="k"><span>Your published pages</span><b>{len(mine)}</b></div>
</div>

<h2>Earnings</h2>
<div class="grid">
 <div class="k"><span>Your pages earned</span><b>{fm(r['page_earnings'], cur)}</b></div>
 <div class="k"><span>Vibeistic share ({ours:.0f}%)</span><b>{fm(r['vibeistic_share'], cur)}</b></div>
 <div class="k"><span>Your share ({their:.0f}%)</span><b>{fm(r['cycle_share'], cur)}</b></div>
 <div class="k"><span>Brought forward</span><b>{fm(r['brought_forward'], cur)}</b></div>
 {pay_line}
</div>
<div class="split" aria-label="Earnings split">
 <div style="width:{max(ours,8):.0f}%;background:#5b2a86">Vibeistic {ours:.0f}%</div>
 <div style="width:{max(their,8):.0f}%;background:#ff5e7e">You {their:.0f}%</div>
</div>
<p style="font-size:14px">{status}</p>

<h2>Your pages</h2>
<table><thead><tr><th>Page</th><th class="n">Views</th><th class="n">Earned</th><th class="n">Your %</th><th class="n">Your share</th></tr></thead>
<tbody>{page_rows}</tbody></table>

<h2>Where you rank (top pages by views)</h2>
<table><thead><tr><th>Rank</th><th>Page</th><th class="n">Views</th></tr></thead><tbody>{''.join(lb)}</tbody></table>{extra}
<p style="font-size:12.5px;color:#625b70;margin-top:6px">Other contributors' pages are hidden for privacy.</p>

<div class="note">Figures are based on Google AdSense and Google Analytics data for this cycle. Earnings shown are the revenue Vibeistic actually received for your pages{" (AdSense estimates adjusted to the final payment)" if abs(totals["factor"] - 1) > 0.001 else ""}. {esc(settings.get('payout_method_note', ''))} Questions? Email {esc(settings['contact_email'])}.</div>
<div class="foot">Generated {dt.datetime.now().strftime('%d %b %Y')} · Tip: use File → Print → Save as PDF to send this statement.</div>
</div></body></html>"""
        f = d / f"{safe_name(cid)}_{safe_name(r['name'])}_{cycle}.html"
        f.write_text(doc, encoding="utf-8")
        files.append(f)
    return files


def write_dashboard(settings) -> Path:
    cur = settings["currency_symbol"]
    ledger = read_ledger()
    cycles = list(dict.fromkeys(r["cycle"] for r in ledger))
    paid = sum(to_num(r["payout"]) for r in ledger if r["status"] == "Paid")
    pending = sum(to_num(r["payout"]) for r in ledger if r["status"] == "Pending")
    carry = {}
    for r in ledger:
        carry[r["contributor_id"]] = to_num(r["carry_forward"])
    contrib_share = sum(to_num(r["cycle_share"]) for r in ledger)
    vib_from_tribe = sum(to_num(r["vibeistic_share"]) for r in ledger)
    site_rev = {}
    for r in ledger:
        site_rev[r["cycle"]] = to_num(r["site_earnings"])

    by_c = {}
    for r in ledger:
        c = by_c.setdefault(r["contributor_id"], {"name": r["name"], "earn": 0.0, "share": 0.0, "paid": 0.0, "views": 0})
        c["earn"] += to_num(r["page_earnings"])
        c["share"] += to_num(r["cycle_share"])
        c["views"] += int(to_num(r["page_views"]))
        if r["status"] == "Paid":
            c["paid"] += to_num(r["payout"])
    mx = max([c["share"] for c in by_c.values()] + [1])
    contrib_rows = "".join(
        f"<tr><td><b>{esc(cid)}</b> {esc(c['name'])}</td><td class='n'>{c['views']:,}</td>"
        f"<td class='n'>{fm(c['earn'], cur)}</td><td class='n'>{fm(c['share'], cur)}</td>"
        f"<td style='width:24%'><div class='bar'><i style='width:{c['share']/mx*100:.0f}%'></i></div></td>"
        f"<td class='n'>{fm(c['paid'], cur)}</td><td class='n'>{fm(carry.get(cid, 0), cur)}</td></tr>"
        for cid, c in sorted(by_c.items(), key=lambda x: -x[1]["share"]))

    cyc_rows = []
    for cy in reversed(cycles):
        rs = [r for r in ledger if r["cycle"] == cy]
        cyc_rows.append(
            f"<tr><td><b>{esc(cy)}</b></td><td class='n'>{int(to_num(rs[0]['site_views'])):,}</td>"
            f"<td class='n'>{fm(site_rev.get(cy, 0), cur)}</td>"
            f"<td class='n'>{fm(sum(to_num(r['page_earnings']) for r in rs), cur)}</td>"
            f"<td class='n'>{fm(sum(to_num(r['cycle_share']) for r in rs), cur)}</td>"
            f"<td class='n'>{fm(sum(to_num(r['payout']) for r in rs), cur)}</td>"
            f"<td><a href='{esc(cy)}/Payout_{esc(cy)}.xlsx'>Workbook</a> · <a href='{esc(cy)}/statements/'>Statements</a></td></tr>")

    detail = []
    for r in reversed(ledger):
        st = r["status"].split()[0]
        detail.append(
            f"<tr><td>{esc(r['cycle'])}</td><td>{esc(r['contributor_id'])} {esc(r['name'])}</td>"
            f"<td class='n'>{fm(r['page_earnings'], cur)}</td><td class='n'>{to_num(r['share_percent']):.0f}%</td>"
            f"<td class='n'>{fm(r['cycle_share'], cur)}</td><td class='n'>{fm(r['payout'], cur)}</td>"
            f"<td><span class='tag {esc(st)}'>{esc(r['status'])}</span></td><td>{esc(r['reference'])}</td></tr>")

    doc = f"""<!doctype html><html lang="en-IN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Vibe Tribe – owner dashboard</title><style>{CSS} .wrap{{max-width:1150px}}</style></head><body><div class="wrap">
<div class="top"><div class="brand">vibe<span>istic</span> · Vibe Tribe</div><h1>Owner dashboard</h1>
<p>{len(cycles)} cycle(s) · {len(by_c)} contributor(s) · updated {dt.datetime.now().strftime('%d %b %Y, %H:%M')}</p></div>
<div class="grid">
 <div class="k"><span>Site revenue (all cycles)</span><b>{fm(sum(site_rev.values()), cur)}</b></div>
 <div class="k"><span>Earned by Vibe Tribe pages</span><b>{fm(contrib_share + vib_from_tribe, cur)}</b></div>
 <div class="k"><span>Contributors' share</span><b>{fm(contrib_share, cur)}</b></div>
 <div class="k"><span>Vibeistic kept from Tribe pages</span><b>{fm(vib_from_tribe, cur)}</b></div>
 <div class="k hl"><span>Paid out</span><b>{fm(paid, cur)}</b></div>
 <div class="k"><span>Pending payouts</span><b>{fm(pending, cur)}</b></div>
 <div class="k"><span>Carried forward</span><b>{fm(sum(carry.values()), cur)}</b></div>
</div>
<h2>Contributors (all cycles)</h2>
<table><thead><tr><th>Contributor</th><th class="n">Views</th><th class="n">Pages earned</th><th class="n">Their share</th><th></th><th class="n">Paid</th><th class="n">Carry fwd</th></tr></thead><tbody>{contrib_rows or "<tr><td colspan=7>No data yet.</td></tr>"}</tbody></table>
<h2>Cycles</h2>
<table><thead><tr><th>Cycle</th><th class="n">Site views</th><th class="n">Site revenue</th><th class="n">Tribe pages earned</th><th class="n">Contributors' share</th><th class="n">Payouts</th><th>Files</th></tr></thead><tbody>{''.join(cyc_rows) or "<tr><td colspan=7>No data yet.</td></tr>"}</tbody></table>
<h2>Payout ledger</h2>
<table><thead><tr><th>Cycle</th><th>Contributor</th><th class="n">Pages earned</th><th class="n">Their %</th><th class="n">Their share</th><th class="n">Payout</th><th>Status</th><th>Reference</th></tr></thead><tbody>{''.join(detail) or "<tr><td colspan=8>No data yet.</td></tr>"}</tbody></table>
<div class="foot">Private – for Vibeistic only. Source of truth: data/ledger.csv · Excel: output/Vibe_Tribe_Ledger.xlsx</div>
</div></body></html>"""
    OUT.mkdir(exist_ok=True)
    f = OUT / "dashboard.html"
    f.write_text(doc, encoding="utf-8")
    return f


# --------------------------------------------------------------------------- commands
def cmd_run(a):
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2]|Q[1-4])", a.cycle):
        sys.exit("Use --cycle like 2026-11 (monthly) or 2026-Q4 (quarterly). Stick to one style.")
    settings = load_settings()
    contributors = load_contributors()
    owners = load_page_owners(contributors)
    adsense = load_adsense(Path(a.adsense))
    ga = load_ga(Path(a.ga) if a.ga else None)
    pages, totals, warnings = compute(a.cycle, adsense, ga, owners, contributors, a.received, a.method, settings)
    rows = update_ledger(a.cycle, pages, totals, contributors, settings, a.force)
    wb = write_cycle_workbook(a.cycle, pages, totals, rows, settings, warnings)
    st = write_statements(a.cycle, pages, totals, rows, settings)
    lw = write_ledger_workbook(settings)
    db = write_dashboard(settings)

    cur = settings["currency_symbol"]
    print(f"\nVibe Tribe payout – {a.cycle}  (method: {totals['method']})")
    print(f"  Site views: {int(totals['site_views']):,}   Revenue used: {cur}{totals['site_earnings']:,.2f}")
    print(f"  {'ID':<4}{'Name':<20}{'Earned':>12}{'Share%':>8}{'Share':>12}{'B/F':>10}{'Payout':>12}  Status")
    for r in rows:
        print(f"  {r['contributor_id']:<4}{r['name'][:19]:<20}{to_num(r['page_earnings']):>12,.2f}"
              f"{to_num(r['share_percent']):>7.0f}%{to_num(r['cycle_share']):>12,.2f}"
              f"{to_num(r['brought_forward']):>10,.2f}{to_num(r['payout']):>12,.2f}  {r['status']}")
    for w in warnings:
        print("  ⚠ " + w)
    print(f"\n  Workbook:   {wb.relative_to(ROOT)}\n  Statements: {st[0].parent.relative_to(ROOT) if st else '-'}"
          f"\n  Ledger:     {lw.relative_to(ROOT)}\n  Dashboard:  {db.relative_to(ROOT)}\n")


def cmd_mark_paid(a):
    ledger = read_ledger()
    hit = [r for r in ledger if r["cycle"] == a.cycle and r["contributor_id"] == a.id]
    if not hit:
        sys.exit(f"No ledger row for cycle {a.cycle}, contributor {a.id}.")
    r = hit[0]
    if to_num(r["payout"]) <= 0:
        sys.exit("Nothing to pay for this row (balance was carried forward).")
    r["status"] = "Paid"
    r["paid_on"] = a.date or dt.date.today().isoformat()
    r["reference"] = a.ref
    write_ledger(ledger)
    settings = load_settings()
    write_ledger_workbook(settings)
    write_dashboard(settings)
    print(f"Marked {a.id} paid for {a.cycle} (ref {a.ref}). Re-run 'run' for the cycle with --force to refresh the statement if needed.")


def cmd_dashboard(_a):
    s = load_settings()
    print("Ledger:", write_ledger_workbook(s).relative_to(ROOT))
    print("Dashboard:", write_dashboard(s).relative_to(ROOT))


def main():
    ap = argparse.ArgumentParser(description="Vibe Tribe payout tool")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="Calculate a cycle")
    r.add_argument("--cycle", required=True)
    r.add_argument("--adsense", required=True, help="AdSense Pages report CSV")
    r.add_argument("--ga", help="GA4 Pages and screens CSV (recommended)")
    r.add_argument("--received", type=float, help="Amount actually received from AdSense for this cycle")
    r.add_argument("--method", choices=["auto", "adsense", "views"], default="auto")
    r.add_argument("--force", action="store_true")
    r.set_defaults(func=cmd_run)
    m = sub.add_parser("mark-paid", help="Record a payment")
    m.add_argument("--cycle", required=True)
    m.add_argument("--id", required=True)
    m.add_argument("--ref", required=True)
    m.add_argument("--date")
    m.set_defaults(func=cmd_mark_paid)
    d = sub.add_parser("dashboard", help="Rebuild ledger workbook and dashboard")
    d.set_defaults(func=cmd_dashboard)
    a = ap.parse_args()
    a.func(a)


if __name__ == "__main__":
    main()
