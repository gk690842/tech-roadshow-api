-- Vibe Tribe contributor portal – database schema (Cloudflare D1 / SQLite)
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contributor_id TEXT UNIQUE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT, city TEXT, instagram TEXT, address TEXT,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'contributor',          -- contributor | admin
  status TEXT NOT NULL DEFAULT 'active',             -- active | blocked | deleted
  totp_secret TEXT, totp_pending TEXT, totp_enabled INTEGER NOT NULL DEFAULT 0,
  age_confirmed INTEGER NOT NULL DEFAULT 0,
  terms_version TEXT, terms_at INTEGER,
  deletion_requested_at INTEGER,
  created_at INTEGER NOT NULL, last_login_at INTEGER
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  twofa_ok INTEGER NOT NULL DEFAULT 1,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS password_resets (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  review_id TEXT UNIQUE,
  user_id INTEGER NOT NULL,
  pillar TEXT, place_name TEXT, area TEXT, city TEXT, visit_date TEXT,
  price_paid TEXT, timings TEXT, parking TEXT, crowd TEXT,
  score1 REAL, score2 REAL, score3 REAL,
  title TEXT, body TEXT, tips TEXT, best_for TEXT,
  reel_url TEXT, reel_ready INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft',  -- draft | submitted | changes_requested | approved | rejected | published
  admin_note TEXT,
  points_awarded INTEGER NOT NULL DEFAULT 0, reel_points INTEGER NOT NULL DEFAULT 0,
  consent_version TEXT, consent_at INTEGER,
  slug TEXT, published_url TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  submitted_at INTEGER, decided_at INTEGER, decided_by INTEGER, published_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_sub_user ON submissions(user_id);
CREATE INDEX IF NOT EXISTS idx_sub_status ON submissions(status);

CREATE TABLE IF NOT EXISTS photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  submission_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  mime TEXT NOT NULL, size INTEGER NOT NULL,
  data BLOB, r2_key TEXT, position INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_photos_sub ON photos(submission_id);

CREATE TABLE IF NOT EXISTS points_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, submission_id INTEGER, payout_id INTEGER,
  points INTEGER NOT NULL,
  kind TEXT NOT NULL,            -- review | reel | bonus | adjust | redeem | refund
  note TEXT, created_by INTEGER, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON points_ledger(user_id);

CREATE TABLE IF NOT EXISTS payouts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payout_ref TEXT UNIQUE,
  user_id INTEGER NOT NULL,
  points INTEGER NOT NULL, amount_paise INTEGER NOT NULL,
  method TEXT NOT NULL, details_enc TEXT NOT NULL, details_hint TEXT,
  status TEXT NOT NULL DEFAULT 'requested',   -- requested | paid | rejected
  reference TEXT, admin_note TEXT,
  requested_at INTEGER NOT NULL, decided_at INTEGER, decided_by INTEGER
);

CREATE TABLE IF NOT EXISTS gifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL, level INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',      -- pending | sent
  note TEXT, created_at INTEGER NOT NULL, sent_at INTEGER,
  UNIQUE(user_id, level)
);

CREATE TABLE IF NOT EXISTS settings ( key TEXT PRIMARY KEY, value TEXT NOT NULL );

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER, action TEXT NOT NULL, target TEXT, detail TEXT, created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS rate_limits ( k TEXT PRIMARY KEY, n INTEGER NOT NULL, reset_at INTEGER NOT NULL );

INSERT OR IGNORE INTO settings (key, value) VALUES
 ('portal_live','0'),
 ('review_points_min','80'),
 ('review_points_max','100'),
 ('review_points_default','90'),
 ('reel_bonus','50'),
 ('inr_per_point','0.5'),
 ('min_payout_inr','300'),
 ('min_words','250'),
 ('min_photos','2'),
 ('max_photos','8'),
 ('payout_days','15'),
 ('launch_reward_text',''),
 ('levels','[{"level":1,"name":"Explorer","min":0,"gift":false},{"level":2,"name":"Local Guide","min":5,"gift":true},{"level":3,"name":"Vibe Curator","min":15,"gift":true},{"level":4,"name":"Tribe Legend","min":30,"gift":false}]');
