/* Vibe Tribe – admin panel (setup, login + 2FA, queue, contributors, rewards, payouts, gifts, reports, audit) */
(function () {
  'use strict';
  var V = window.VT, esc = V.esc, api = V.api;
  var root = document.getElementById('vt-admin');
  if (!root) return;
  var TABS = [['overview', 'Overview'], ['queue', 'Review queue'], ['contributors', 'Contributors'], ['payouts', 'Payouts'], ['gifts', 'Gifts'], ['settings', 'Rewards & settings'], ['reports', 'Reports'], ['audit', 'Audit log']];

  window.addEventListener('hashchange', route);
  boot();

  async function boot() {
    root.innerHTML = '<p class="vt-muted">Loading…</p>';
    var st;
    try { st = await api('GET', '/api/status'); } catch (e) { root.innerHTML = '<div class="vt-note red">' + esc(e.message) + '</div>'; return; }
    if (!st.adminExists) return viewSetup(st);
    if (!st.user || st.user.role !== 'admin') return viewLogin();
    if (!st.user.twofa) return viewLogin(true);
    route();
  }
  function shell(active, inner) {
    root.innerHTML = '<div class="vt-between"><h1>Vibe Tribe · Admin</h1><div class="vt-row"><a class="vt-btn small ghost" href="/vibe-tribe/" target="_blank">View Join Us page</a><button class="vt-btn small ghost" id="lo">Log out</button></div></div>' +
      '<nav class="vt-tabs">' + TABS.map(function (t) { return '<button class="vt-tab ' + (t[0] === active ? 'on' : '') + '" data-t="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</nav><div id="pane">' + inner + '</div>';
    root.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { location.hash = '#/' + b.getAttribute('data-t'); }; });
    root.querySelector('#lo').onclick = async function () { try { await api('POST', '/api/auth/logout', {}); } catch (e) {} boot(); };
    return root.querySelector('#pane');
  }
  async function route() {
    var parts = (location.hash || '#/overview').slice(2).split('/');
    var tab = parts[0] || 'overview';
    try {
      if (tab === 'review' && parts[1]) return await viewReview(parseInt(parts[1], 10));
      if (tab === 'contributor' && parts[1]) return await viewContributor(parseInt(parts[1], 10));
      var fn = { overview: viewOverview, queue: viewQueue, contributors: viewContributors, payouts: viewPayouts, gifts: viewGifts, settings: viewSettings, reports: viewReports, audit: viewAudit }[tab] || viewOverview;
      await fn();
    } catch (e) {
      if (e.status === 401 || e.status === 403) return boot();
      shell('', '<div class="vt-note red">' + esc(e.message) + '</div>');
    }
  }

  // ------------------------------------------------------------ setup / login / 2FA
  function viewSetup(st) {
    if (!st.setupEnabled) { root.innerHTML = '<div class="vt-auth vt-card"><h1>Admin setup</h1><p>Set the <code>ADMIN_SETUP_KEY</code> secret in Cloudflare (see README), then reload this page.</p></div>'; return; }
    root.innerHTML = '<div class="vt-auth vt-card"><h1>Create the first admin</h1><p class="vt-muted">One-time setup. Use a separate email from any contributor account.</p><form id="f">' +
      inp('Setup key (ADMIN_SETUP_KEY)', 'setupKey', 'password') + inp('Your name', 'name') + inp('Admin email', 'email', 'email') + inp('Password (12+ characters)', 'password', 'password') +
      '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Create admin</button></form></div>';
    root.querySelector('#f').onsubmit = submitter('/api/setup-admin', function () { viewTotpSetup(); });
  }
  function viewLogin(skipPassword) {
    if (skipPassword) return view2fa();
    root.innerHTML = '<div class="vt-auth vt-card"><h1>Admin log in</h1><form id="f">' + inp('Email', 'email', 'email') + inp('Password', 'password', 'password') +
      '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Continue</button></form></div>';
    root.querySelector('#f').onsubmit = submitter('/api/auth/login', function (r) {
      if (r.role !== 'admin') { root.innerHTML = '<div class="vt-auth vt-card"><p>This is a contributor account. <a href="/vibe-tribe/dashboard/">Go to the contributor dashboard</a>.</p></div>'; return; }
      if (r.needsTotpSetup) viewTotpSetup(); else view2fa();
    });
  }
  function view2fa() {
    root.innerHTML = '<div class="vt-auth vt-card"><h1>Two-factor check</h1><p class="vt-muted">Enter the 6-digit code from your authenticator app.</p><form id="f">' +
      '<div class="vt-field"><input class="vt-input" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*" autofocus style="font-size:24px;letter-spacing:6px;text-align:center"></div>' +
      '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Verify</button></form><p style="margin-top:10px"><button class="vt-link" id="back">Use a different account</button></p></div>';
    root.querySelector('#f').onsubmit = submitter('/api/auth/2fa', function () { location.hash = '#/overview'; route(); });
    root.querySelector('#back').onclick = async function () { try { await api('POST', '/api/auth/logout', {}); } catch (e) {} viewLogin(); };
  }
  async function viewTotpSetup() {
    var r;
    try { r = await api('POST', '/api/auth/2fa/setup', {}); } catch (e) { root.innerHTML = '<div class="vt-note red">' + esc(e.message) + '</div>'; return; }
    var pretty = r.secret.replace(/(.{4})/g, '$1 ').trim();
    root.innerHTML = '<div class="vt-auth vt-card"><h1>Turn on two-factor authentication</h1>' +
      '<ol style="padding-left:20px;margin:10px 0"><li>Open an authenticator app (Google Authenticator, Microsoft Authenticator, or Apple Passwords on Mac/iPhone).</li><li>Add a new account → <b>Enter a setup key</b>: name <b>Vibeistic Admin</b>, key below, time-based.</li><li>Type the 6-digit code it shows.</li></ol>' +
      '<div class="vt-code" style="font-size:16px;text-align:center">' + esc(pretty) + '</div>' +
      '<p style="margin:8px 0"><a href="' + esc(r.uri) + '">Open in authenticator app (on this device)</a></p>' +
      '<p class="vt-muted" style="font-size:13px">Save this key in your password manager as a backup. Without it you cannot sign in if you lose your phone.</p>' +
      '<form id="f"><div class="vt-field"><input class="vt-input" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" style="font-size:24px;letter-spacing:6px;text-align:center"></div>' +
      '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Enable & continue</button></form></div>';
    root.querySelector('#f').onsubmit = submitter('/api/auth/2fa/enable', function () { V.toast('Two-factor authentication is on ✅'); location.hash = '#/overview'; route(); });
  }
  function submitter(path, done) {
    return async function (e) {
      e.preventDefault();
      var f = e.target, err = f.querySelector('#err'), btn = f.querySelector('button.vt-btn');
      btn.disabled = true; err.classList.add('vt-hidden');
      try { done(await api('POST', path, Object.fromEntries(new FormData(f)))); }
      catch (ex) { err.textContent = ex.message; err.classList.remove('vt-hidden'); btn.disabled = false; }
    };
  }
  function inp(label, name, type, val) { return '<div class="vt-field"><label>' + label + '</label><input class="vt-input" name="' + name + '" type="' + (type || 'text') + '" value="' + esc(val == null ? '' : val) + '" autocomplete="' + (type === 'password' ? 'current-password' : 'off') + '"></div>'; }
  function stat(v, l, hl) { return '<div class="vt-stat' + (hl ? ' hl' : '') + '"><b>' + esc(v) + '</b><span>' + l + '</span></div>'; }

  // ------------------------------------------------------------ overview
  async function viewOverview() {
    var o = await api('GET', '/api/admin/overview'), c = o.submissions;
    var pane = shell('overview',
      '<div class="vt-card ' + (o.live ? '' : 'vt-soft') + '"><div class="vt-between"><div><h3>' + (o.live ? '🟢 Join Us is LIVE for everyone' : '🟠 Join Us is hidden (visitors see “Our team is working on it”)') + '</h3>' +
      '<p class="vt-muted">Preview link for testers (works while hidden):</p><div class="vt-code" id="pv">' + esc(o.previewUrl) + '</div></div>' +
      '<div class="vt-row"><button class="vt-btn small ghost" id="cp">Copy preview link</button><button class="vt-btn small ' + (o.live ? 'red' : 'green') + '" id="tg">' + (o.live ? 'Hide again' : 'Go live') + '</button></div></div></div>' +
      '<div class="vt-grid">' + stat(c.total || 0, 'Total submissions') + stat(c.pending || 0, 'Pending review', !!c.pending) + stat(c.approved || 0, 'Approved') + stat(c.published || 0, 'Published') +
      stat(c.changes || 0, 'Changes requested') + stat(c.rejected || 0, 'Rejected') + stat(o.contributors, 'Contributors') + stat(o.payouts.pending + ' · ' + V.money(o.payouts.pendingAmount), 'Payouts to make', !!o.payouts.pending) +
      stat(V.money(o.payouts.paidAmount), 'Paid so far') + stat(o.giftsDue, 'Gifts to send', !!o.giftsDue) + stat(o.pointsIssued, 'Points issued') + stat(o.deletionRequests, 'Deletion requests', !!o.deletionRequests) + '</div>' +
      '<h2>Setup status</h2><table class="vt-table"><tbody>' +
      row('Photo storage', o.config.photos === 'R2' ? '✅ Cloudflare R2' : '✅ D1 database (fine to start; switch to R2 later)') +
      row('One-click publish to website', o.config.github ? '✅ GitHub connected' : '⚪ Not set – use “Download Markdown”') +
      row('Emails (reset, notifications)', o.config.email ? '✅ Brevo connected' : '⚪ Not set – password resets via admin link') +
      row('Payout encryption (DATA_KEY)', o.config.payouts ? '✅ On' : '❌ Missing – payouts disabled') + '</tbody></table>');
    pane.querySelector('#cp').onclick = function () { navigator.clipboard && navigator.clipboard.writeText(o.previewUrl).then(function () { V.toast('Copied'); }); };
    pane.querySelector('#tg').onclick = async function () {
      if (!o.live && !confirm('Make the Join Us page visible to everyone? Make sure you have tested every page as admin and as a visitor (preview link).')) return;
      await api('PUT', '/api/admin/settings', { portal_live: !o.live }); V.toast(o.live ? 'Hidden' : 'Live! 🎉'); route();
    };
  }
  function row(a, b) { return '<tr><td><b>' + esc(a) + '</b></td><td>' + esc(b) + '</td></tr>'; }

  // ------------------------------------------------------------ queue
  async function viewQueue() {
    var stSel = sessionStorage.getItem('vt_q') || 'submitted';
    var r = await api('GET', '/api/admin/submissions?status=' + encodeURIComponent(stSel));
    var opts = [['submitted', 'Pending review'], ['changes_requested', 'Changes requested'], ['approved', 'Approved (not published)'], ['published', 'Published'], ['rejected', 'Rejected'], ['all', 'All']];
    var pane = shell('queue', '<div class="vt-between"><select id="sf" style="max-width:260px">' + opts.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === stSel ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select><span class="vt-muted">' + r.submissions.length + ' item(s) · oldest first</span></div>' +
      (r.submissions.length ? '<div class="vt-scroll" style="margin-top:10px"><table class="vt-table"><thead><tr><th>Review ID</th><th>Place</th><th>Contributor</th><th>Words</th><th>Photos</th><th>Reel</th><th>Status</th><th>Submitted</th></tr></thead><tbody>' +
        r.submissions.map(function (x) { return '<tr class="click" data-id="' + x.id + '"><td><b>' + esc(x.reviewId) + '</b></td><td>' + (V.ICON[x.pillar] || '') + ' ' + esc(x.placeName) + '<br><small class="vt-muted">' + esc([x.area, x.city].filter(Boolean).join(', ')) + '</small></td><td>' + esc(x.contributor) + '<br><small>' + esc(x.contributorId) + '</small></td><td>' + x.words + '</td><td>' + x.photos + '</td><td>' + (x.hasReel ? '🎬' : '–') + '</td><td>' + V.badge(x.status) + '</td><td>' + V.dateTime(x.submittedAt) + '</td></tr>'; }).join('') +
        '</tbody></table></div>' : '<div class="vt-card vt-soft" style="margin-top:10px">Nothing here 🎉</div>'));
    pane.querySelector('#sf').onchange = function (e) { sessionStorage.setItem('vt_q', e.target.value); route(); };
    pane.querySelectorAll('tr[data-id]').forEach(function (tr) { tr.onclick = function () { location.hash = '#/review/' + tr.getAttribute('data-id'); }; });
  }

  async function viewReview(id) {
    var r = await api('GET', '/api/admin/submissions/' + id), s = r.submission, c = r.contributor;
    var P = r.pillars[s.pillar] || { name: '', f: ['1', '2', '3'] };
    var editable = s.status !== 'published';
    var t = function (label, name, val, area) { return '<div class="vt-field"><label>' + label + '</label>' + (area ? '<textarea name="' + name + '" rows="' + (name === 'body' ? 14 : 4) + '"' + (editable ? '' : ' disabled') + '>' + esc(val || '') + '</textarea>' : '<input class="vt-input" name="' + name + '" value="' + esc(val == null ? '' : val) + '"' + (editable ? '' : ' disabled') + '>') + '</div>'; };
    var pane = shell('queue', '<p><a href="#/queue">← Back to queue</a></p>' +
      '<div class="vt-between"><h2 style="margin:0">' + (V.ICON[s.pillar] || '') + ' ' + esc(s.placeName) + ' <span class="vt-chip">' + esc(s.reviewId) + '</span></h2>' + V.badge(s.status) + '</div>' +
      '<div class="vt-card vt-soft" style="margin-top:12px"><b><a href="#/contributor/' + c.id + '">' + esc(c.name) + '</a></b> · ' + esc(c.contributorId) + ' · ' + esc(c.email) + (c.instagram ? ' · @' + esc(c.instagram) : '') + '<br><span class="vt-muted">Level ' + c.level.level + ' ' + esc(c.level.name) + ' · ' + c.approved + ' approved · submitted ' + V.dateTime(s.submittedAt) + ' · ' + s.words + ' words</span></div>' +
      (s.adminNote ? '<div class="vt-note">Last note: ' + esc(s.adminNote) + '</div>' : '') +
      '<form id="ed"><div class="vt-card"><div class="vt-two">' + t('Place name', 'placeName', s.placeName) + t('Area', 'area', s.area) + t('City', 'city', s.city) + t('Visit date', 'visitDate', s.visitDate) +
      t('Paid', 'pricePaid', s.pricePaid) + t('Timings', 'timings', s.timings) + t('Parking', 'parking', s.parking) + t('Crowd', 'crowd', s.crowd) + '</div><div class="vt-three">' +
      t(esc(P.f[0]), 'score1', s.score1) + t(esc(P.f[1]), 'score2', s.score2) + t(esc(P.f[2]), 'score3', s.score3) + '</div>' +
      t('Title', 'title', s.title) + t('Review', 'body', s.body, true) + t('Tips', 'tips', s.tips, true) + t('Best for', 'bestFor', s.bestFor) +
      (editable ? '<button class="vt-btn small ghost">Save edits</button>' : '') + '</div></form>' +
      '<div class="vt-card"><h3>Photos (' + s.photos.length + ')</h3><div class="vt-photos">' + s.photos.map(function (p) { return '<div class="vt-photo"><img src="' + esc(p.url) + '" alt=""></div>'; }).join('') + '</div>' +
      (s.reelUrl ? '<p>🎬 Reel/Short: <a href="' + esc(s.reelUrl) + '" target="_blank" rel="noopener">' + esc(s.reelUrl) + '</a> ' + (s.reelReady ? '(confirmed ready to post)' : '') + '</p>' : '<p class="vt-muted">No reel submitted.</p>') + '</div>' +
      decisionBox(s, r) + '<div id="pub"></div>');
    pane.querySelectorAll('.vt-photo img').forEach(function (i) { i.onclick = function () { V.photoViewer(i.src); }; });
    var ed = pane.querySelector('#ed');
    ed.onsubmit = async function (e) { e.preventDefault(); try { await api('PATCH', '/api/admin/submissions/' + id, Object.fromEntries(new FormData(ed))); V.toast('Edits saved'); } catch (ex) { V.toast(ex.message, true); } };
    pane.querySelectorAll('[data-act]').forEach(function (b) {
      b.onclick = async function () {
        var act = b.getAttribute('data-act'), note = pane.querySelector('#note').value;
        var body = { action: act, note: note };
        if (act === 'approve') { body.points = Number(pane.querySelector('#pts').value); var rc = pane.querySelector('#reel'); body.reelAccepted = !!(rc && rc.checked); }
        if (act !== 'approve' && note.trim().length < 5) { V.toast('Please write a note for the contributor.', true); return; }
        if (!confirm({ approve: 'Approve and award points?', changes: 'Send back for changes?', reject: 'Reject this review?' }[act])) return;
        try { await api('POST', '/api/admin/submissions/' + id + '/decision', body); V.toast('Done'); route(); } catch (ex) { V.toast(ex.message, true); }
      };
    });
    var pubBtn = pane.querySelector('#publish');
    if (pubBtn) pubBtn.onclick = async function () {
      if (!confirm('Publish this review to vibeistic.in? This commits the page and photos to GitHub and Cloudflare will rebuild the site.')) return;
      pubBtn.disabled = true; pubBtn.textContent = 'Publishing…';
      try { var p = await api('POST', '/api/admin/submissions/' + id + '/publish', {}); V.toast('Published at ' + p.url); route(); } catch (ex) { V.toast(ex.message, true); pubBtn.disabled = false; pubBtn.textContent = 'Publish to website'; }
    };
    var mdBtn = pane.querySelector('#md');
    if (mdBtn) mdBtn.onclick = async function () {
      try {
        var m = await api('GET', '/api/admin/submissions/' + id + '/markdown');
        pane.querySelector('#pub').innerHTML = '<div class="vt-card"><h3>Manual publishing</h3><ol style="padding-left:20px"><li>Save the text below as <b>src/content/reviews/' + esc(m.slug) + '.md</b></li><li>Download each photo and save it with the name shown, into <b>public/uploads/</b></li><li>Build, commit and push. Then click “Mark as published”.</li></ol>' +
          '<textarea id="mdt" rows="14" style="font-family:monospace;font-size:13px">' + esc(m.markdown) + '</textarea><p class="vt-row" style="margin:8px 0"><button class="vt-btn small" id="cpm">Copy Markdown</button></p>' +
          '<ul>' + m.files.map(function (f) { return '<li><a href="' + esc(f.url) + '" download="' + esc(f.path.split('/').pop()) + '">Download photo</a> → save as <code>' + esc(f.path) + '</code></li>'; }).join('') + '</ul>' +
          '<div class="vt-row"><input class="vt-input" id="slug" value="' + esc(m.slug) + '" style="max-width:360px"><button class="vt-btn small green" id="mp">Mark as published</button></div></div>';
        pane.querySelector('#cpm').onclick = function () { navigator.clipboard.writeText(m.markdown).then(function () { V.toast('Copied'); }); };
        pane.querySelector('#mp').onclick = async function () { try { await api('POST', '/api/admin/submissions/' + id + '/mark-published', { slug: pane.querySelector('#slug').value }); V.toast('Marked as published'); route(); } catch (ex) { V.toast(ex.message, true); } };
      } catch (ex) { V.toast(ex.message, true); }
    };
  }
  function decisionBox(s, r) {
    if (s.status === 'submitted') {
      return '<div class="vt-card"><h3>Decision</h3><div class="vt-two"><div class="vt-field"><label>Points for this review (' + r.pointsMin + '–' + r.pointsMax + ')</label><input class="vt-input" id="pts" type="number" min="' + r.pointsMin + '" max="' + r.pointsMax + '" value="' + r.pointsDefault + '"></div>' +
        (s.reelUrl ? '<label class="vt-check" style="margin-top:28px"><input type="checkbox" id="reel"> Reel/Short accepted (+' + r.reelBonus + ' bonus points)</label>' : '<div></div>') + '</div>' +
        '<div class="vt-field"><label>Note to contributor (required for changes / reject)</label><textarea id="note" rows="3" placeholder="e.g. Please add parking details and one landscape photo."></textarea></div>' +
        '<p class="vt-muted" style="font-size:13px">Points reward effort and helpfulness, never a positive opinion. Don\'t lower points because of a low score.</p>' +
        '<div class="vt-row"><button class="vt-btn green" data-act="approve">Approve</button><button class="vt-btn" data-act="changes">Request changes</button><button class="vt-btn red" data-act="reject">Reject</button></div></div>';
    }
    if (s.status === 'approved') {
      return '<div class="vt-card"><h3>Publish</h3><p>Approved · ' + (s.pointsAwarded + s.reelPoints) + ' points awarded. The page will show “Reader review by ' + esc(r.contributor.name) + '”.</p><div class="vt-row"><button class="vt-btn green" id="publish">Publish to website</button><button class="vt-btn ghost" id="md">Download Markdown (manual)</button></div></div><input type="hidden" id="note">';
    }
    if (s.status === 'published') return '<div class="vt-note green">Live at <a href="' + esc(s.publishedUrl) + '" target="_blank">' + esc(s.publishedUrl) + '</a></div><input type="hidden" id="note">';
    return '<input type="hidden" id="note">';
  }

  // ------------------------------------------------------------ contributors
  async function viewContributors() {
    var q = sessionStorage.getItem('vt_cq') || '';
    var r = await api('GET', '/api/admin/contributors?q=' + encodeURIComponent(q));
    var pane = shell('contributors', '<div class="vt-between"><input class="vt-input" id="q" placeholder="Search name, email or VT-ID" value="' + esc(q) + '" style="max-width:320px"><a class="vt-btn small ghost" href="/api/admin/export/contributors.csv">Export CSV</a></div>' +
      '<div class="vt-scroll" style="margin-top:10px"><table class="vt-table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>City</th><th>Approved</th><th>Level</th><th>Points</th><th>₹</th><th>Status</th></tr></thead><tbody>' +
      r.contributors.map(function (x) { return '<tr class="click" data-id="' + x.id + '"><td><b>' + esc(x.contributor_id) + '</b></td><td>' + esc(x.name) + (x.deletion_requested_at ? ' <span class="vt-badge st-changes_requested">deletion requested</span>' : '') + '</td><td>' + esc(x.email) + '</td><td>' + esc(x.city || '') + '</td><td>' + x.approved + ' / ' + x.submitted + '</td><td>' + x.level.level + ' ' + esc(x.level.name) + '</td><td>' + x.points + '</td><td>' + V.money(x.balanceInr) + '</td><td>' + esc(x.status) + '</td></tr>'; }).join('') +
      '</tbody></table></div>');
    var qi = pane.querySelector('#q'), tm;
    qi.oninput = function () { clearTimeout(tm); tm = setTimeout(function () { sessionStorage.setItem('vt_cq', qi.value); route(); }, 400); };
    pane.querySelectorAll('tr[data-id]').forEach(function (tr) { tr.onclick = function () { location.hash = '#/contributor/' + tr.getAttribute('data-id'); }; });
  }
  async function viewContributor(id) {
    var r = await api('GET', '/api/admin/contributors/' + id), u = r.contributor, st = r.stats;
    var pane = shell('contributors', '<p><a href="#/contributors">← All contributors</a></p><div class="vt-between"><h2 style="margin:0">' + esc(u.name) + ' <span class="vt-chip">' + esc(u.contributorId) + '</span></h2><span>' + esc(r.status) + '</span></div>' +
      '<p class="vt-muted">' + esc(u.email) + ' · ' + esc(u.phone || 'no phone') + ' · ' + esc(u.city || '') + (u.instagram ? ' · @' + esc(u.instagram) : '') + ' · joined ' + V.date(u.createdAt) + '</p>' +
      (u.deletionRequested ? '<div class="vt-note red">This contributor asked for account deletion. Remove their published reviews from the site if needed, then click “Anonymise account”.</div>' : '') +
      '<div class="vt-grid" style="margin-top:10px">' + stat(st.approved, 'Approved') + stat(st.underReview, 'Under review') + stat('L' + st.level.current.level + ' ' + st.level.current.name, 'Level') + stat(st.points, 'Points') + stat(V.money(st.balanceInr), 'Balance', true) + stat(V.money(st.paidInr), 'Paid') + '</div>' +
      '<div class="vt-card" style="margin-top:12px"><h3>Adjust points</h3><div class="vt-row"><input class="vt-input" id="ap" type="number" placeholder="e.g. 50 or -20" style="max-width:160px"><input class="vt-input" id="an" placeholder="Reason (shown in ledger)" style="max-width:340px"><button class="vt-btn small" id="adj">Apply</button></div></div>' +
      '<div class="vt-card"><h3>Account</h3><div class="vt-row">' + (r.status === 'active' ? '<button class="vt-btn small red" data-a="block">Block</button>' : r.status === 'blocked' ? '<button class="vt-btn small green" data-a="unblock">Unblock</button>' : '') +
      '<button class="vt-btn small ghost" data-a="reset-link">Create password reset link</button><button class="vt-btn small red" data-a="anonymize">Anonymise account</button></div><div id="out"></div></div>' +
      (u.address ? '<div class="vt-card"><h3>Gift delivery address</h3><p>' + esc(u.address) + '</p></div>' : '') +
      '<h2>Points ledger</h2><div class="vt-scroll"><table class="vt-table"><thead><tr><th>Date</th><th>Points</th><th>Type</th><th>Note</th></tr></thead><tbody>' +
      r.ledger.map(function (l) { return '<tr><td>' + V.date(l.created_at) + '</td><td><b>' + (l.points > 0 ? '+' : '') + l.points + '</b></td><td>' + esc(l.kind) + '</td><td>' + esc(l.note || '') + '</td></tr>'; }).join('') + '</tbody></table></div>');
    pane.querySelector('#adj').onclick = async function () {
      try { await api('POST', '/api/admin/contributors/' + id, { action: 'adjust', points: Number(pane.querySelector('#ap').value), note: pane.querySelector('#an').value }); V.toast('Points updated'); route(); } catch (ex) { V.toast(ex.message, true); }
    };
    pane.querySelectorAll('[data-a]').forEach(function (b) {
      b.onclick = async function () {
        var a = b.getAttribute('data-a');
        if (a === 'anonymize' && !confirm('Permanently anonymise this account? Name, email, phone and address will be erased.')) return;
        if (a === 'block' && !confirm('Block this contributor? They will be logged out.')) return;
        try {
          var res = await api('POST', '/api/admin/contributors/' + id, { action: a });
          if (res.link) pane.querySelector('#out').innerHTML = '<p class="vt-muted" style="margin-top:10px">Send this link to the contributor (valid 24 h):</p><div class="vt-code">' + esc(res.link) + '</div>';
          else { V.toast('Done'); route(); }
        } catch (ex) { V.toast(ex.message, true); }
      };
    });
  }

  // ------------------------------------------------------------ payouts
  async function viewPayouts() {
    var stSel = sessionStorage.getItem('vt_p') || 'requested';
    var r = await api('GET', '/api/admin/payouts?status=' + stSel);
    var pane = shell('payouts', '<div class="vt-between"><select id="sf" style="max-width:220px">' + [['requested', 'To pay'], ['paid', 'Paid'], ['rejected', 'Rejected'], ['all', 'All']].map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === stSel ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select><a class="vt-btn small ghost" href="/api/admin/export/payouts.csv">Export CSV</a></div>' +
      (r.payouts.length ? '<div class="vt-scroll" style="margin-top:10px"><table class="vt-table"><thead><tr><th>Request</th><th>Contributor</th><th>Points</th><th>Amount</th><th>Method</th><th>Status</th><th>Requested</th><th></th></tr></thead><tbody>' +
        r.payouts.map(function (p) { return '<tr><td><b>' + esc(p.payout_ref) + '</b></td><td>' + esc(p.name) + '<br><small>' + esc(p.contributor_id) + '</small></td><td>' + p.points + '</td><td><b>' + V.money(p.amount) + '</b></td><td>' + esc(p.details_hint) + '</td><td>' + V.badge(p.status) + (p.reference ? '<br><small>' + esc(p.reference) + '</small>' : '') + (p.admin_note ? '<br><small>' + esc(p.admin_note) + '</small>' : '') + '</td><td>' + V.date(p.requested_at) + '</td><td>' +
          (p.status === 'requested' ? '<button class="vt-btn small" data-show="' + p.id + '">Pay</button>' : '') + '</td></tr>'; }).join('') + '</tbody></table></div>' : '<div class="vt-card vt-soft" style="margin-top:10px">No payouts here.</div>'));
    pane.querySelector('#sf').onchange = function (e) { sessionStorage.setItem('vt_p', e.target.value); route(); };
    pane.querySelectorAll('[data-show]').forEach(function (b) {
      b.onclick = async function () {
        var pid = b.getAttribute('data-show'), p = r.payouts.filter(function (x) { return String(x.id) === pid; })[0];
        try {
          var d = (await api('GET', '/api/admin/payouts/' + pid + '/details')).details;
          var m = V.modal('<h2 style="margin-top:0">Pay ' + V.money(p.amount) + ' to ' + esc(p.name) + '</h2>' +
            (d.upi ? '<p>UPI ID:</p><div class="vt-code" style="font-size:18px">' + esc(d.upi) + '</div>' : '<p>Bank transfer:</p><div class="vt-code">Name: ' + esc(d.accountName) + '<br>Account: ' + esc(d.accountNo) + '<br>IFSC: ' + esc(d.ifsc) + '</div>') +
            '<p class="vt-muted" style="font-size:13px">Payment details are erased automatically when you mark this paid or rejected.</p>' +
            '<div class="vt-field" style="margin-top:12px"><label>Transaction reference (UTR / UPI ref)</label><input class="vt-input" id="ref"></div>' +
            '<div class="vt-field"><label>Note (optional / reason if rejecting)</label><input class="vt-input" id="pn"></div>' +
            '<div class="vt-row"><button class="vt-btn green" id="paid">Mark as paid</button><button class="vt-btn red" id="rej">Reject & return points</button><button class="vt-btn ghost" data-close>Close</button></div>');
          m.querySelector('#paid').onclick = async function () { try { await api('POST', '/api/admin/payouts/' + pid, { action: 'paid', reference: m.querySelector('#ref').value, note: m.querySelector('#pn').value }); m.remove(); V.toast('Marked paid – the contributor can see it now'); route(); } catch (ex) { V.toast(ex.message, true); } };
          m.querySelector('#rej').onclick = async function () { if (!confirm('Reject and return the points?')) return; try { await api('POST', '/api/admin/payouts/' + pid, { action: 'reject', note: m.querySelector('#pn').value }); m.remove(); route(); } catch (ex) { V.toast(ex.message, true); } };
        } catch (ex) { V.toast(ex.message, true); }
      };
    });
  }

  // ------------------------------------------------------------ gifts
  async function viewGifts() {
    var r = await api('GET', '/api/admin/gifts');
    var pane = shell('gifts', '<p class="vt-muted">Contributors unlock a surprise gift when they reach a gift level. They only see “a surprise is on its way”.</p>' +
      (r.gifts.length ? '<div class="vt-scroll"><table class="vt-table"><thead><tr><th>Contributor</th><th>Level</th><th>Phone</th><th>Address</th><th>Status</th><th></th></tr></thead><tbody>' +
        r.gifts.map(function (g) { return '<tr><td>' + esc(g.name) + '<br><small>' + esc(g.contributor_id) + ' · ' + esc(g.email) + '</small></td><td>' + g.level + '</td><td>' + esc(g.phone || '–') + '</td><td>' + esc(g.address || 'Not added yet') + '</td><td>' + V.badge(g.status) + (g.note ? '<br><small>' + esc(g.note) + '</small>' : '') + '</td><td>' +
          (g.status === 'pending' ? '<button class="vt-btn small green" data-g="' + g.id + '">Mark sent</button>' : V.date(g.sent_at)) + '</td></tr>'; }).join('') + '</tbody></table></div>' : '<div class="vt-card vt-soft">No gifts unlocked yet.</div>'));
    pane.querySelectorAll('[data-g]').forEach(function (b) {
      b.onclick = async function () { var note = prompt('What did you send? (e.g. Vibeistic mug + coffee hamper, courier ref)') || ''; try { await api('POST', '/api/admin/gifts/' + b.getAttribute('data-g'), { note: note }); route(); } catch (ex) { V.toast(ex.message, true); } };
    });
  }

  // ------------------------------------------------------------ settings
  async function viewSettings() {
    var r = await api('GET', '/api/admin/settings'), s = r.settings;
    var levels = JSON.parse(s.levels);
    var n = function (label, key, step, hint) { return '<div class="vt-field"><label>' + label + '</label><input class="vt-input" name="' + key + '" type="number" step="' + (step || 1) + '" value="' + esc(s[key]) + '">' + (hint ? '<small>' + hint + '</small>' : '') + '</div>'; };
    var pane = shell('settings', '<form id="sf">' +
      '<div class="vt-card"><h3>💰 Points & money</h3><div class="vt-three">' + n('Min points per approved review', 'review_points_min') + n('Max points per approved review', 'review_points_max') + n('Default points', 'review_points_default') +
      n('Reel / Short bonus points', 'reel_bonus') + n('₹ value of 1 point', 'inr_per_point', 0.01, 'e.g. 0.5 → 10 points = ₹5') + n('Minimum payout (₹)', 'min_payout_inr') + '</div>' +
      '<p class="vt-muted" id="pv">Now: ' + esc(r.rewardPreview) + '</p>' +
      '<div class="vt-field"><label>Illustrative launch reward text (shown on the Join Us page – leave empty to auto-generate)</label><textarea name="launch_reward_text" rows="3">' + esc(s.launch_reward_text) + '</textarea></div></div>' +
      '<div class="vt-card"><h3>📝 Submission rules</h3><div class="vt-three">' + n('Minimum words', 'min_words') + n('Minimum photos', 'min_photos') + n('Maximum photos', 'max_photos') + n('Payout within (working days)', 'payout_days') + '</div></div>' +
      '<div class="vt-card"><h3>🏅 Contributor levels</h3><p class="vt-muted">Level is based on the number of approved reviews. Tick 🎁 to give a surprise gift at that level.</p><div class="vt-scroll"><table class="vt-table" id="lv"><thead><tr><th>Level</th><th>Name</th><th>Approved reviews needed</th><th>🎁 Gift</th><th></th></tr></thead><tbody></tbody></table></div><button type="button" class="vt-btn small ghost" id="addl">+ Add level</button></div>' +
      '<div class="vt-row"><button class="vt-btn">Save settings</button><button type="button" class="vt-btn ghost" id="rp">New preview link</button></div></form>');
    var tb = pane.querySelector('#lv tbody');
    function drawLevels() {
      tb.innerHTML = levels.map(function (l, i) { return '<tr><td><input class="vt-input" data-i="' + i + '" data-k="level" type="number" value="' + l.level + '" style="width:70px"></td><td><input class="vt-input" data-i="' + i + '" data-k="name" value="' + esc(l.name) + '"></td><td><input class="vt-input" data-i="' + i + '" data-k="min" type="number" value="' + l.min + '" style="width:100px"></td><td><input type="checkbox" data-i="' + i + '" data-k="gift"' + (l.gift ? ' checked' : '') + '></td><td><button type="button" class="vt-link" data-rm="' + i + '">Remove</button></td></tr>'; }).join('');
      tb.querySelectorAll('input').forEach(function (x) { x.oninput = x.onchange = function () { var l = levels[x.getAttribute('data-i')], k = x.getAttribute('data-k'); l[k] = k === 'gift' ? x.checked : k === 'name' ? x.value : parseInt(x.value || '0', 10); }; });
      tb.querySelectorAll('[data-rm]').forEach(function (b) { b.onclick = function () { levels.splice(+b.getAttribute('data-rm'), 1); drawLevels(); }; });
    }
    drawLevels();
    pane.querySelector('#addl').onclick = function () { var last = levels[levels.length - 1] || { level: 0, min: 0 }; levels.push({ level: last.level + 1, name: 'New level', min: last.min + 10, gift: false }); drawLevels(); };
    pane.querySelector('#sf').onsubmit = async function (e) {
      e.preventDefault();
      var d = Object.fromEntries(new FormData(e.target)); d.levels = levels;
      try { await api('PUT', '/api/admin/settings', d); V.toast('Settings saved'); route(); } catch (ex) { V.toast(ex.message, true); }
    };
    pane.querySelector('#rp').onclick = async function () { if (!confirm('Create a new preview link? The old one stops working.')) return; await api('PUT', '/api/admin/settings', { regeneratePreview: true }); V.toast('New preview link created – see Overview'); };
  }

  // ------------------------------------------------------------ reports
  async function viewReports() {
    var r = await api('GET', '/api/admin/reports');
    var max = Math.max.apply(null, r.weekly.map(function (w) { return w.submitted; }).concat([1]));
    var pane = shell('reports', '<div class="vt-grid">' + stat(r.approvalRate + '%', 'Approval rate') + stat(r.reels, 'Reels accepted') + stat(r.pointsIssued, 'Points issued') + stat(V.money(r.inrIssued), 'Value issued') +
      stat(r.pointsRedeemed, 'Points redeemed') + stat(V.money(r.paidInr), 'Paid out (' + r.payoutsPaid + ')', true) + '</div>' +
      '<h2>Submissions per week (last 12 weeks)</h2><div class="vt-card"><div class="vt-bars">' + (r.weekly.length ? r.weekly.map(function (w) { return '<div style="height:' + Math.round((w.submitted / max) * 100) + '%" title="Week ' + esc(w.week) + '"><span>' + w.submitted + '</span></div>'; }).join('') : '<p class="vt-muted">No data yet.</p>') + '</div></div>' +
      '<div class="vt-two"><div><h2>By pillar</h2><table class="vt-table"><thead><tr><th>Pillar</th><th>Submitted</th><th>Approved</th></tr></thead><tbody>' + r.byPillar.map(function (p) { return '<tr><td>' + (V.ICON[p.pillar] || '') + ' ' + esc(p.pillar) + '</td><td>' + p.total + '</td><td>' + p.approved + '</td></tr>'; }).join('') + '</tbody></table></div>' +
      '<div><h2>Top contributors</h2><table class="vt-table"><thead><tr><th>Contributor</th><th>Approved</th><th>Points</th></tr></thead><tbody>' + r.top.map(function (t) { return '<tr><td>' + esc(t.name) + ' <small>' + esc(t.contributor_id) + '</small></td><td>' + t.approved + '</td><td>' + t.points + '</td></tr>'; }).join('') + '</tbody></table></div></div>' +
      '<h2>Exports</h2><div class="vt-row">' + ['submissions', 'contributors', 'payouts', 'ledger'].map(function (x) { return '<a class="vt-btn small ghost" href="/api/admin/export/' + x + '.csv">' + x + '.csv</a>'; }).join('') + '</div>' +
      '<p class="vt-muted" style="margin-top:10px">For page traffic and earnings per published review, use Google Analytics and the Vibe Tribe payout tool on your Mac.</p>');
  }
  async function viewAudit() {
    var r = await api('GET', '/api/admin/audit');
    shell('audit', '<div class="vt-scroll"><table class="vt-table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Target</th><th>Detail</th></tr></thead><tbody>' +
      r.audit.map(function (a) { return '<tr><td>' + V.dateTime(a.created_at) + '</td><td>' + esc(a.actor || '–') + '</td><td>' + esc(a.action) + '</td><td>' + esc(a.target || '') + '</td><td><small>' + esc(a.detail || '') + '</small></td></tr>'; }).join('') + '</tbody></table></div>');
  }
})();
