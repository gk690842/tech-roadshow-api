/* Vibe Tribe – contributor app (login, register, dashboard, review editor, rewards, profile) */
(function () {
  'use strict';
  var V = window.VT, esc = V.esc, api = V.api;
  var root = document.getElementById('vt-app');
  if (!root) return;
  var state = { status: null, cfg: null, me: null };
  var editor = null; // current editor session (autosave timers)

  function go(hash) { if (location.hash === hash) render(); else location.hash = hash; }
  window.addEventListener('hashchange', render);
  window.addEventListener('beforeunload', function () { if (editor) editor.flush(true); });

  async function boot() {
    root.innerHTML = '<p class="vt-muted">Loading…</p>';
    try {
      var r = await Promise.all([api('GET', '/api/status'), api('GET', '/api/public-settings')]);
      state.status = r[0]; state.cfg = r[1];
    } catch (e) { root.innerHTML = '<div class="vt-note red">' + esc(e.message) + '</div>'; return; }
    render();
  }

  async function render() {
    if (editor) { editor.flush(true); editor.stop(); editor = null; }
    var h = location.hash || '';
    if (h.indexOf('#/reset') === 0) return viewReset();
    var u = state.status.user;
    if (!u) return viewAuth(h === '#/register' ? 'register' : h === '#/forgot' ? 'forgot' : 'login');
    if (u.role === 'admin') {
      root.innerHTML = '<div class="vt-card vt-auth"><h1>Admin account</h1><p>You are signed in as an admin. Contributor features use a separate contributor account.</p><p class="vt-row" style="margin-top:12px"><a class="vt-btn" href="/tribe-admin/">Open admin panel</a><button class="vt-btn ghost" id="lo">Log out</button></p></div>';
      root.querySelector('#lo').onclick = logout;
      return;
    }
    try {
      if (h.indexOf('#/edit/') === 0) return await viewEditor(parseInt(h.split('/')[2], 10));
      if (h === '#/new') return viewNew();
      if (h === '#/profile') return await viewProfile();
      return await viewDashboard();
    } catch (e) {
      if (e.status === 401) { state.status.user = null; return viewAuth('login'); }
      root.innerHTML = '<div class="vt-note red">' + esc(e.message) + '</div><p><a class="vt-btn" href="#/">Back to dashboard</a></p>';
    }
  }

  async function logout() {
    try { await api('POST', '/api/auth/logout', {}); } catch (e) {}
    state.status.user = null; go('#/login');
  }

  // ------------------------------------------------------------ auth
  function viewAuth(mode) {
    var tabs = '<div class="vt-tabs" role="tablist"><button class="vt-tab ' + (mode === 'login' ? 'on' : '') + '" data-go="#/login">Log in</button><button class="vt-tab ' + (mode === 'register' ? 'on' : '') + '" data-go="#/register">Join the Vibe Tribe</button></div>';
    var form;
    if (mode === 'register') {
      form = '<form id="f" novalidate>' +
        field('Your name', '<input class="vt-input" name="name" autocomplete="name" required maxlength="60">', 'Shown as “Reader review by …” on published reviews.') +
        field('Email', '<input class="vt-input" name="email" type="email" autocomplete="email" inputmode="email" required>') +
        field('Password', pw('new-password'), 'At least 8 characters.') +
        '<label class="vt-check"><input type="checkbox" name="age18"> I am 18 years or older.</label>' +
        '<label class="vt-check"><input type="checkbox" name="terms"> I agree to the <a href="/vibe-tribe/terms/" target="_blank">Contributor Terms</a> and <a href="/privacy-policy/" target="_blank">Privacy Policy</a>.</label>' +
        '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn full-m" style="width:100%">Create my account</button></form>';
    } else if (mode === 'forgot') {
      form = '<form id="f" novalidate><p class="vt-muted" style="margin-bottom:10px">Enter your registered email and we will help you reset your password.</p>' +
        field('Email', '<input class="vt-input" name="email" type="email" autocomplete="email" required>') +
        '<div class="vt-note vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Send reset link</button><p style="margin-top:10px"><a href="#/login">Back to log in</a></p></form>';
    } else {
      form = '<form id="f" novalidate>' +
        field('Email', '<input class="vt-input" name="email" type="email" autocomplete="email" inputmode="email" required>') +
        field('Password', pw('current-password')) +
        '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Log in</button>' +
        '<p class="vt-between" style="margin-top:10px"><a href="#/forgot">Forgot password?</a><a href="#/register">New here? Join</a></p></form>';
    }
    root.innerHTML = '<div class="vt-auth"><div class="vt-card"><h1>' + (mode === 'register' ? 'Join the Vibe Tribe' : mode === 'forgot' ? 'Reset password' : 'Welcome back') + '</h1>' +
      (mode === 'register' ? '<p class="vt-muted">Free to join. Takes 30 seconds.</p>' : '') + (mode === 'forgot' ? '' : tabs) + form + '</div></div>';
    root.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { go(b.getAttribute('data-go')); }; });
    wirePw();
    var f = root.querySelector('#f'), err = root.querySelector('#err');
    f.onsubmit = async function (e) {
      e.preventDefault();
      var d = Object.fromEntries(new FormData(f));
      var btn = f.querySelector('button.vt-btn'); btn.disabled = true;
      err.classList.add('vt-hidden');
      try {
        if (mode === 'register') {
          await api('POST', '/api/auth/register', { name: d.name, email: d.email, password: d.password, age18: !!d.age18, terms: !!d.terms });
          V.toast('Welcome to the Vibe Tribe! 🎉');
        } else if (mode === 'forgot') {
          var r = await api('POST', '/api/auth/forgot', { email: d.email });
          err.textContent = r.message; err.className = 'vt-note green'; btn.disabled = false; return;
        } else {
          var lr = await api('POST', '/api/auth/login', { email: d.email, password: d.password });
          if (lr.role === 'admin') { location.href = '/tribe-admin/'; return; }
        }
        state.status = await api('GET', '/api/status');
        go('#/');
      } catch (ex) { err.textContent = ex.message; err.classList.remove('vt-hidden'); btn.disabled = false; }
    };
  }
  function field(label, input, hint) { return '<div class="vt-field"><label>' + label + '</label>' + input + (hint ? '<small>' + hint + '</small>' : '') + '</div>'; }
  function pw(ac) { return '<div style="position:relative"><input class="vt-input" name="password" type="password" autocomplete="' + ac + '" required minlength="8" style="padding-right:70px"><button type="button" class="vt-link vt-pw" style="position:absolute;right:12px;top:12px">Show</button></div>'; }
  function wirePw() { root.querySelectorAll('.vt-pw').forEach(function (b) { b.onclick = function () { var i = b.previousElementSibling; i.type = i.type === 'password' ? 'text' : 'password'; b.textContent = i.type === 'password' ? 'Show' : 'Hide'; }; }); }

  function viewReset() {
    var token = new URLSearchParams(location.hash.split('?')[1] || '').get('token') || '';
    root.innerHTML = '<div class="vt-auth"><div class="vt-card"><h1>Choose a new password</h1><form id="f">' + field('New password', pw('new-password'), 'At least 8 characters.') +
      '<div class="vt-note red vt-hidden" id="err"></div><button class="vt-btn" style="width:100%">Save password</button></form></div></div>';
    wirePw();
    var f = root.querySelector('#f');
    f.onsubmit = async function (e) {
      e.preventDefault();
      try { await api('POST', '/api/auth/reset', { token: token, password: new FormData(f).get('password') }); V.toast('Password updated. Please log in.'); go('#/login'); }
      catch (ex) { var er = root.querySelector('#err'); er.textContent = ex.message; er.classList.remove('vt-hidden'); }
    };
  }

  // ------------------------------------------------------------ dashboard
  async function viewDashboard() {
    var r = await Promise.all([api('GET', '/api/me'), api('GET', '/api/submissions'), api('GET', '/api/payouts')]);
    var me = r[0], subs = r[1].submissions, payouts = r[2].payouts, st = me.stats, s = me.settings;
    state.me = me;
    var lv = st.level, next = lv.next;
    var pct = next ? Math.min(100, Math.round(((st.approved - lv.current.min) / Math.max(1, next.min - lv.current.min)) * 100)) : 100;
    var need = Math.max(0, s.minPayout - st.balanceInr);
    var payPct = Math.min(100, Math.round((st.balanceInr / s.minPayout) * 100));
    var giftHtml = me.gifts.filter(function (g) { return g.status === 'pending'; }).map(function (g) {
      return '<div class="vt-note green">🎁 <b>You unlocked a surprise gift at Level ' + g.level + '!</b> We will contact you soon. Please make sure your delivery address and phone are in your <a href="#/profile">profile</a>.</div>';
    }).join('');

    root.innerHTML =
      '<div class="vt-between"><div><h1>Welcome, ' + esc(me.user.name.split(' ')[0]) + ' 👋</h1>' +
      '<div class="vt-row"><span class="vt-chip" title="Your contributor ID">🆔 ' + esc(me.user.contributorId) + '</span><span class="vt-level">🏅 Level ' + lv.current.level + ' · ' + esc(lv.current.name) + '</span></div></div>' +
      '<div class="vt-row"><a class="vt-btn coral" href="#/new">＋ New review</a><a class="vt-btn ghost" href="#/profile">Profile</a><button class="vt-btn ghost" id="lo">Log out</button></div></div>' +
      (me.user.deletionRequested ? '<div class="vt-note red">You asked us to delete your account. Our team will process it and confirm by email.</div>' : '') +
      giftHtml +
      '<div class="vt-card vt-soft" style="margin-top:16px"><div class="vt-between"><b>' + (next ? 'Level ' + next.level + ' · ' + esc(next.name) + (next.gift ? ' 🎁' : '') : 'Top level reached 🏆') + '</b><span class="vt-muted">' +
      (next ? st.approved + ' / ' + next.min + ' approved reviews' : st.approved + ' approved reviews') + '</span></div><div class="vt-progress"><i style="width:' + pct + '%"></i></div>' +
      (next && next.gift ? '<span class="vt-muted">A surprise gift waits for you at this level.</span>' : '') + '</div>' +
      '<div class="vt-grid">' +
      stat(st.submissions, 'Submissions') + stat(st.underReview, 'Under review') + stat(st.approved, 'Approved') + stat(st.changesRequested, 'Changes requested') +
      stat(st.points, 'Reward points') + stat(V.money(st.balanceInr), 'Equivalent reward', true) + '</div>' +
      '<div class="vt-card" style="margin-top:14px"><div class="vt-between"><div><h3>💸 Reward money</h3><p class="vt-muted">' + esc('10 points = ' + V.money(10 * s.inrPerPoint)) + ' · Paid ' + V.money(st.paidInr) + (st.pendingInr ? ' · In progress ' + V.money(st.pendingInr) : '') + '</p></div>' +
      (st.canRequestPayout ? '<button class="vt-btn green" id="pay">Request Reward Money (' + V.money(st.balanceInr) + ')</button>'
        : st.hasPendingPayout ? '<span class="vt-badge st-requested">Payout in progress</span>'
          : '<button class="vt-btn" disabled title="Unlocks at ' + V.money(s.minPayout) + '">Request Reward Money</button>') + '</div>' +
      (!st.canRequestPayout && !st.hasPendingPayout ? '<div class="vt-progress"><i style="width:' + payPct + '%"></i></div><p class="vt-muted">' + V.money(need) + ' more to unlock. You can request money once your balance reaches ' + V.money(s.minPayout) + '.</p>' : '') + '</div>' +
      '<h2>My submissions</h2>' + (subs.length ? subTable(subs) : '<div class="vt-card vt-soft"><p>No reviews yet. <a href="#/new">Write your first one →</a></p><p class="vt-muted">' + esc(s.rewardText) + '</p></div>') +
      (payouts.length ? '<h2>Payout history</h2><div class="vt-scroll"><table class="vt-table"><thead><tr><th>Request</th><th>Amount</th><th>To</th><th>Status</th><th>Reference</th><th>Requested</th></tr></thead><tbody>' +
        payouts.map(function (p) { return '<tr><td>' + esc(p.payout_ref) + '</td><td>' + V.money(p.amount) + '</td><td>' + esc(p.details_hint) + '</td><td>' + V.badge(p.status) + (p.admin_note ? '<br><small>' + esc(p.admin_note) + '</small>' : '') + '</td><td>' + esc(p.reference || '–') + '</td><td>' + V.date(p.requested_at) + '</td></tr>'; }).join('') +
        '</tbody></table></div>' : '');
    root.querySelector('#lo').onclick = logout;
    var pb = root.querySelector('#pay'); if (pb) pb.onclick = function () { payoutModal(st, s); };
    root.querySelectorAll('[data-del]').forEach(function (b) {
      b.onclick = async function () {
        if (!confirm('Delete this draft? This cannot be undone.')) return;
        try { await api('DELETE', '/api/submissions/' + b.getAttribute('data-del')); localStorage.removeItem('vt_draft_' + b.getAttribute('data-del')); render(); } catch (e) { V.toast(e.message, true); }
      };
    });
  }
  function stat(v, l, hl) { return '<div class="vt-stat' + (hl ? ' hl' : '') + '"><b>' + esc(v) + '</b><span>' + l + '</span></div>'; }
  function subTable(subs) {
    return '<div class="vt-scroll"><table class="vt-table"><thead><tr><th>Review ID</th><th>Place</th><th>Status</th><th>Points</th><th>Updated</th><th></th></tr></thead><tbody>' +
      subs.map(function (x) {
        var editable = x.status === 'draft' || x.status === 'changes_requested';
        return '<tr><td><b>' + esc(x.reviewId) + '</b></td><td>' + (V.ICON[x.pillar] || '📝') + ' ' + esc(x.placeName || 'Untitled') + '<br><small class="vt-muted">' + esc([x.area, x.city].filter(Boolean).join(', ')) + '</small>' +
          (x.adminNote && (x.status === 'changes_requested' || x.status === 'rejected') ? '<div class="vt-note ' + (x.status === 'rejected' ? '' : 'red') + '" style="margin:6px 0 0">💬 ' + esc(x.adminNote) + '</div>' : '') + '</td>' +
          '<td>' + V.badge(x.status) + '</td><td>' + (x.pointsAwarded + x.reelPoints || '–') + '</td><td>' + V.date(x.updatedAt) + '</td><td style="white-space:nowrap">' +
          (editable ? '<a class="vt-btn small" href="#/edit/' + x.id + '">' + (x.status === 'draft' ? 'Continue' : 'Edit & resubmit') + '</a>' : '<a class="vt-btn small ghost" href="#/edit/' + x.id + '">View</a>') +
          (x.publishedUrl ? ' <a class="vt-btn small green" href="' + esc(x.publishedUrl) + '" target="_blank">Live</a>' : '') +
          (x.status === 'draft' ? ' <button class="vt-link" data-del="' + x.id + '">Delete</button>' : '') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  function payoutModal(st, s) {
    var m = V.modal('<h2 style="margin-top:0">Request Reward Money</h2><p>You will receive <b>' + V.money(st.balanceInr) + '</b> for <b>' + st.points + ' points</b>, usually within ' + s.payoutDays + ' working days.</p>' +
      '<form id="pf"><div class="vt-row" style="margin:10px 0"><label class="vt-check"><input type="radio" name="method" value="upi" checked> UPI</label><label class="vt-check"><input type="radio" name="method" value="bank"> Bank transfer</label></div>' +
      '<div id="upi">' + field('UPI ID', '<input class="vt-input" name="upiId" placeholder="name@okbank" autocomplete="off">') + '</div>' +
      '<div id="bank" class="vt-hidden">' + field('Account holder name', '<input class="vt-input" name="accountName">') + field('Account number', '<input class="vt-input" name="accountNo" inputmode="numeric" autocomplete="off">') + field('IFSC code', '<input class="vt-input" name="ifsc" style="text-transform:uppercase" maxlength="11">') + '</div>' +
      '<label class="vt-check"><input type="checkbox" name="confirm"> These details are correct and the account is in my name. Rewards may be taxable; I may be asked for my PAN for larger amounts.</label>' +
      '<p class="vt-muted" style="font-size:12.5px">Your payment details are encrypted and deleted once the payment is completed.</p>' +
      '<div class="vt-note red vt-hidden" id="perr"></div><div class="vt-row" style="margin-top:10px"><button class="vt-btn green">Submit request</button><button type="button" class="vt-btn ghost" data-close>Cancel</button></div></form>');
    var f = m.querySelector('#pf');
    f.querySelectorAll('[name=method]').forEach(function (r) { r.onchange = function () { var b = f.method.value === 'bank'; m.querySelector('#bank').classList.toggle('vt-hidden', !b); m.querySelector('#upi').classList.toggle('vt-hidden', b); }; });
    f.onsubmit = async function (e) {
      e.preventDefault();
      var d = Object.fromEntries(new FormData(f));
      try { var r = await api('POST', '/api/payouts', { method: d.method, upiId: d.upiId, accountName: d.accountName, accountNo: d.accountNo, ifsc: d.ifsc, confirm: !!d.confirm }); m.remove(); V.toast('Request ' + r.payoutRef + ' sent for ' + V.money(r.amount)); render(); }
      catch (ex) { var er = m.querySelector('#perr'); er.textContent = ex.message; er.classList.remove('vt-hidden'); }
    };
  }

  // ------------------------------------------------------------ new review: choose pillar
  function viewNew() {
    var P = state.cfg.pillars;
    root.innerHTML = '<p><a href="#/">← Dashboard</a></p><h1>Choose a pillar</h1><p class="vt-muted">What kind of place are you reviewing?</p><div class="vt-pillars" style="margin-top:14px">' +
      Object.keys(P).map(function (k) { return '<button class="vt-pillar" data-p="' + k + '"><span>' + V.ICON[k] + '</span><b>' + esc(P[k].name) + '</b><br><small class="vt-muted">' + esc(P[k].f.join(' · ')) + '</small></button>'; }).join('') + '</div>';
    root.querySelectorAll('[data-p]').forEach(function (b) {
      b.onclick = async function () {
        b.disabled = true;
        try { var r = await api('POST', '/api/submissions', { pillar: b.getAttribute('data-p') }); go('#/edit/' + r.submission.id); }
        catch (e) { V.toast(e.message, true); b.disabled = false; }
      };
    });
  }

  // ------------------------------------------------------------ editor
  var FIELDS = ['placeName', 'area', 'city', 'visitDate', 'pricePaid', 'timings', 'parking', 'crowd', 'score1', 'score2', 'score3', 'title', 'body', 'tips', 'bestFor', 'reelUrl', 'reelReady'];
  async function viewEditor(id) {
    var sub = (await api('GET', '/api/submissions/' + id)).submission;
    var cfg = state.cfg, P = cfg.pillars[sub.pillar] || { name: '', f: ['Score 1', 'Score 2', 'Score 3'] };
    var editable = sub.status === 'draft' || sub.status === 'changes_requested';
    var key = 'vt_draft_' + id;
    var local = null;
    try { local = JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) {}
    var restored = false;
    if (editable && local && local.savedAt > (sub.updatedAt || 0)) { FIELDS.forEach(function (f) { if (f in local.data) sub[f] = local.data[f]; }); restored = true; }
    var ro = editable ? '' : ' disabled';
    var today = new Date().toISOString().slice(0, 10);

    root.innerHTML = '<p><a href="#/">← Dashboard</a></p>' +
      '<div class="vt-between"><div><h1>' + V.ICON[sub.pillar] + ' ' + esc(sub.placeName || 'New ' + P.name + ' review') + '</h1><div class="vt-row"><span class="vt-chip">' + esc(sub.reviewId) + '</span>' + V.badge(sub.status) + '</div></div>' +
      (editable ? '<span class="vt-save" id="sv" aria-live="polite">' + (restored ? 'Restored your unsaved changes from this device' : 'All changes saved') + '</span>' : '') + '</div>' +
      (sub.adminNote && sub.status === 'changes_requested' ? '<div class="vt-note red"><b>Changes requested by our team:</b> ' + esc(sub.adminNote) + '</div>' : '') +
      (sub.status === 'rejected' && sub.adminNote ? '<div class="vt-note"><b>Not selected:</b> ' + esc(sub.adminNote) + '</div>' : '') +
      (sub.status === 'submitted' ? '<div class="vt-note">⏳ Under review. We usually reply within 7 days.</div>' : '') +
      (sub.status === 'approved' || sub.status === 'published' ? '<div class="vt-note green">✅ Approved · ' + (sub.pointsAwarded + sub.reelPoints) + ' points earned' + (sub.publishedUrl ? ' · <a href="' + esc(sub.publishedUrl) + '" target="_blank">See it live</a>' : '') + '</div>' : '') +
      '<form id="ef" novalidate>' +
      '<div class="vt-card"><h3>📍 Place details</h3><div class="vt-two">' +
      f('Place name *', 'placeName', sub.placeName, 'e.g. Naivedya Thali') + f('Area *', 'area', sub.area, 'e.g. Wakad') +
      f('City *', 'city', sub.city, 'e.g. Pune') + '<div class="vt-field"><label>Date of visit *</label><input class="vt-input" type="date" name="visitDate" max="' + today + '" value="' + esc(sub.visitDate || '') + '"' + ro + '><small>Within the last 12 months.</small></div>' +
      f('What you paid', 'pricePaid', sub.pricePaid, 'e.g. ₹900 for two') + f('Timings', 'timings', sub.timings, 'e.g. 12–4 pm, 7–10:30 pm') +
      f('Parking', 'parking', sub.parking, 'e.g. Free underground') + f('Crowd / best time', 'crowd', sub.crowd, 'e.g. Calm on weekdays') + '</div></div>' +
      '<div class="vt-card"><h3>⭐ Your scores (0–10) *</h3><div class="vt-three">' +
      [1, 2, 3].map(function (n) { return '<div class="vt-field"><label>' + esc(P.f[n - 1]) + '</label><input class="vt-input" type="number" name="score' + n + '" min="0" max="10" step="0.5" inputmode="decimal" value="' + esc(sub['score' + n] == null ? '' : sub['score' + n]) + '"' + ro + '></div>'; }).join('') + '</div>' +
      '<small class="vt-muted">See <a href="/how-we-rate/" target="_blank">How We Rate</a>. Score honestly: points never depend on your scores.</small></div>' +
      '<div class="vt-card"><h3>✍️ Your review</h3>' + f('Title *', 'title', sub.title, 'One line that sums up your visit') +
      '<div class="vt-field"><label>Review * <span class="vt-muted" id="wc"></span></label><textarea name="body" rows="12" placeholder="What did you try or do? How was the taste, service, cleanliness, crowd and value? What should others know? Would you go again?"' + ro + '>' + esc(sub.body || '') + '</textarea><small>Minimum ' + cfg.minWords + ' words, in your own words. No AI-written text, please.</small></div>' +
      '<div class="vt-field"><label>Tips for visitors</label><textarea name="tips" rows="4" placeholder="Best dish, best time, how to reach…"' + ro + '>' + esc(sub.tips || '') + '</textarea></div>' +
      f('Best for', 'bestFor', sub.bestFor, 'e.g. Families, work, dates') + '</div>' +
      '<div class="vt-card"><h3>📸 Photos * <span class="vt-muted">(' + cfg.minPhotos + '–' + cfg.maxPhotos + ', your own)</span></h3><div class="vt-photos" id="ph"></div>' +
      (editable ? '<label class="vt-drop" id="drop"><input type="file" accept="image/*" multiple hidden id="file"><b>Tap to add photos</b><br><small class="vt-muted">JPG or PNG from your phone or laptop. We resize them and remove location data automatically. Include at least 1 landscape photo.</small></label>' : '') +
      '<div class="vt-muted" id="upl" style="margin-top:6px"></div></div>' +
      '<div class="vt-card"><h3>🎬 Reel or Short (optional, +' + cfg.reelBonus + ' bonus points)</h3>' +
      '<p class="vt-muted" style="margin-bottom:8px">Share a link (Google Drive, Instagram, YouTube) to a fully edited, ready-to-post vertical video of this visit. If we use it, you earn bonus points and credit.</p>' +
      f('Link', 'reelUrl', sub.reelUrl, 'https://…') +
      '<label class="vt-check"><input type="checkbox" name="reelReady"' + (sub.reelReady ? ' checked' : '') + ro + '> My video is ready to post, I filmed it myself, it has no copyrighted music I cannot license, and Vibeistic may post it with credit to me.</label></div>' +
      (editable ? '<div class="vt-card"><h3>✅ Declarations *</h3>' +
        chk('ownVisit', 'I personally visited this place on the date above.') + chk('ownPhotos', 'All photos (and the video, if any) were taken by me.') +
        chk('noConflict', 'I have no business, family or job connection with this place.') + chk('noPayment', 'I was not paid or given free services by the place for this review (or I have said so in my review).') +
        chk('terms', 'I agree to the <a href="/vibe-tribe/terms/" target="_blank">Contributor Terms</a>, <a href="/vibe-tribe/#guidelines" target="_blank">Community Guidelines</a> and <a href="/privacy-policy/" target="_blank">Privacy Policy</a>, and I give Vibeistic permission to publish and edit my review and photos.') +
        '<div class="vt-note red vt-hidden" id="err"></div><div class="vt-row" style="margin-top:12px"><button class="vt-btn coral full-m" id="submit">Submit for review</button><button type="button" class="vt-btn ghost full-m" id="savenow">Save draft</button></div></div>' : '') +
      '</form>';

    var form = root.querySelector('#ef');
    var wc = root.querySelector('#wc');
    var updWc = function () { var n = V.words(form.elements.body.value); wc.textContent = '· ' + n + ' / ' + cfg.minWords + ' words'; wc.style.color = n >= cfg.minWords ? '#1f7a4a' : ''; };
    updWc();
    var photos = sub.photos.slice();
    var phBox = root.querySelector('#ph');
    function drawPhotos() {
      phBox.innerHTML = photos.map(function (p) { return '<div class="vt-photo"><img src="' + esc(p.url) + '" alt="Your photo" loading="lazy">' + (editable ? '<button type="button" aria-label="Remove photo" data-rm="' + p.id + '">✕</button>' : '') + '</div>'; }).join('') || '<p class="vt-muted">No photos yet.</p>';
      phBox.querySelectorAll('img').forEach(function (i) { i.onclick = function () { V.photoViewer(i.src); }; });
      phBox.querySelectorAll('[data-rm]').forEach(function (b) {
        b.onclick = async function () {
          try { await api('DELETE', '/api/submissions/' + id + '/photos/' + b.getAttribute('data-rm')); photos = photos.filter(function (p) { return String(p.id) !== b.getAttribute('data-rm'); }); drawPhotos(); }
          catch (e) { V.toast(e.message, true); }
        };
      });
    }
    drawPhotos();
    if (!editable) return;

    var fileIn = root.querySelector('#file'), upl = root.querySelector('#upl');
    fileIn.onchange = async function () {
      var files = Array.prototype.slice.call(fileIn.files);
      fileIn.value = '';
      for (var i = 0; i < files.length; i++) {
        if (photos.length >= cfg.maxPhotos) { V.toast('You can add up to ' + cfg.maxPhotos + ' photos.', true); break; }
        upl.textContent = 'Uploading photo ' + (i + 1) + ' of ' + files.length + '…';
        try {
          var blob = await V.resizeImage(files[i], 1600);
          var r = await api('POST', '/api/submissions/' + id + '/photos', blob);
          photos.push(r.photo); drawPhotos();
        } catch (e) { V.toast(e.message, true); }
      }
      upl.textContent = '';
    };

    // ---- autosave (device + server)
    var sv = root.querySelector('#sv');
    var dirty = restored, tLocal = null, tServer = null, saving = false;
    function collect() {
      var d = {};
      FIELDS.forEach(function (k) { var el = form.elements[k]; if (!el) return; d[k] = el.type === 'checkbox' ? el.checked : el.value; });
      return d;
    }
    function saveLocal() { try { localStorage.setItem(key, JSON.stringify({ savedAt: Math.floor(Date.now() / 1000), data: collect() })); } catch (e) {} }
    async function saveServer(keepalive) {
      if (!dirty || saving) return;
      saving = true; sv.textContent = 'Saving…';
      try {
        await api('PATCH', '/api/submissions/' + id, collect(), { keepalive: keepalive });
        dirty = false; localStorage.removeItem(key);
        sv.textContent = 'Saved ✓ ' + new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      } catch (e) {
        sv.textContent = e.offline ? 'Offline – saved on this device' : 'Not saved: ' + e.message;
      }
      saving = false;
    }
    form.addEventListener('input', function (e) {
      if (e.target.name === 'body') updWc();
      if (e.target.name === 'placeName') root.querySelector('h1').textContent = V.ICON[sub.pillar] + ' ' + (e.target.value || 'New review');
      dirty = true; sv.textContent = 'Unsaved changes…';
      clearTimeout(tLocal); tLocal = setTimeout(saveLocal, 800);
      clearTimeout(tServer); tServer = setTimeout(saveServer, 4000);
    });
    form.addEventListener('change', function () { dirty = true; clearTimeout(tServer); tServer = setTimeout(saveServer, 1500); });
    var interval = setInterval(function () { saveServer(false); }, 20000);
    var onHide = function () { if (document.visibilityState === 'hidden') { saveLocal(); saveServer(true); } };
    document.addEventListener('visibilitychange', onHide);
    editor = { flush: function (k) { if (dirty) { saveLocal(); saveServer(k); } }, stop: function () { clearInterval(interval); clearTimeout(tLocal); clearTimeout(tServer); document.removeEventListener('visibilitychange', onHide); } };
    if (restored) saveServer(false);

    root.querySelector('#savenow').onclick = async function () { dirty = true; saveLocal(); await saveServer(false); };
    form.onsubmit = async function (e) {
      e.preventDefault();
      var err = root.querySelector('#err'); err.classList.add('vt-hidden');
      var btn = root.querySelector('#submit'); btn.disabled = true;
      dirty = true; await saveServer(false);
      var c = {}; ['ownVisit', 'ownPhotos', 'noConflict', 'noPayment', 'terms'].forEach(function (k) { c[k] = form.elements['c_' + k].checked; });
      try {
        var r = await api('POST', '/api/submissions/' + id + '/submit', { consents: c });
        localStorage.removeItem(key);
        editor.stop(); editor = null;
        V.toast('Submitted! Review ID ' + r.reviewId + '. We usually reply within 7 days.');
        go('#/');
      } catch (ex) {
        err.innerHTML = esc(ex.message) + (ex.data && ex.data.errors ? '<ul class="vt-err-list">' + ex.data.errors.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : '');
        err.classList.remove('vt-hidden'); err.scrollIntoView({ behavior: 'smooth', block: 'center' });
        btn.disabled = false;
      }
    };
    function f(label, name, val, ph) { return '<div class="vt-field"><label>' + label + '</label><input class="vt-input" name="' + name + '" value="' + esc(val || '') + '" placeholder="' + esc(ph || '') + '"' + ro + '></div>'; }
    function chk(k, text) { return '<label class="vt-check"><input type="checkbox" name="c_' + k + '"> <span>' + text + '</span></label>'; }
  }

  // ------------------------------------------------------------ profile
  async function viewProfile() {
    var me = await api('GET', '/api/me'), u = me.user;
    root.innerHTML = '<p><a href="#/">← Dashboard</a></p><h1>My profile</h1><p class="vt-row"><span class="vt-chip">🆔 ' + esc(u.contributorId) + '</span><span class="vt-muted">' + esc(u.email) + ' · joined ' + V.date(u.createdAt) + '</span></p>' +
      '<form id="pf" class="vt-card" style="margin-top:14px"><div class="vt-two">' +
      inp('Name (shown on published reviews)', 'name', u.name) + inp('Phone', 'phone', u.phone, 'tel') + inp('City', 'city', u.city) + inp('Instagram handle', 'instagram', u.instagram) + '</div>' +
      '<div class="vt-field"><label>Delivery address (only used to send contributor gifts)</label><textarea name="address" rows="3">' + esc(u.address) + '</textarea></div>' +
      '<button class="vt-btn">Save profile</button></form>' +
      '<form id="cp" class="vt-card"><h3>Change password</h3><div class="vt-two">' +
      '<div class="vt-field"><label>Current password</label><input class="vt-input" type="password" name="current" autocomplete="current-password"></div>' +
      '<div class="vt-field"><label>New password</label><input class="vt-input" type="password" name="password" autocomplete="new-password" minlength="8"></div></div><button class="vt-btn ghost">Update password</button></form>' +
      '<div class="vt-card"><h3>Your data</h3><p class="vt-muted">You can ask us to delete your account and personal data at any time. Published reviews will be removed or anonymised, and unpaid rewards below the minimum will lapse.</p>' +
      (u.deletionRequested ? '<p class="vt-note">Deletion requested. We will confirm by email.</p>' : '<button class="vt-btn red small" id="del">Request account deletion</button>') + '</div>';
    root.querySelector('#pf').onsubmit = async function (e) { e.preventDefault(); try { await api('PATCH', '/api/me', Object.fromEntries(new FormData(e.target))); V.toast('Profile saved'); } catch (ex) { V.toast(ex.message, true); } };
    root.querySelector('#cp').onsubmit = async function (e) { e.preventDefault(); try { await api('POST', '/api/me/password', Object.fromEntries(new FormData(e.target))); e.target.reset(); V.toast('Password updated'); } catch (ex) { V.toast(ex.message, true); } };
    var d = root.querySelector('#del');
    if (d) d.onclick = async function () { if (!confirm('Ask Vibeistic to delete your account and personal data?')) return; try { await api('POST', '/api/me/delete-request', {}); V.toast('Request sent'); render(); } catch (ex) { V.toast(ex.message, true); } };
    function inp(l, n, v, t) { return '<div class="vt-field"><label>' + l + '</label><input class="vt-input" name="' + n + '" type="' + (t || 'text') + '" value="' + esc(v || '') + '"></div>'; }
  }

  boot();
})();
