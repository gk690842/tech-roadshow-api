/* Vibe Tribe – shared helpers */
window.VT = (function () {
  'use strict';
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  async function api(method, path, body, opts) {
    opts = opts || {};
    var headers = { 'x-vt-csrf': '1' };
    var payload = body;
    if (body && !(body instanceof Blob)) { headers['content-type'] = 'application/json'; payload = JSON.stringify(body); }
    if (body instanceof Blob) headers['content-type'] = body.type || 'image/jpeg';
    var res;
    try {
      res = await fetch(path, { method: method, headers: method === 'GET' ? {} : headers, body: method === 'GET' ? undefined : payload, credentials: 'same-origin', keepalive: !!opts.keepalive });
    } catch (e) {
      var ne = new Error('You seem to be offline. Your work is saved on this device.'); ne.offline = true; throw ne;
    }
    var data = null;
    try { data = await res.json(); } catch (e) { data = {}; }
    if (!res.ok) { var err = new Error((data && data.error) || 'Something went wrong.'); err.status = res.status; err.data = data; throw err; }
    return data;
  }
  function toast(msg, isErr) {
    var t = document.createElement('div');
    t.className = 'vt-toast' + (isErr ? ' err' : '');
    t.setAttribute('role', 'status');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, isErr ? 5000 : 2800);
  }
  var money = function (n) { return '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 }); };
  var date = function (ts) { return ts ? new Date(ts * 1000).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '–'; };
  var dateTime = function (ts) { return ts ? new Date(ts * 1000).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '–'; };
  var STATUS = { draft: 'Draft', submitted: 'Under review', changes_requested: 'Changes requested', approved: 'Approved', published: 'Published', rejected: 'Not selected', requested: 'Requested', paid: 'Paid', pending: 'Pending', sent: 'Sent' };
  var badge = function (s) { return '<span class="vt-badge st-' + esc(s) + '">' + esc(STATUS[s] || s) + '</span>'; };
  var ICON = { eat: '🍛', sip: '☕', travel: '🧭', pray: '🛕', play: '⚽', stay: '🏨' };
  function modal(html) {
    var m = document.createElement('div');
    m.className = 'vt-modal';
    m.innerHTML = '<div role="dialog" aria-modal="true">' + html + '</div>';
    m.addEventListener('click', function (e) { if (e.target === m || e.target.closest('[data-close]')) m.remove(); });
    document.addEventListener('keydown', function k(e) { if (e.key === 'Escape') { m.remove(); document.removeEventListener('keydown', k); } });
    document.body.appendChild(m);
    return m;
  }
  function photoViewer(url) { modal('<img src="' + esc(url) + '" alt="" style="width:100%;border-radius:12px"><p style="text-align:right;margin-top:10px"><button class="vt-btn small" data-close>Close</button></p>'); }
  function words(t) { var m = String(t || '').trim().match(/\S+/g); return m ? m.length : 0; }
  async function resizeImage(file, max) {
    max = max || 1600;
    var src;
    try { src = await createImageBitmap(file); }
    catch (e) {
      src = await new Promise(function (res, rej) {
        var i = new Image();
        i.onload = function () { res(i); };
        i.onerror = function () { rej(new Error('This photo format is not supported. Please use JPG or PNG. (iPhone: Settings → Camera → Formats → Most Compatible)')); };
        i.src = URL.createObjectURL(file);
      });
    }
    var w = src.width, h = src.height, scale = Math.min(1, max / Math.max(w, h));
    var c = document.createElement('canvas');
    c.width = Math.round(w * scale); c.height = Math.round(h * scale);
    c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
    return await new Promise(function (res) { c.toBlob(function (b) { res(b); }, 'image/jpeg', 0.82); });
  }
  return { esc: esc, api: api, toast: toast, money: money, date: date, dateTime: dateTime, badge: badge, ICON: ICON, modal: modal, photoViewer: photoViewer, words: words, resizeImage: resizeImage, STATUS: STATUS };
})();
