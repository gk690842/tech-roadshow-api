/**
 * Vibeistic – Vibe Tribe contributor portal (Cloudflare Worker)
 *
 * Serves:
 *   /api/*            JSON API (auth, submissions, photos, rewards, admin)
 *   /vibe-tribe/*     the Join Us pages – shown only when the portal is LIVE,
 *                     or to admins / people with the preview link. Everyone else
 *                     sees the "Our team is working on it" page.
 * Everything else is served straight from the static Astro build (env.ASSETS).
 *
 * Bindings (wrangler.jsonc):  DB (D1, required), ASSETS (static assets), PHOTOS (R2, optional)
 * Secrets (wrangler secret put …):
 *   ADMIN_SETUP_KEY  – one-time key to create the first admin account (required for setup)
 *   DATA_KEY         – encrypts payout (UPI / bank) details (required before payouts)
 *   GITHUB_TOKEN, GITHUB_REPO, GITHUB_BRANCH – optional, for one-click "Publish to website"
 *   BREVO_API_KEY, MAIL_FROM, ADMIN_EMAIL   – optional, for password-reset and status emails
 */

const TERMS_VERSION = 'v1-2026-11';
const PILLARS = {
  eat: { name: 'Eat', f: ['Taste', 'Value', 'Hygiene'] },
  sip: { name: 'Sip', f: ['Brew', 'Vibe', 'Value'] },
  travel: { name: 'Travel', f: ['Experience', 'Access', 'Value'] },
  pray: { name: 'Pray', f: ['Darshan', 'Cleanliness', 'Calm'] },
  play: { name: 'Play', f: ['Facilities', 'Crowd', 'Value'] },
  stay: { name: 'Stay', f: ['Room', 'Location', 'Value'] },
};
const DEFAULTS = {
  portal_live: '0', preview_key: '', review_points_min: '80', review_points_max: '100',
  review_points_default: '90', reel_bonus: '50', inr_per_point: '0.5', min_payout_inr: '300',
  min_words: '250', min_photos: '2', max_photos: '8', payout_days: '15', launch_reward_text: '',
  levels: '[{"level":1,"name":"Explorer","min":0,"gift":false},{"level":2,"name":"Local Guide","min":5,"gift":true},{"level":3,"name":"Vibe Curator","min":15,"gift":true},{"level":4,"name":"Tribe Legend","min":30,"gift":false}]',
};
const FIELDS = {
  pillar: 10, place_name: 120, area: 80, city: 60, visit_date: 10, price_paid: 80, timings: 120,
  parking: 120, crowd: 160, title: 120, body: 12000, tips: 2000, best_for: 160, reel_url: 400,
};
const MAX_PHOTO_BYTES = 4 * 1024 * 1024;
const enc = new TextEncoder();

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const now = () => Math.floor(Date.now() / 1000);
const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex', ...headers },
  });

// ---------------------------------------------------------------- DB helpers
const one = (env, sql, ...b) => env.DB.prepare(sql).bind(...b).first();
const all = async (env, sql, ...b) => (await env.DB.prepare(sql).bind(...b).all()).results || [];
const run = (env, sql, ...b) => env.DB.prepare(sql).bind(...b).run();

// ---------------------------------------------------------------- crypto helpers
function bytesToB64(bytes) {
  let s = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) s += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(s);
}
const b64ToBytes = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
const b64url = (bytes) => bytesToB64(bytes).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const randomBytes = (n) => crypto.getRandomValues(new Uint8Array(n));
const randomToken = (n = 32) => b64url(randomBytes(n));
async function sha256hex(str) {
  const d = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(str)));
  return [...d].map((x) => x.toString(16).padStart(2, '0')).join('');
}
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
async function pbkdf2(password, salt, iter) {
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256));
}
async function hashPassword(password, env) {
  const iter = Math.min(100000, Math.max(10000, parseInt(env.PBKDF2_ITER || '60000', 10)));
  const salt = randomBytes(16);
  return `pbkdf2$${iter}$${bytesToB64(salt)}$${bytesToB64(await pbkdf2(password, salt, iter))}`;
}
async function verifyPassword(password, stored) {
  const [alg, iter, salt, hash] = String(stored || '').split('$');
  if (alg !== 'pbkdf2') return false;
  const got = bytesToB64(await pbkdf2(password, b64ToBytes(salt), parseInt(iter, 10)));
  return safeEqual(got, hash);
}
// TOTP (RFC 6238) for admin two-factor authentication
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Encode(bytes) {
  let bits = 0, value = 0, out = '';
  for (const b of bytes) { value = (value << 8) | b; bits += 8; while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}
function base32Decode(str) {
  const clean = String(str).toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0, value = 0; const out = [];
  for (const c of clean) { value = (value << 5) | B32.indexOf(c); bits += 5; if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; } }
  return new Uint8Array(out);
}
async function totpAt(secret, counter) {
  const key = await crypto.subtle.importKey('raw', base32Decode(secret), { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  const msg = new ArrayBuffer(8); const view = new DataView(msg);
  view.setUint32(0, Math.floor(counter / 2 ** 32)); view.setUint32(4, counter >>> 0);
  const h = new Uint8Array(await crypto.subtle.sign('HMAC', key, msg));
  const o = h[h.length - 1] & 15;
  const code = ((h[o] & 127) << 24 | h[o + 1] << 16 | h[o + 2] << 8 | h[o + 3]) % 1e6;
  return String(code).padStart(6, '0');
}
async function verifyTotp(secret, code) {
  code = String(code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(code) || !secret) return false;
  const c = Math.floor(Date.now() / 30000);
  for (const d of [-1, 0, 1]) if (safeEqual(await totpAt(secret, c + d), code)) return true;
  return false;
}
// AES-GCM encryption for payout details
async function dataKey(env) {
  if (!env.DATA_KEY) throw new HttpError(503, 'Reward payouts are not switched on yet. Please try again later.');
  const raw = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(env.DATA_KEY)));
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
}
async function encryptText(env, text) {
  const iv = randomBytes(12);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await dataKey(env), enc.encode(text)));
  return `v1:${bytesToB64(iv)}:${bytesToB64(ct)}`;
}
async function decryptText(env, blob) {
  const [, iv, ct] = String(blob).split(':');
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64ToBytes(iv) }, await dataKey(env), b64ToBytes(ct));
  return new TextDecoder().decode(pt);
}

// ---------------------------------------------------------------- settings
async function getSettings(env) {
  const rows = await all(env, 'SELECT key, value FROM settings');
  const s = { ...DEFAULTS };
  for (const r of rows) s[r.key] = r.value;
  if (!s.preview_key) {
    s.preview_key = randomToken(12);
    await run(env, 'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'preview_key', s.preview_key);
  }
  let levels;
  try { levels = JSON.parse(s.levels); } catch { levels = JSON.parse(DEFAULTS.levels); }
  levels.sort((a, b) => a.min - b.min);
  const n = (k) => Number(s[k]);
  return {
    raw: s, live: s.portal_live === '1', previewKey: s.preview_key, levels,
    pointsMin: n('review_points_min'), pointsMax: n('review_points_max'), pointsDefault: n('review_points_default'),
    reelBonus: n('reel_bonus'), inrPerPoint: n('inr_per_point'), minPayout: n('min_payout_inr'),
    minWords: n('min_words'), minPhotos: n('min_photos'), maxPhotos: n('max_photos'), payoutDays: n('payout_days'),
    launchRewardText: s.launch_reward_text,
  };
}
const inr = (points, s) => Math.round(points * s.inrPerPoint * 100) / 100;
function rewardText(s) {
  if (s.launchRewardText) return s.launchRewardText;
  return `Approved review: ${s.pointsMin}–${s.pointsMax} points (≈ ₹${inr(s.pointsMin, s)}–${inr(s.pointsMax, s)}). Ready-to-post Reel or Short: +${s.reelBonus} bonus points (≈ ₹${inr(s.reelBonus, s)}). Redeem once you reach ₹${s.minPayout}.`;
}
function levelFor(approved, levels) {
  let current = levels[0];
  for (const l of levels) if (approved >= l.min) current = l;
  const next = levels.find((l) => l.min > approved) || null;
  return { current, next, approved };
}

// ---------------------------------------------------------------- request helpers
function getCookie(req, name) {
  const m = (req.headers.get('cookie') || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return m ? decodeURIComponent(m[1]) : null;
}
const cookie = (name, value, maxAge) =>
  `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
async function body(req) {
  try { return await req.json(); } catch { throw new HttpError(400, 'Invalid request.'); }
}
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const words = (t) => (String(t || '').trim().match(/\S+/g) || []).length;
const emailOk = (e) => /^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/i.test(e);
const ip = (req) => req.headers.get('cf-connecting-ip') || 'local';

async function rateLimit(env, key, max, windowSec) {
  const t = now();
  const row = await one(env, 'SELECT n, reset_at FROM rate_limits WHERE k = ?', key);
  if (!row || row.reset_at < t) {
    await run(env, 'INSERT OR REPLACE INTO rate_limits (k, n, reset_at) VALUES (?, 1, ?)', key, t + windowSec);
    return;
  }
  if (row.n >= max) throw new HttpError(429, 'Too many attempts. Please wait a few minutes and try again.');
  await run(env, 'UPDATE rate_limits SET n = n + 1 WHERE k = ?', key);
}
async function audit(env, actorId, action, target, detail) {
  await run(env, 'INSERT INTO audit_log (actor_id, action, target, detail, created_at) VALUES (?, ?, ?, ?, ?)',
    actorId ?? null, action, target ?? null, detail ? String(detail).slice(0, 1000) : null, now());
}

// ---------------------------------------------------------------- sessions
async function createSession(env, userId, twofaOk, ttl) {
  const token = randomToken(32);
  await run(env, 'INSERT INTO sessions (token_hash, user_id, twofa_ok, expires_at, created_at) VALUES (?, ?, ?, ?, ?)',
    await sha256hex(token), userId, twofaOk ? 1 : 0, now() + ttl, now());
  return cookie('vt_s', token, ttl);
}
async function getAuth(req, env) {
  const tok = getCookie(req, 'vt_s');
  if (!tok) return null;
  const hash = await sha256hex(tok);
  const row = await one(env,
    `SELECT s.token_hash AS s_hash, s.twofa_ok AS s_twofa, s.expires_at AS s_exp, u.*
       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`, hash);
  if (!row || row.s_exp < now() || row.status !== 'active') return null;
  return { user: row, twofa: row.s_twofa === 1, hash };
}
function needUser(auth) {
  if (!auth) throw new HttpError(401, 'Please log in to continue.');
  if (auth.user.role === 'admin' && !auth.twofa) throw new HttpError(401, 'Please complete two-factor sign-in.');
  return auth.user;
}
function needContributor(auth) {
  const u = needUser(auth);
  if (u.role !== 'contributor') throw new HttpError(403, 'Use a contributor account for this page.');
  return u;
}
function needAdmin(auth) {
  if (!auth || auth.user.role !== 'admin') throw new HttpError(403, 'Admins only.');
  if (!auth.twofa) throw new HttpError(401, 'Please complete two-factor sign-in.');
  return auth.user;
}

// ---------------------------------------------------------------- email (optional, Brevo)
async function sendMail(env, to, subject, html) {
  if (!env.BREVO_API_KEY || !env.MAIL_FROM || !to) return false;
  try {
    const r = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { 'api-key': env.BREVO_API_KEY, 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ sender: { name: 'Vibeistic', email: env.MAIL_FROM }, to: [{ email: to }], subject, htmlContent: html }),
    });
    return r.ok;
  } catch { return false; }
}
const mailWrap = (inner) =>
  `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#1d1730"><h2 style="color:#5b2a86">Vibe Tribe · Vibeistic</h2>${inner}<p style="color:#625b70;font-size:13px">hello@vibeistic.in · vibeistic.in</p></div>`;

// ---------------------------------------------------------------- stats
async function userStats(env, uid, s) {
  const c = await one(env,
    `SELECT COUNT(*) AS total,
            SUM(status = 'draft') AS drafts, SUM(status = 'submitted') AS review,
            SUM(status = 'changes_requested') AS changes, SUM(status IN ('approved','published')) AS approved,
            SUM(status = 'rejected') AS rejected
       FROM submissions WHERE user_id = ?`, uid);
  const l = await one(env,
    `SELECT COALESCE(SUM(points),0) AS balance,
            COALESCE(SUM(CASE WHEN kind IN ('review','reel','bonus') THEN points ELSE 0 END),0) AS earned
       FROM points_ledger WHERE user_id = ?`, uid);
  const p = await one(env,
    `SELECT COALESCE(SUM(CASE WHEN status='paid' THEN amount_paise ELSE 0 END),0) AS paid,
            COALESCE(SUM(CASE WHEN status='requested' THEN amount_paise ELSE 0 END),0) AS pending,
            SUM(status='requested') AS pendingCount
       FROM payouts WHERE user_id = ?`, uid);
  const approved = c.approved || 0;
  const balance = l.balance || 0;
  const balanceInr = inr(balance, s);
  return {
    submissions: c.total || 0, drafts: c.drafts || 0, underReview: c.review || 0, changesRequested: c.changes || 0,
    approved, rejected: c.rejected || 0,
    points: balance, pointsEarned: l.earned || 0, balanceInr,
    paidInr: (p.paid || 0) / 100, pendingInr: (p.pending || 0) / 100,
    canRequestPayout: balanceInr >= s.minPayout && !(p.pendingCount > 0),
    hasPendingPayout: (p.pendingCount || 0) > 0,
    level: levelFor(approved, s.levels),
  };
}
const publicUser = (u) => ({
  id: u.id, contributorId: u.contributor_id, name: u.name, email: u.email, phone: u.phone || '', city: u.city || '',
  instagram: u.instagram || '', address: u.address || '', role: u.role, createdAt: u.created_at,
  deletionRequested: !!u.deletion_requested_at,
});
function cleanSubmission(sub, photos) {
  return {
    id: sub.id, reviewId: sub.review_id, pillar: sub.pillar, placeName: sub.place_name, area: sub.area, city: sub.city,
    visitDate: sub.visit_date, pricePaid: sub.price_paid, timings: sub.timings, parking: sub.parking, crowd: sub.crowd,
    score1: sub.score1, score2: sub.score2, score3: sub.score3, title: sub.title, body: sub.body, tips: sub.tips,
    bestFor: sub.best_for, reelUrl: sub.reel_url, reelReady: !!sub.reel_ready, status: sub.status, adminNote: sub.admin_note,
    pointsAwarded: sub.points_awarded, reelPoints: sub.reel_points, publishedUrl: sub.published_url,
    createdAt: sub.created_at, updatedAt: sub.updated_at, submittedAt: sub.submitted_at, decidedAt: sub.decided_at,
    words: words(sub.body),
    photos: (photos || []).map((p) => ({ id: p.id, url: `/api/photos/${p.id}`, size: p.size })),
  };
}
const FIELD_MAP = {
  pillar: 'pillar', placeName: 'place_name', area: 'area', city: 'city', visitDate: 'visit_date', pricePaid: 'price_paid',
  timings: 'timings', parking: 'parking', crowd: 'crowd', title: 'title', body: 'body', tips: 'tips', bestFor: 'best_for', reelUrl: 'reel_url',
};
function pickFields(b) {
  const out = {};
  for (const [k, col] of Object.entries(FIELD_MAP)) if (k in b) out[col] = str(b[k], FIELDS[col]);
  if ('pillar' in out && out.pillar && !PILLARS[out.pillar]) throw new HttpError(400, 'Please choose a valid pillar.');
  for (const k of ['score1', 'score2', 'score3']) {
    if (k in b) {
      if (b[k] === '' || b[k] === null) out[k] = null;
      else {
        const v = Number(b[k]);
        if (!Number.isFinite(v) || v < 0 || v > 10) throw new HttpError(400, 'Scores must be between 0 and 10.');
        out[k] = Math.round(v * 10) / 10;
      }
    }
  }
  if ('reelReady' in b) out.reel_ready = b.reelReady ? 1 : 0;
  return out;
}
async function updateSubmission(env, id, fields) {
  const cols = Object.keys(fields);
  if (!cols.length) return;
  await run(env, `UPDATE submissions SET ${cols.map((c) => `${c} = ?`).join(', ')}, updated_at = ? WHERE id = ?`,
    ...cols.map((c) => fields[c]), now(), id);
}
async function loadOwnSubmission(env, id, uid) {
  const sub = await one(env, 'SELECT * FROM submissions WHERE id = ? AND user_id = ?', id, uid);
  if (!sub) throw new HttpError(404, 'Submission not found.');
  return sub;
}
const photosFor = (env, sid) => all(env, 'SELECT id, size, mime, r2_key FROM photos WHERE submission_id = ? ORDER BY position, id', sid);

function validateForSubmit(sub, photoCount, s) {
  const errs = [];
  if (!PILLARS[sub.pillar]) errs.push('Choose a pillar.');
  if (str(sub.place_name, 200).length < 2) errs.push('Add the place name.');
  if (!str(sub.area, 100)) errs.push('Add the area.');
  if (!str(sub.city, 100)) errs.push('Add the city.');
  const vd = Date.parse(sub.visit_date || '');
  if (!vd) errs.push('Add your visit date.');
  else if (vd > Date.now() + 86400000) errs.push('The visit date cannot be in the future.');
  else if (vd < Date.now() - 365 * 86400000) errs.push('Please review places you visited within the last 12 months.');
  if (str(sub.title, 200).length < 5) errs.push('Add a short title (5+ characters).');
  if (words(sub.body) < s.minWords) errs.push(`Your review needs at least ${s.minWords} words (now ${words(sub.body)}).`);
  for (const k of ['score1', 'score2', 'score3']) if (sub[k] === null || sub[k] === undefined) { errs.push('Give all three scores.'); break; }
  if (photoCount < s.minPhotos) errs.push(`Add at least ${s.minPhotos} photos (now ${photoCount}).`);
  if (sub.reel_url) {
    if (!/^https:\/\/\S+$/i.test(sub.reel_url)) errs.push('The Reel/Short link must start with https://');
    if (!sub.reel_ready) errs.push('Confirm your Reel/Short is ready to post and fully yours.');
  }
  return errs;
}

// ---------------------------------------------------------------- photos storage
async function storePhoto(env, sub, user, bytes, mime) {
  const pos = ((await one(env, 'SELECT COALESCE(MAX(position),0) AS m FROM photos WHERE submission_id = ?', sub.id)).m || 0) + 1;
  let r2Key = null, data = null;
  if (env.PHOTOS) {
    r2Key = `tribe/${sub.review_id}/${randomToken(8)}.${mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg'}`;
    await env.PHOTOS.put(r2Key, bytes, { httpMetadata: { contentType: mime } });
  } else data = bytes;
  const r = await run(env,
    'INSERT INTO photos (submission_id, user_id, mime, size, data, r2_key, position, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    sub.id, user.id, mime, bytes.byteLength, data, r2Key, pos, now());
  return r.meta.last_row_id;
}
async function photoBytes(env, pid) {
  const p = await one(env, 'SELECT * FROM photos WHERE id = ?', pid);
  if (!p) return null;
  let bytes;
  if (p.r2_key && env.PHOTOS) {
    const o = await env.PHOTOS.get(p.r2_key);
    if (!o) return null;
    bytes = new Uint8Array(await o.arrayBuffer());
  } else bytes = p.data instanceof Uint8Array ? p.data : new Uint8Array(p.data || []);
  return { ...p, bytes };
}
async function deletePhoto(env, p) {
  if (p.r2_key && env.PHOTOS) await env.PHOTOS.delete(p.r2_key);
  await run(env, 'DELETE FROM photos WHERE id = ?', p.id);
}

// ---------------------------------------------------------------- markdown / publishing
const slugify = (t) => String(t).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
  .replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 70);
const yq = (v) => JSON.stringify(String(v ?? ''));
function buildMarkdown(sub, user, photos, slug) {
  const p = PILLARS[sub.pillar] || PILLARS.eat;
  const area = [sub.area, sub.city].filter(Boolean).join(', ');
  const ext = (ph) => (ph.mime === 'image/png' ? 'png' : ph.mime === 'image/webp' ? 'webp' : 'jpg');
  const files = photos.map((ph, i) => ({ id: ph.id, path: `/uploads/${slug}-${i + 1}.${ext(ph)}` }));
  const avg = Math.round(((sub.score1 + sub.score2 + sub.score3) / 3) * 10) / 10;
  const verdict = str(String(sub.body).split(/(?<=[.!?])\s/)[0], 200);
  const extra = [];
  if (sub.price_paid) extra.push(`  - { icon: "💰", label: "Paid", value: ${yq(sub.price_paid)} }`);
  if (sub.parking) extra.push(`  - { icon: "🚗", label: "Parking", value: ${yq(sub.parking)} }`);
  if (sub.crowd) extra.push(`  - { icon: "👥", label: "Crowd", value: ${yq(sub.crowd)} }`);
  const gallery = files.slice(1).map((f, i) => `  - { image: ${yq(f.path)}, caption: "", alt: ${yq(`${sub.place_name} photo ${i + 2}`)} }`);
  const fm = [
    '---',
    `title: ${yq(sub.place_name + (area ? `, ${area}` : ''))}`,
    `pillar: ${sub.pillar}`,
    `area: ${yq(area || sub.city || '')}`,
    `seoTitle: ${yq(str(`${sub.place_name} ${sub.area || sub.city || ''}: Review & Tips`, 60))}`,
    `seoDescription: ${yq(str(`Reader review of ${sub.place_name}, ${area}: ${sub.title}. Scores, price, timings and tips from a first-hand visit.`, 160))}`,
    `quickAnswer: ${yq(str(sub.title, 300))}`,
    `badge: "Reader review"`,
    `price: ${yq(sub.price_paid || '')}`,
    `verdict: ${yq(verdict)}`,
    `address: ${yq(area)}`,
    `station: ""`,
    `timings: ${yq(sub.timings || '')}`,
    `bestFor: ${yq(sub.best_for || '')}`,
    extra.length ? `extraInfo:\n${extra.join('\n')}` : 'extraInfo: []',
    `score1: ${sub.score1}`, `score2: ${sub.score2}`, `score3: ${sub.score3}`,
    `image: ${yq(files[0]?.path || '')}`,
    `imageAlt: ${yq(`${sub.place_name}, ${area}`)}`,
    gallery.length ? `gallery:\n${gallery.join('\n')}` : 'gallery: []',
    'galleryAfterParagraph: 2',
    `instagramUrl: ""`, `youtubeUrl: ""`, 'faqs: []',
    `published: ${new Date().toISOString().slice(0, 10)}`,
    'sample: false', 'draft: false',
    `contributor: ${yq(user.name)}`,
    `contributorId: ${yq(user.contributor_id)}`,
    `contributorInstagram: ${yq(user.instagram || '')}`,
    '---', '',
  ].join('\n');
  let bodyMd = String(sub.body || '').trim() + '\n';
  if (sub.tips) bodyMd += `\n## Tips\n\n${String(sub.tips).trim()}\n`;
  bodyMd += `\n*Reader review by ${user.name} (${user.contributor_id}), a member of the Vibe Tribe. Scores: ${p.f[0]} ${sub.score1}, ${p.f[1]} ${sub.score2}, ${p.f[2]} ${sub.score3} (overall ${avg}/10). Visited ${sub.visit_date}.*\n`;
  return { markdown: fm + bodyMd, files };
}
async function github(env, method, path, payload) {
  const r = await fetch(`https://api.github.com/repos/${env.GITHUB_REPO}/contents/${path}${method === 'GET' ? `?ref=${env.GITHUB_BRANCH || 'main'}` : ''}`, {
    method,
    headers: { authorization: `Bearer ${env.GITHUB_TOKEN}`, accept: 'application/vnd.github+json', 'user-agent': 'vibeistic-tribe', 'content-type': 'application/json' },
    body: payload ? JSON.stringify(payload) : undefined,
  });
  return r;
}

// ---------------------------------------------------------------- gate for /vibe-tribe/*
async function gate(req, env, url) {
  const s = await getSettings(env);
  const qp = url.searchParams.get('preview');
  if (qp) {
    if (safeEqual(qp, s.previewKey)) {
      url.searchParams.delete('preview');
      return new Response(null, { status: 302, headers: { location: url.pathname + url.search, 'set-cookie': cookie('vt_preview', qp, 30 * 86400) } });
    }
  }
  let allowed = s.live || safeEqual(getCookie(req, 'vt_preview') || '', s.previewKey);
  if (!allowed) {
    const a = await getAuth(req, env);
    allowed = !!(a && a.user.role === 'admin' && a.twofa);
  }
  if (!allowed) {
    const r = await env.ASSETS.fetch(new Request(new URL('/vibe-tribe-soon/', url).toString(), { headers: req.headers }));
    const h = new Headers(r.headers);
    h.set('cache-control', 'no-store'); h.set('x-robots-tag', 'noindex');
    return new Response(r.body, { status: 200, headers: h });
  }
  const r = await env.ASSETS.fetch(req);
  const h = new Headers(r.headers);
  h.set('cache-control', 'no-store');
  if (!s.live || url.pathname.includes('/dashboard')) h.set('x-robots-tag', 'noindex');
  return new Response(r.body, { status: r.status, headers: h });
}

// ---------------------------------------------------------------- API
async function api(req, env, url, ctx) {
  const later = (pr) => (ctx && ctx.waitUntil ? ctx.waitUntil(pr) : pr);
  const path = url.pathname.replace(/\/+$/, '');
  const m = req.method;
  if (m !== 'GET' && m !== 'HEAD' && req.headers.get('x-vt-csrf') !== '1') throw new HttpError(403, 'Request blocked.');
  const seg = path.split('/').slice(2); // after /api
  const auth = await getAuth(req, env);
  const s = await getSettings(env);
  const id = (i) => { const v = parseInt(seg[i], 10); if (!v) throw new HttpError(404, 'Not found.'); return v; };

  // ---------- public
  if (path === '/api/status' && m === 'GET') {
    return json({
      live: s.live, terms: TERMS_VERSION,
      user: auth ? { name: auth.user.name, role: auth.user.role, twofa: auth.twofa, contributorId: auth.user.contributor_id } : null,
      adminExists: !!(await one(env, "SELECT 1 AS x FROM users WHERE role = 'admin' LIMIT 1")),
      setupEnabled: !!env.ADMIN_SETUP_KEY,
    });
  }
  if (path === '/api/public-settings' && m === 'GET') {
    return json({
      pillars: PILLARS, levels: s.levels, pointsMin: s.pointsMin, pointsMax: s.pointsMax, reelBonus: s.reelBonus,
      inrPerPoint: s.inrPerPoint, minPayout: s.minPayout, minWords: s.minWords, minPhotos: s.minPhotos, maxPhotos: s.maxPhotos,
      payoutDays: s.payoutDays, rewardText: rewardText(s), terms: TERMS_VERSION, emailEnabled: !!env.BREVO_API_KEY,
    });
  }

  // ---------- auth
  if (path === '/api/auth/register' && m === 'POST') {
    const b = await body(req);
    await rateLimit(env, `reg:${ip(req)}`, 10, 3600);
    const name = str(b.name, 60), email = str(b.email, 200).toLowerCase(), pw = String(b.password || '');
    if (name.length < 2) throw new HttpError(400, 'Please enter your name.');
    if (!emailOk(email)) throw new HttpError(400, 'Please enter a valid email address.');
    if (pw.length < 8) throw new HttpError(400, 'Use a password with at least 8 characters.');
    if (!b.age18) throw new HttpError(400, 'You must be 18 or older to join the Vibe Tribe.');
    if (!b.terms) throw new HttpError(400, 'Please accept the Contributor Terms and Privacy Policy.');
    if (await one(env, 'SELECT 1 AS x FROM users WHERE email = ?', email)) throw new HttpError(409, 'An account with this email already exists. Please log in.');
    const r = await run(env,
      `INSERT INTO users (name, email, password_hash, role, age_confirmed, terms_version, terms_at, created_at, last_login_at)
       VALUES (?, ?, ?, 'contributor', 1, ?, ?, ?, ?)`, name, email, await hashPassword(pw, env), TERMS_VERSION, now(), now(), now());
    const uid = r.meta.last_row_id;
    const cid = `VT-${String(uid).padStart(4, '0')}`;
    await run(env, 'UPDATE users SET contributor_id = ? WHERE id = ?', cid, uid);
    await audit(env, uid, 'register', cid, email);
    later(sendMail(env, email, 'Welcome to the Vibe Tribe', mailWrap(`<p>Hi ${name},</p><p>Your contributor ID is <b>${cid}</b>. Share your first review from your dashboard.</p>`)));
    return json({ ok: true, contributorId: cid }, 200, { 'set-cookie': await createSession(env, uid, true, 30 * 86400) });
  }
  if (path === '/api/auth/login' && m === 'POST') {
    const b = await body(req);
    const email = str(b.email, 200).toLowerCase();
    await rateLimit(env, `login:${email}`, 8, 900);
    await rateLimit(env, `loginip:${ip(req)}`, 40, 900);
    const u = await one(env, 'SELECT * FROM users WHERE email = ?', email);
    if (!u || !(await verifyPassword(String(b.password || ''), u.password_hash))) throw new HttpError(401, 'Email or password is incorrect.');
    if (u.status !== 'active') throw new HttpError(403, 'This account is not active. Please contact hello@vibeistic.in.');
    await run(env, 'UPDATE users SET last_login_at = ? WHERE id = ?', now(), u.id);
    await run(env, 'DELETE FROM rate_limits WHERE k = ?', `login:${email}`);
    if (u.role === 'admin') {
      const c = await createSession(env, u.id, false, 15 * 60);
      return json({ ok: true, role: 'admin', needs2fa: !!u.totp_enabled, needsTotpSetup: !u.totp_enabled }, 200, { 'set-cookie': c });
    }
    return json({ ok: true, role: 'contributor' }, 200, { 'set-cookie': await createSession(env, u.id, true, 30 * 86400) });
  }
  if (path === '/api/auth/logout' && m === 'POST') {
    if (auth) await run(env, 'DELETE FROM sessions WHERE token_hash = ?', auth.hash);
    return json({ ok: true }, 200, { 'set-cookie': cookie('vt_s', '', 0) });
  }
  if (path === '/api/auth/2fa' && m === 'POST') {
    if (!auth || auth.user.role !== 'admin') throw new HttpError(401, 'Please log in again.');
    const b = await body(req);
    await rateLimit(env, `2fa:${auth.user.id}`, 6, 900);
    if (!auth.user.totp_enabled || !(await verifyTotp(auth.user.totp_secret, b.code))) throw new HttpError(401, 'That code is not valid. Check your authenticator app.');
    await run(env, 'UPDATE sessions SET twofa_ok = 1, expires_at = ? WHERE token_hash = ?', now() + 12 * 3600, auth.hash);
    await audit(env, auth.user.id, 'admin_login', null, ip(req));
    return json({ ok: true }, 200, { 'set-cookie': cookie('vt_s', getCookie(req, 'vt_s'), 12 * 3600) });
  }
  if (path === '/api/auth/2fa/setup' && m === 'POST') {
    if (!auth || auth.user.role !== 'admin') throw new HttpError(401, 'Please log in again.');
    if (auth.user.totp_enabled) throw new HttpError(400, 'Two-factor authentication is already set up.');
    const secret = base32Encode(randomBytes(20));
    await run(env, 'UPDATE users SET totp_pending = ? WHERE id = ?', secret, auth.user.id);
    const label = encodeURIComponent(`Vibeistic Admin:${auth.user.email}`);
    return json({ secret, uri: `otpauth://totp/${label}?secret=${secret}&issuer=Vibeistic&digits=6&period=30` });
  }
  if (path === '/api/auth/2fa/enable' && m === 'POST') {
    if (!auth || auth.user.role !== 'admin') throw new HttpError(401, 'Please log in again.');
    const b = await body(req);
    if (!auth.user.totp_pending || !(await verifyTotp(auth.user.totp_pending, b.code))) throw new HttpError(400, 'That code is not valid. Make sure your phone time is correct and try again.');
    await run(env, 'UPDATE users SET totp_secret = totp_pending, totp_pending = NULL, totp_enabled = 1 WHERE id = ?', auth.user.id);
    await run(env, 'UPDATE sessions SET twofa_ok = 1, expires_at = ? WHERE token_hash = ?', now() + 12 * 3600, auth.hash);
    await audit(env, auth.user.id, '2fa_enabled', null, null);
    return json({ ok: true }, 200, { 'set-cookie': cookie('vt_s', getCookie(req, 'vt_s'), 12 * 3600) });
  }
  if (path === '/api/setup-admin' && m === 'POST') {
    const b = await body(req);
    await rateLimit(env, `setup:${ip(req)}`, 5, 3600);
    if (!env.ADMIN_SETUP_KEY) throw new HttpError(403, 'Admin setup is not enabled. Set the ADMIN_SETUP_KEY secret.');
    if (await one(env, "SELECT 1 AS x FROM users WHERE role = 'admin'")) throw new HttpError(403, 'An admin already exists. Please log in.');
    if (!safeEqual(String(b.setupKey || ''), env.ADMIN_SETUP_KEY)) throw new HttpError(401, 'Setup key is incorrect.');
    const name = str(b.name, 60), email = str(b.email, 200).toLowerCase(), pw = String(b.password || '');
    if (name.length < 2 || !emailOk(email)) throw new HttpError(400, 'Enter a valid name and email.');
    if (pw.length < 12) throw new HttpError(400, 'Admin passwords need at least 12 characters.');
    const r = await run(env,
      `INSERT INTO users (contributor_id, name, email, password_hash, role, age_confirmed, created_at) VALUES ('ADMIN', ?, ?, ?, 'admin', 1, ?)`,
      name, email, await hashPassword(pw, env), now());
    const uid = r.meta.last_row_id;
    await run(env, 'UPDATE users SET contributor_id = ? WHERE id = ?', `ADMIN-${uid}`, uid);
    await audit(env, uid, 'admin_created', email, null);
    return json({ ok: true, needsTotpSetup: true }, 200, { 'set-cookie': await createSession(env, uid, false, 15 * 60) });
  }
  if (path === '/api/auth/forgot' && m === 'POST') {
    const b = await body(req);
    const email = str(b.email, 200).toLowerCase();
    await rateLimit(env, `forgot:${ip(req)}`, 5, 3600);
    const u = await one(env, "SELECT * FROM users WHERE email = ? AND status = 'active'", email);
    if (u && env.BREVO_API_KEY) {
      const t = randomToken(32);
      await run(env, 'INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?, ?, ?)', await sha256hex(t), u.id, now() + 3600);
      const link = `${url.origin}/vibe-tribe/dashboard/#/reset?token=${t}`;
      await sendMail(env, u.email, 'Reset your Vibe Tribe password', mailWrap(`<p>Hi ${u.name},</p><p><a href="${link}">Reset your password</a>. This link expires in 1 hour.</p><p>If you didn't ask for this, ignore this email.</p>`));
    }
    return json({ ok: true, message: env.BREVO_API_KEY
      ? 'If that email is registered, a reset link is on its way.'
      : 'Please email hello@vibeistic.in from your registered email address and we will send you a reset link.' });
  }
  if (path === '/api/auth/reset' && m === 'POST') {
    const b = await body(req);
    const pw = String(b.password || '');
    if (pw.length < 8) throw new HttpError(400, 'Use a password with at least 8 characters.');
    const h = await sha256hex(String(b.token || ''));
    const r = await one(env, 'SELECT * FROM password_resets WHERE token_hash = ?', h);
    if (!r || r.expires_at < now()) throw new HttpError(400, 'This reset link has expired. Please ask for a new one.');
    await run(env, 'UPDATE users SET password_hash = ? WHERE id = ?', await hashPassword(pw, env), r.user_id);
    await run(env, 'DELETE FROM password_resets WHERE user_id = ?', r.user_id);
    await run(env, 'DELETE FROM sessions WHERE user_id = ?', r.user_id);
    await audit(env, r.user_id, 'password_reset', null, null);
    return json({ ok: true });
  }

  // ---------- photos (owner or admin)
  if (seg[0] === 'photos' && seg.length === 2 && m === 'GET') {
    const u = needUser(auth);
    const p = await photoBytes(env, id(1));
    if (!p || (u.role !== 'admin' && p.user_id !== u.id)) throw new HttpError(404, 'Photo not found.');
    return new Response(p.bytes, { headers: { 'content-type': p.mime, 'cache-control': 'private, max-age=3600', 'x-robots-tag': 'noindex' } });
  }

  // ---------- contributor
  if (seg[0] === 'me') {
    if (seg.length === 1 && m === 'GET') {
      const u = needContributor(auth);
      const gifts = await all(env, 'SELECT level, status FROM gifts WHERE user_id = ? ORDER BY level', u.id);
      return json({ user: publicUser(u), stats: await userStats(env, u.id, s), gifts, settings: {
        minPayout: s.minPayout, inrPerPoint: s.inrPerPoint, levels: s.levels, payoutDays: s.payoutDays, rewardText: rewardText(s),
      } });
    }
    if (seg.length === 1 && m === 'PATCH') {
      const u = needContributor(auth);
      const b = await body(req);
      const f = {};
      if ('name' in b) { const n = str(b.name, 60); if (n.length < 2) throw new HttpError(400, 'Please enter your name.'); f.name = n; }
      if ('phone' in b) f.phone = str(b.phone, 20);
      if ('city' in b) f.city = str(b.city, 60);
      if ('instagram' in b) f.instagram = str(b.instagram, 60).replace(/^@/, '');
      if ('address' in b) f.address = str(b.address, 400);
      const cols = Object.keys(f);
      if (cols.length) await run(env, `UPDATE users SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`, ...cols.map((c) => f[c]), u.id);
      return json({ ok: true });
    }
    if (seg[1] === 'password' && m === 'POST') {
      const u = needContributor(auth);
      const b = await body(req);
      if (!(await verifyPassword(String(b.current || ''), u.password_hash))) throw new HttpError(400, 'Current password is incorrect.');
      if (String(b.password || '').length < 8) throw new HttpError(400, 'Use a password with at least 8 characters.');
      await run(env, 'UPDATE users SET password_hash = ? WHERE id = ?', await hashPassword(String(b.password), env), u.id);
      await run(env, 'DELETE FROM sessions WHERE user_id = ? AND token_hash != ?', u.id, auth.hash);
      return json({ ok: true });
    }
    if (seg[1] === 'delete-request' && m === 'POST') {
      const u = needContributor(auth);
      await run(env, 'UPDATE users SET deletion_requested_at = ? WHERE id = ?', now(), u.id);
      await audit(env, u.id, 'deletion_requested', u.contributor_id, null);
      later(sendMail(env, env.ADMIN_EMAIL, `Account deletion request – ${u.contributor_id}`, mailWrap(`<p>${u.name} (${u.email}) asked to delete their account.</p>`)));
      return json({ ok: true });
    }
  }

  if (seg[0] === 'submissions') {
    const u = needContributor(auth);
    if (seg.length === 1 && m === 'GET') {
      const rows = await all(env, 'SELECT * FROM submissions WHERE user_id = ? ORDER BY updated_at DESC', u.id);
      return json({ submissions: rows.map((r) => { const c = cleanSubmission(r); delete c.body; return { ...c, words: words(r.body) }; }) });
    }
    if (seg.length === 1 && m === 'POST') {
      await rateLimit(env, `newsub:${u.id}`, 30, 86400);
      const drafts = await one(env, "SELECT COUNT(*) AS n FROM submissions WHERE user_id = ? AND status = 'draft'", u.id);
      if (drafts.n >= 10) throw new HttpError(400, 'You have 10 drafts already. Finish or delete one first.');
      const b = await body(req);
      const f = pickFields(b);
      const r = await run(env, 'INSERT INTO submissions (user_id, status, created_at, updated_at) VALUES (?, ?, ?, ?)', u.id, 'draft', now(), now());
      const sid = r.meta.last_row_id;
      await run(env, 'UPDATE submissions SET review_id = ? WHERE id = ?', `VR-${String(sid).padStart(6, '0')}`, sid);
      await updateSubmission(env, sid, f);
      const sub = await one(env, 'SELECT * FROM submissions WHERE id = ?', sid);
      return json({ submission: cleanSubmission(sub, []) });
    }
    const sid = id(1);
    const sub = await loadOwnSubmission(env, sid, u.id);
    const editable = sub.status === 'draft' || sub.status === 'changes_requested';
    if (seg.length === 2 && m === 'GET') return json({ submission: cleanSubmission(sub, await photosFor(env, sid)) });
    if (seg.length === 2 && m === 'PATCH') {
      if (!editable) throw new HttpError(400, 'This review can no longer be edited.');
      await updateSubmission(env, sid, pickFields(await body(req)));
      return json({ ok: true, savedAt: now() });
    }
    if (seg.length === 2 && m === 'DELETE') {
      if (sub.status !== 'draft') throw new HttpError(400, 'Only drafts can be deleted.');
      for (const p of await photosFor(env, sid)) await deletePhoto(env, p);
      await run(env, 'DELETE FROM submissions WHERE id = ?', sid);
      return json({ ok: true });
    }
    if (seg[2] === 'photos' && seg.length === 3 && m === 'POST') {
      if (!editable) throw new HttpError(400, 'This review can no longer be edited.');
      const mime = (req.headers.get('content-type') || '').split(';')[0];
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(mime)) throw new HttpError(400, 'Please upload JPG, PNG or WebP photos.');
      const count = (await one(env, 'SELECT COUNT(*) AS n FROM photos WHERE submission_id = ?', sid)).n;
      if (count >= s.maxPhotos) throw new HttpError(400, `You can add up to ${s.maxPhotos} photos.`);
      const bytes = new Uint8Array(await req.arrayBuffer());
      if (!bytes.length || bytes.length > MAX_PHOTO_BYTES) throw new HttpError(400, 'Each photo must be under 4 MB.');
      const pid = await storePhoto(env, sub, u, bytes, mime);
      await run(env, 'UPDATE submissions SET updated_at = ? WHERE id = ?', now(), sid);
      return json({ photo: { id: pid, url: `/api/photos/${pid}`, size: bytes.length } });
    }
    if (seg[2] === 'photos' && seg.length === 4 && m === 'DELETE') {
      if (!editable) throw new HttpError(400, 'This review can no longer be edited.');
      const p = await one(env, 'SELECT * FROM photos WHERE id = ? AND submission_id = ?', id(3), sid);
      if (!p) throw new HttpError(404, 'Photo not found.');
      await deletePhoto(env, p);
      return json({ ok: true });
    }
    if (seg[2] === 'submit' && m === 'POST') {
      if (!editable) throw new HttpError(400, 'This review has already been submitted.');
      const b = await body(req);
      const c = b.consents || {};
      if (!(c.ownVisit && c.ownPhotos && c.noConflict && c.noPayment && c.terms)) throw new HttpError(400, 'Please tick all the declarations before submitting.');
      const errs = validateForSubmit(sub, (await photosFor(env, sid)).length, s);
      if (errs.length) return json({ error: 'Please fix these before submitting.', errors: errs }, 400);
      await run(env, `UPDATE submissions SET status = 'submitted', submitted_at = ?, updated_at = ?, consent_version = ?, consent_at = ? WHERE id = ?`,
        now(), now(), TERMS_VERSION, now(), sid);
      await audit(env, u.id, 'submitted', sub.review_id, sub.status === 'changes_requested' ? 'resubmitted' : null);
      later(sendMail(env, env.ADMIN_EMAIL, `New Vibe Tribe submission ${sub.review_id}`, mailWrap(`<p>${u.name} (${u.contributor_id}) submitted <b>${sub.place_name}</b>.</p>`)));
      return json({ ok: true, reviewId: sub.review_id });
    }
  }

  if (seg[0] === 'payouts') {
    const u = needContributor(auth);
    if (m === 'GET') {
      const rows = await all(env, 'SELECT payout_ref, points, amount_paise, method, details_hint, status, reference, admin_note, requested_at, decided_at FROM payouts WHERE user_id = ? ORDER BY id DESC', u.id);
      return json({ payouts: rows.map((r) => ({ ...r, amount: r.amount_paise / 100 })) });
    }
    if (m === 'POST') {
      const st = await userStats(env, u.id, s);
      if (st.hasPendingPayout) throw new HttpError(400, 'You already have a payout request in progress.');
      if (st.balanceInr < s.minPayout) throw new HttpError(400, `You need at least ₹${s.minPayout} in rewards to request money.`);
      const b = await body(req);
      let details, hint;
      if (b.method === 'upi') {
        const upi = str(b.upiId, 100);
        if (!/^[\w.\-]{2,256}@[a-zA-Z][a-zA-Z0-9.\-]{1,64}$/.test(upi)) throw new HttpError(400, 'Please enter a valid UPI ID (like name@okbank).');
        details = { upi }; hint = `UPI ${upi.replace(/^(.{2}).*(@.*)$/, '$1•••$2')}`;
      } else if (b.method === 'bank') {
        const acc = str(b.accountNo, 20).replace(/\s/g, ''), ifsc = str(b.ifsc, 11).toUpperCase(), holder = str(b.accountName, 80);
        if (!/^\d{9,18}$/.test(acc)) throw new HttpError(400, 'Please enter a valid account number (9–18 digits).');
        if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) throw new HttpError(400, 'Please enter a valid IFSC code.');
        if (holder.length < 2) throw new HttpError(400, 'Please enter the account holder name.');
        details = { accountNo: acc, ifsc, accountName: holder }; hint = `Bank ••••${acc.slice(-4)} · ${ifsc}`;
      } else throw new HttpError(400, 'Choose UPI or bank transfer.');
      if (!b.confirm) throw new HttpError(400, 'Please confirm the payment details are correct and belong to you.');
      const enc1 = await encryptText(env, JSON.stringify(details));
      const points = st.points;
      const r = await run(env,
        'INSERT INTO payouts (user_id, points, amount_paise, method, details_enc, details_hint, status, requested_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        u.id, points, Math.round(inr(points, s) * 100), b.method, enc1, hint, 'requested', now());
      const pid = r.meta.last_row_id;
      const ref = `PO-${String(pid).padStart(5, '0')}`;
      await run(env, 'UPDATE payouts SET payout_ref = ? WHERE id = ?', ref, pid);
      await run(env, "INSERT INTO points_ledger (user_id, payout_id, points, kind, note, created_at) VALUES (?, ?, ?, 'redeem', ?, ?)", u.id, pid, -points, ref, now());
      await audit(env, u.id, 'payout_requested', ref, String(inr(points, s)));
      later(sendMail(env, env.ADMIN_EMAIL, `Payout request ${ref}`, mailWrap(`<p>${u.name} (${u.contributor_id}) requested ₹${inr(points, s)}.</p>`)));
      return json({ ok: true, payoutRef: ref, amount: inr(points, s) });
    }
  }

  // ---------- admin
  if (seg[0] === 'admin') {
    const a = needAdmin(auth);
    const r1 = seg[1];

    if (r1 === 'overview' && m === 'GET') {
      const c = await one(env, `SELECT COUNT(*) AS total, SUM(status='submitted') AS pending, SUM(status IN ('approved','published')) AS approved,
        SUM(status='rejected') AS rejected, SUM(status='changes_requested') AS changes, SUM(status='published') AS published, SUM(status='draft') AS drafts FROM submissions`);
      const users = await one(env, "SELECT COUNT(*) AS n, SUM(deletion_requested_at IS NOT NULL) AS del FROM users WHERE role='contributor' AND status != 'deleted'");
      const pay = await one(env, `SELECT SUM(status='requested') AS n, COALESCE(SUM(CASE WHEN status='requested' THEN amount_paise END),0) AS amt,
        COALESCE(SUM(CASE WHEN status='paid' THEN amount_paise END),0) AS paid FROM payouts`);
      const gifts = await one(env, "SELECT COUNT(*) AS n FROM gifts WHERE status='pending'");
      const pts = await one(env, "SELECT COALESCE(SUM(CASE WHEN points>0 AND kind IN ('review','reel','bonus','adjust') THEN points END),0) AS issued FROM points_ledger");
      return json({
        submissions: c, contributors: users.n || 0, deletionRequests: users.del || 0,
        payouts: { pending: pay.n || 0, pendingAmount: (pay.amt || 0) / 100, paidAmount: (pay.paid || 0) / 100 },
        giftsDue: gifts.n || 0, pointsIssued: pts.issued, live: s.live,
        previewUrl: `${url.origin}/vibe-tribe/?preview=${s.previewKey}`,
        config: { photos: env.PHOTOS ? 'R2' : 'D1', github: !!(env.GITHUB_TOKEN && env.GITHUB_REPO), email: !!env.BREVO_API_KEY, payouts: !!env.DATA_KEY },
      });
    }
    if (r1 === 'submissions') {
      if (seg.length === 2 && m === 'GET') {
        const st = url.searchParams.get('status') || 'submitted';
        const rows = await all(env, `SELECT s.*, u.name AS u_name, u.contributor_id AS u_cid,
            (SELECT COUNT(*) FROM photos p WHERE p.submission_id = s.id) AS photo_count
          FROM submissions s JOIN users u ON u.id = s.user_id
          WHERE ${st === 'all' ? "s.status != 'draft'" : 's.status = ?'} ORDER BY COALESCE(s.submitted_at, s.updated_at) ${st === 'submitted' ? 'ASC' : 'DESC'} LIMIT 200`,
          ...(st === 'all' ? [] : [st]));
        return json({ submissions: rows.map((r) => ({ id: r.id, reviewId: r.review_id, placeName: r.place_name, pillar: r.pillar, area: r.area, city: r.city,
          status: r.status, contributor: r.u_name, contributorId: r.u_cid, submittedAt: r.submitted_at, words: words(r.body), photos: r.photo_count, hasReel: !!r.reel_url })) });
      }
      const sid = id(2);
      const sub = await one(env, 'SELECT * FROM submissions WHERE id = ?', sid);
      if (!sub) throw new HttpError(404, 'Submission not found.');
      const owner = await one(env, 'SELECT * FROM users WHERE id = ?', sub.user_id);
      if (seg.length === 3 && m === 'GET') {
        const st = await userStats(env, owner.id, s);
        return json({ submission: cleanSubmission(sub, await photosFor(env, sid)), contributor: { ...publicUser(owner), approved: st.approved, level: st.level.current },
          pointsMin: s.pointsMin, pointsMax: s.pointsMax, pointsDefault: s.pointsDefault, reelBonus: s.reelBonus, pillars: PILLARS });
      }
      if (seg.length === 3 && m === 'PATCH') {
        if (sub.status === 'published') throw new HttpError(400, 'Published reviews are edited in the website editor.');
        const f = pickFields(await body(req));
        await updateSubmission(env, sid, f);
        await audit(env, a.id, 'admin_edit', sub.review_id, Object.keys(f).join(','));
        return json({ ok: true });
      }
      if (seg[3] === 'decision' && m === 'POST') {
        const b = await body(req);
        const note = str(b.note, 1000);
        if (b.action === 'approve') {
          if (sub.status !== 'submitted') throw new HttpError(400, 'Only submitted reviews can be approved.');
          const pts = Math.round(Number(b.points ?? s.pointsDefault));
          if (!Number.isFinite(pts) || pts < s.pointsMin || pts > s.pointsMax) throw new HttpError(400, `Points must be between ${s.pointsMin} and ${s.pointsMax}.`);
          const reel = b.reelAccepted && sub.reel_url ? s.reelBonus : 0;
          await run(env, `UPDATE submissions SET status='approved', points_awarded=?, reel_points=?, admin_note=?, decided_at=?, decided_by=?, updated_at=? WHERE id=?`,
            pts, reel, note || null, now(), a.id, now(), sid);
          await run(env, "INSERT INTO points_ledger (user_id, submission_id, points, kind, note, created_by, created_at) VALUES (?, ?, ?, 'review', ?, ?, ?)", owner.id, sid, pts, sub.review_id, a.id, now());
          if (reel) await run(env, "INSERT INTO points_ledger (user_id, submission_id, points, kind, note, created_by, created_at) VALUES (?, ?, ?, 'reel', ?, ?, ?)", owner.id, sid, reel, `${sub.review_id} reel`, a.id, now());
          const st = await userStats(env, owner.id, s);
          for (const l of s.levels) if (l.gift && st.approved >= l.min)
            await run(env, 'INSERT OR IGNORE INTO gifts (user_id, level, created_at) VALUES (?, ?, ?)', owner.id, l.level, now());
          await audit(env, a.id, 'approved', sub.review_id, `${pts}+${reel}`);
          later(sendMail(env, owner.email, `Approved: ${sub.place_name}`, mailWrap(`<p>Hi ${owner.name},</p><p>Your review <b>${sub.review_id}</b> was approved. You earned <b>${pts + reel} points</b> (≈ ₹${inr(pts + reel, s)}).</p>`)));
          return json({ ok: true, points: pts, reelPoints: reel });
        }
        if (b.action === 'reject' || b.action === 'changes') {
          if (sub.status !== 'submitted') throw new HttpError(400, 'Only submitted reviews can be updated.');
          if (note.length < 5) throw new HttpError(400, 'Please add a short note for the contributor.');
          const ns = b.action === 'reject' ? 'rejected' : 'changes_requested';
          await run(env, 'UPDATE submissions SET status=?, admin_note=?, decided_at=?, decided_by=?, updated_at=? WHERE id=?', ns, note, now(), a.id, now(), sid);
          await audit(env, a.id, ns, sub.review_id, note);
          later(sendMail(env, owner.email, ns === 'rejected' ? `Update on ${sub.place_name}` : `Changes requested: ${sub.place_name}`,
            mailWrap(`<p>Hi ${owner.name},</p><p>${ns === 'rejected' ? 'Your review was not selected this time.' : 'We need a few changes to your review before approving it.'}</p><p><i>${note.replace(/</g, '&lt;')}</i></p>`)));
          return json({ ok: true, status: ns });
        }
        throw new HttpError(400, 'Unknown action.');
      }
      if (seg[3] === 'markdown' && m === 'GET') {
        if (!['approved', 'published'].includes(sub.status)) throw new HttpError(400, 'Approve the review first.');
        const slug = sub.slug || slugify(`${sub.place_name} ${sub.area || ''} ${sub.city || ''}`);
        const { markdown, files } = buildMarkdown(sub, owner, await photosFor(env, sid), slug);
        return json({ slug, markdown, files: files.map((f) => ({ path: `public${f.path}`, url: `/api/photos/${f.id}` })) });
      }
      if (seg[3] === 'publish' && m === 'POST') {
        if (sub.status !== 'approved') throw new HttpError(400, 'Only approved reviews can be published.');
        if (!env.GITHUB_TOKEN || !env.GITHUB_REPO) throw new HttpError(400, 'Automatic publishing is not set up (GITHUB_TOKEN / GITHUB_REPO). Use “Download Markdown” instead.');
        let slug = slugify(`${sub.place_name} ${sub.area || ''} ${sub.city || ''}`);
        if ((await github(env, 'GET', `src/content/reviews/${slug}.md`)).status === 200) slug = `${slug}-${sub.review_id.toLowerCase()}`;
        const photos = await photosFor(env, sid);
        const { markdown, files } = buildMarkdown(sub, owner, photos, slug);
        const branch = env.GITHUB_BRANCH || 'main';
        for (const f of files) {
          const ph = await photoBytes(env, f.id);
          const r = await github(env, 'PUT', `public${f.path}`, { message: `Vibe Tribe ${sub.review_id}: photo`, content: bytesToB64(ph.bytes), branch });
          if (!r.ok) throw new HttpError(502, `GitHub upload failed (${r.status}). Check the token's permissions.`);
        }
        const r = await github(env, 'PUT', `src/content/reviews/${slug}.md`, { message: `Vibe Tribe ${sub.review_id}: ${sub.place_name}`, content: bytesToB64(enc.encode(markdown)), branch });
        if (!r.ok) throw new HttpError(502, `GitHub upload failed (${r.status}). Check the token's permissions.`);
        await run(env, "UPDATE submissions SET status='published', slug=?, published_url=?, published_at=?, updated_at=? WHERE id=?", slug, `/review/${slug}/`, now(), now(), sid);
        await audit(env, a.id, 'published', sub.review_id, slug);
        later(sendMail(env, owner.email, `Your review is live: ${sub.place_name}`, mailWrap(`<p>Hi ${owner.name},</p><p>Your review is now live on Vibeistic (it may take a few minutes to appear): <a href="${url.origin}/review/${slug}/">${url.origin}/review/${slug}/</a></p>`)));
        return json({ ok: true, url: `/review/${slug}/` });
      }
      if (seg[3] === 'mark-published' && m === 'POST') {
        const b = await body(req);
        const slug = slugify(str(b.slug, 120));
        if (!slug) throw new HttpError(400, 'Enter the page slug you published.');
        await run(env, "UPDATE submissions SET status='published', slug=?, published_url=?, published_at=?, updated_at=? WHERE id=?", slug, `/review/${slug}/`, now(), now(), sid);
        await audit(env, a.id, 'published_manual', sub.review_id, slug);
        return json({ ok: true });
      }
    }
    if (r1 === 'contributors') {
      if (seg.length === 2 && m === 'GET') {
        const q = `%${str(url.searchParams.get('q'), 60).toLowerCase()}%`;
        const rows = await all(env, `SELECT u.id, u.contributor_id, u.name, u.email, u.phone, u.city, u.instagram, u.address, u.status, u.created_at, u.last_login_at, u.deletion_requested_at,
            (SELECT COUNT(*) FROM submissions s WHERE s.user_id=u.id AND s.status IN ('approved','published')) AS approved,
            (SELECT COUNT(*) FROM submissions s WHERE s.user_id=u.id AND s.status != 'draft') AS submitted,
            (SELECT COALESCE(SUM(points),0) FROM points_ledger l WHERE l.user_id=u.id) AS points
          FROM users u WHERE u.role='contributor' AND (lower(u.name) LIKE ? OR lower(u.email) LIKE ? OR lower(u.contributor_id) LIKE ?)
          ORDER BY u.id DESC LIMIT 300`, q, q, q);
        return json({ contributors: rows.map((r) => ({ ...r, balanceInr: inr(r.points, s), level: levelFor(r.approved, s.levels).current })) });
      }
      const uid = id(2);
      const target = await one(env, "SELECT * FROM users WHERE id = ? AND role = 'contributor'", uid);
      if (!target) throw new HttpError(404, 'Contributor not found.');
      if (seg.length === 3 && m === 'GET') {
        const ledger = await all(env, 'SELECT points, kind, note, created_at FROM points_ledger WHERE user_id = ? ORDER BY id DESC LIMIT 100', uid);
        return json({ contributor: publicUser(target), status: target.status, stats: await userStats(env, uid, s), ledger,
          gifts: await all(env, 'SELECT * FROM gifts WHERE user_id = ?', uid) });
      }
      if (seg.length === 3 && m === 'POST') {
        const b = await body(req);
        if (b.action === 'block' || b.action === 'unblock') {
          await run(env, 'UPDATE users SET status = ? WHERE id = ?', b.action === 'block' ? 'blocked' : 'active', uid);
          if (b.action === 'block') await run(env, 'DELETE FROM sessions WHERE user_id = ?', uid);
          await audit(env, a.id, b.action, target.contributor_id, str(b.note, 300));
          return json({ ok: true });
        }
        if (b.action === 'adjust') {
          const pts = Math.round(Number(b.points));
          const note = str(b.note, 300);
          if (!pts || Math.abs(pts) > 100000) throw new HttpError(400, 'Enter a points amount (use minus for deductions).');
          if (note.length < 3) throw new HttpError(400, 'Add a reason for the adjustment.');
          await run(env, "INSERT INTO points_ledger (user_id, points, kind, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)", uid, pts, pts > 0 ? 'bonus' : 'adjust', note, a.id, now());
          await audit(env, a.id, 'points_adjusted', target.contributor_id, `${pts} ${note}`);
          return json({ ok: true });
        }
        if (b.action === 'reset-link') {
          const t = randomToken(32);
          await run(env, 'INSERT INTO password_resets (token_hash, user_id, expires_at) VALUES (?, ?, ?)', await sha256hex(t), uid, now() + 24 * 3600);
          await audit(env, a.id, 'reset_link', target.contributor_id, null);
          return json({ link: `${url.origin}/vibe-tribe/dashboard/#/reset?token=${t}` });
        }
        if (b.action === 'anonymize') {
          await run(env, `UPDATE users SET name='Deleted contributor', email=?, phone=NULL, city=NULL, instagram=NULL, address=NULL, status='deleted', password_hash=? WHERE id=?`,
            `deleted-${uid}@invalid.local`, `x$${randomToken(8)}`, uid);
          await run(env, 'DELETE FROM sessions WHERE user_id = ?', uid);
          await run(env, "UPDATE payouts SET details_enc='erased', details_hint='erased' WHERE user_id = ? AND status != 'requested'", uid);
          await audit(env, a.id, 'anonymized', target.contributor_id, null);
          return json({ ok: true });
        }
        throw new HttpError(400, 'Unknown action.');
      }
    }
    if (r1 === 'gifts') {
      if (seg.length === 2 && m === 'GET') {
        const rows = await all(env, `SELECT g.*, u.name, u.contributor_id, u.phone, u.address, u.email FROM gifts g JOIN users u ON u.id = g.user_id ORDER BY g.status DESC, g.created_at`);
        return json({ gifts: rows });
      }
      if (seg.length === 3 && m === 'POST') {
        const b = await body(req);
        await run(env, "UPDATE gifts SET status='sent', sent_at=?, note=? WHERE id=?", now(), str(b.note, 300), id(2));
        await audit(env, a.id, 'gift_sent', String(id(2)), str(b.note, 300));
        return json({ ok: true });
      }
    }
    if (r1 === 'payouts') {
      if (seg.length === 2 && m === 'GET') {
        const st = url.searchParams.get('status') || 'requested';
        const rows = await all(env, `SELECT p.id, p.payout_ref, p.points, p.amount_paise, p.method, p.details_hint, p.status, p.reference, p.admin_note, p.requested_at, p.decided_at,
            u.name, u.contributor_id, u.email FROM payouts p JOIN users u ON u.id = p.user_id ${st === 'all' ? '' : 'WHERE p.status = ?'} ORDER BY p.id DESC LIMIT 300`, ...(st === 'all' ? [] : [st]));
        return json({ payouts: rows.map((r) => ({ ...r, amount: r.amount_paise / 100 })) });
      }
      const pid = id(2);
      const p = await one(env, 'SELECT * FROM payouts WHERE id = ?', pid);
      if (!p) throw new HttpError(404, 'Payout not found.');
      if (seg[3] === 'details' && m === 'GET') {
        if (p.status !== 'requested') throw new HttpError(400, 'Details are only shown for open requests.');
        await audit(env, a.id, 'payout_details_viewed', p.payout_ref, null);
        return json({ details: JSON.parse(await decryptText(env, p.details_enc)) });
      }
      if (seg.length === 3 && m === 'POST') {
        const b = await body(req);
        if (p.status !== 'requested') throw new HttpError(400, 'This payout is already closed.');
        const owner = await one(env, 'SELECT * FROM users WHERE id = ?', p.user_id);
        if (b.action === 'paid') {
          const ref = str(b.reference, 80);
          if (ref.length < 3) throw new HttpError(400, 'Enter the UPI / bank transaction reference.');
          await run(env, "UPDATE payouts SET status='paid', reference=?, admin_note=?, decided_at=?, decided_by=?, details_enc='erased' WHERE id=?", ref, str(b.note, 300) || null, now(), a.id, pid);
          await audit(env, a.id, 'payout_paid', p.payout_ref, ref);
          later(sendMail(env, owner.email, `Reward paid: ₹${p.amount_paise / 100}`, mailWrap(`<p>Hi ${owner.name},</p><p>We've sent ₹${p.amount_paise / 100} for request ${p.payout_ref}. Reference: <b>${ref}</b>.</p>`)));
          return json({ ok: true });
        }
        if (b.action === 'reject') {
          const note = str(b.note, 300);
          if (note.length < 5) throw new HttpError(400, 'Add a reason so the contributor knows what to fix.');
          await run(env, "UPDATE payouts SET status='rejected', admin_note=?, decided_at=?, decided_by=?, details_enc='erased' WHERE id=?", note, now(), a.id, pid);
          await run(env, "INSERT INTO points_ledger (user_id, payout_id, points, kind, note, created_by, created_at) VALUES (?, ?, ?, 'refund', ?, ?, ?)", p.user_id, pid, p.points, `${p.payout_ref} returned`, a.id, now());
          await audit(env, a.id, 'payout_rejected', p.payout_ref, note);
          return json({ ok: true });
        }
        throw new HttpError(400, 'Unknown action.');
      }
    }
    if (r1 === 'settings') {
      if (m === 'GET') {
        const { preview_key, ...rest } = s.raw;
        return json({ settings: rest, previewUrl: `${url.origin}/vibe-tribe/?preview=${s.previewKey}`, rewardPreview: rewardText(s) });
      }
      if (m === 'PUT') {
        const b = await body(req);
        const out = {};
        const num = (k, lo, hi, integer = true) => {
          if (!(k in b)) return;
          const v = Number(b[k]);
          if (!Number.isFinite(v) || v < lo || v > hi || (integer && !Number.isInteger(v))) throw new HttpError(400, `${k.replace(/_/g, ' ')} must be between ${lo} and ${hi}.`);
          out[k] = String(v);
        };
        num('review_points_min', 1, 10000); num('review_points_max', 1, 10000); num('review_points_default', 1, 10000);
        num('reel_bonus', 0, 10000); num('inr_per_point', 0.01, 100, false); num('min_payout_inr', 1, 100000);
        num('min_words', 50, 3000); num('min_photos', 1, 10); num('max_photos', 1, 12); num('payout_days', 1, 90);
        const merged = { ...s.raw, ...out };
        if (+merged.review_points_max < +merged.review_points_min) throw new HttpError(400, 'Maximum points must be at least the minimum.');
        if (+merged.review_points_default < +merged.review_points_min || +merged.review_points_default > +merged.review_points_max) throw new HttpError(400, 'Default points must be within the min–max range.');
        if (+merged.max_photos < +merged.min_photos) throw new HttpError(400, 'Maximum photos must be at least the minimum.');
        if ('launch_reward_text' in b) out.launch_reward_text = str(b.launch_reward_text, 500);
        if ('portal_live' in b) out.portal_live = b.portal_live ? '1' : '0';
        if ('levels' in b) {
          let lv = b.levels;
          if (typeof lv === 'string') { try { lv = JSON.parse(lv); } catch { throw new HttpError(400, 'Levels must be valid JSON.'); } }
          if (!Array.isArray(lv) || !lv.length || lv.some((l) => !Number.isInteger(l.level) || !l.name || !Number.isInteger(l.min) || l.min < 0))
            throw new HttpError(400, 'Each level needs a level number, a name and a minimum number of approved reviews.');
          out.levels = JSON.stringify(lv.map((l) => ({ level: l.level, name: str(l.name, 40), min: l.min, gift: !!l.gift })));
        }
        if (b.regeneratePreview) out.preview_key = randomToken(12);
        for (const [k, v] of Object.entries(out)) await run(env, 'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', k, v);
        await audit(env, a.id, 'settings_changed', null, JSON.stringify(out).slice(0, 900));
        return json({ ok: true });
      }
    }
    if (r1 === 'reports' && m === 'GET') {
      const since = now() - 84 * 86400;
      const weekly = await all(env, `SELECT strftime('%Y-%W', submitted_at, 'unixepoch') AS week, COUNT(*) AS submitted,
          SUM(status IN ('approved','published')) AS approved FROM submissions WHERE submitted_at >= ? GROUP BY week ORDER BY week`, since);
      const byPillar = await all(env, `SELECT pillar, COUNT(*) AS total, SUM(status IN ('approved','published')) AS approved FROM submissions WHERE status != 'draft' GROUP BY pillar ORDER BY total DESC`);
      const top = await all(env, `SELECT u.contributor_id, u.name, COUNT(*) AS approved, COALESCE(SUM(s.points_awarded + s.reel_points),0) AS points
          FROM submissions s JOIN users u ON u.id = s.user_id WHERE s.status IN ('approved','published') GROUP BY u.id ORDER BY approved DESC, points DESC LIMIT 10`);
      const totals = await one(env, `SELECT SUM(status IN ('approved','published')) AS approved, SUM(status='rejected') AS rejected,
          SUM(status IN ('approved','published','rejected')) AS decided, SUM(reel_points > 0) AS reels FROM submissions`);
      const points = await one(env, `SELECT COALESCE(SUM(CASE WHEN kind IN ('review','reel','bonus') THEN points END),0) AS issued,
          COALESCE(-SUM(CASE WHEN kind='redeem' THEN points END),0) AS redeemed, COALESCE(SUM(CASE WHEN kind='refund' THEN points END),0) AS refunded FROM points_ledger`);
      const paid = await one(env, "SELECT COALESCE(SUM(amount_paise),0) AS paid, COUNT(*) AS n FROM payouts WHERE status='paid'");
      const signups = await all(env, `SELECT strftime('%Y-%W', created_at, 'unixepoch') AS week, COUNT(*) AS n FROM users WHERE role='contributor' AND created_at >= ? GROUP BY week ORDER BY week`, since);
      return json({ weekly, byPillar, top, signups,
        approvalRate: totals.decided ? Math.round((totals.approved / totals.decided) * 100) : 0, reels: totals.reels || 0,
        pointsIssued: points.issued, pointsRedeemed: points.redeemed - points.refunded, inrIssued: inr(points.issued, s), paidInr: paid.paid / 100, payoutsPaid: paid.n });
    }
    if (r1 === 'export' && m === 'GET') {
      const what = (seg[2] || '').replace(/\.csv$/, '');
      const q = {
        submissions: `SELECT s.review_id, u.contributor_id, u.name, s.pillar, s.place_name, s.area, s.city, s.visit_date, s.status, s.points_awarded, s.reel_points,
          datetime(s.submitted_at,'unixepoch') AS submitted, datetime(s.decided_at,'unixepoch') AS decided, s.published_url FROM submissions s JOIN users u ON u.id=s.user_id WHERE s.status != 'draft' ORDER BY s.id`,
        contributors: `SELECT u.contributor_id, u.name, u.email, u.phone, u.city, u.instagram, u.status, datetime(u.created_at,'unixepoch') AS joined,
          (SELECT COUNT(*) FROM submissions s WHERE s.user_id=u.id AND s.status IN ('approved','published')) AS approved,
          (SELECT COALESCE(SUM(points),0) FROM points_ledger l WHERE l.user_id=u.id) AS points_balance FROM users u WHERE u.role='contributor' ORDER BY u.id`,
        payouts: `SELECT p.payout_ref, u.contributor_id, u.name, p.points, p.amount_paise/100.0 AS amount_inr, p.method, p.details_hint, p.status, p.reference,
          datetime(p.requested_at,'unixepoch') AS requested, datetime(p.decided_at,'unixepoch') AS decided FROM payouts p JOIN users u ON u.id=p.user_id ORDER BY p.id`,
        ledger: `SELECT u.contributor_id, l.points, l.kind, l.note, datetime(l.created_at,'unixepoch') AS at FROM points_ledger l JOIN users u ON u.id=l.user_id ORDER BY l.id`,
      }[what];
      if (!q) throw new HttpError(404, 'Unknown export.');
      const rows = await all(env, q);
      const cols = rows.length ? Object.keys(rows[0]) : [];
      const cell = (v) => { const t = v === null || v === undefined ? '' : String(v); const safe = /^[=+\-@]/.test(t) ? `'${t}` : t; return /[",\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe; };
      const csv = [cols.join(','), ...rows.map((r) => cols.map((c) => cell(r[c])).join(','))].join('\n');
      await audit(env, a.id, 'export', what, null);
      return new Response('\ufeff' + csv, { headers: { 'content-type': 'text/csv; charset=utf-8', 'content-disposition': `attachment; filename="vibe-tribe-${what}.csv"`, 'cache-control': 'no-store' } });
    }
    if (r1 === 'audit' && m === 'GET') {
      const rows = await all(env, 'SELECT l.*, u.name AS actor FROM audit_log l LEFT JOIN users u ON u.id = l.actor_id ORDER BY l.id DESC LIMIT 200');
      return json({ audit: rows });
    }
  }
  throw new HttpError(404, 'Not found.');
}

// ---------------------------------------------------------------- entry
export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    const p = url.pathname;
    try {
      if (p.startsWith('/api/')) return await api(req, env, url, ctx);
      if (p === '/vibe-tribe' || p.startsWith('/vibe-tribe/')) return await gate(req, env, url);
      return env.ASSETS.fetch(req);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error(e);
      return p.startsWith('/api/') ? json({ error: 'Something went wrong. Please try again.' }, 500) : new Response('Something went wrong.', { status: 500 });
    }
  },
};
export const _test = { verifyTotp, totpAt, base32Encode, hashPassword, verifyPassword, buildMarkdown, slugify };
