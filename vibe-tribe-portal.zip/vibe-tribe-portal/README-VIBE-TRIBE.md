# Vibe Tribe – Join Us portal (contributors + admin)

End-to-end contributor programme for vibeistic.in, running on your existing Cloudflare Worker:

| Page | Who | What |
|---|---|---|
| `/vibe-tribe/` | Visitors | Join Us landing: what it is, How it works flowchart, rewards, levels, guidelines, editorial independence, sign up / log in |
| `/vibe-tribe/dashboard/` | Contributors | Register / login, Contributor ID, stats, levels, points, ₹ equivalent, review editor with auto-saved drafts and photos, submissions with Review IDs and status, Request Reward Money (UPI / bank), profile, delete request |
| `/vibe-tribe/terms/` | Everyone | Contributor Terms (v1-2026-11) – linked from every consent checkbox |
| `/tribe-admin/` | You | First-time setup, login + 2-factor (TOTP), overview, review queue (approve / request changes / reject, edit, publish), contributors, payouts, gifts, rewards & settings, reports, CSV exports, audit log |
| `/vibe-tribe-soon/` | Visitors (while hidden) | “Our team is working on it” |

**Hidden until you say so.** While the portal is off, every `/vibe-tribe/…` URL shows the “Our team is working on it” page. You (logged in as admin with 2FA) and anyone with the **preview link** see the real pages. Turn it on with **Admin → Overview → Go live**.

---

## 1. Copy the files (Mac)

1. GitHub Desktop → **Fetch origin → Pull origin**.
2. Copy into `~/Desktop/Projects/vibeistic-astro` (replace when asked):
   ```
   worker/index.js
   migrations/0001_vibe_tribe.sql
   public/portal/portal.css, common.js, app.js, admin.js
   public/robots.txt
   src/pages/vibe-tribe/index.astro, dashboard.astro, terms.astro
   src/pages/tribe-admin.astro
   src/pages/vibe-tribe-soon.astro
   src/pages/review/[slug].astro       (adds “Reader review by …”)
   src/content.config.ts               (adds contributor fields)
   astro.config.mjs                    (keeps private pages out of the sitemap)
   wrangler.jsonc
   ```
3. **Delete the old file** `src/pages/vibe-tribe.astro` (it is replaced by `src/pages/vibe-tribe/index.astro`).
4. In `wrangler.jsonc`, check `"name"` is your Worker's name in Cloudflare (`vibeistic-astro`).
5. Add to `.gitignore`:
   ```
   .dev.vars
   .wrangler/
   ```

## 2. Update Wrangler and create the database (Terminal)

```bash
cd ~/Desktop/Projects/vibeistic-astro
npm install -D wrangler@latest
npx wrangler login                       # opens the browser – allow access
npx wrangler d1 create vibe-tribe
```
Copy the `database_id` it prints into `wrangler.jsonc` (replace `PASTE-YOUR-D1-DATABASE-ID-HERE`). Then create the tables:
```bash
npx wrangler d1 migrations apply vibe-tribe --remote
```

## 3. Secrets

```bash
openssl rand -base64 24      # run twice – one value for each secret below
npx wrangler secret put ADMIN_SETUP_KEY     # one-time key to create your admin account
npx wrangler secret put DATA_KEY            # encrypts UPI / bank details – NEVER lose or change it while payouts are open
```
Save both values in the Mac **Passwords** app.

Optional (can be added later):

| Secret | Purpose |
|---|---|
| `GITHUB_TOKEN` | Fine-grained token, **only** your website repo, **Contents: Read and write** – enables “Publish to website” |
| `GITHUB_REPO` | e.g. `vibeistic-admin/vibeistic-astro` |
| `GITHUB_BRANCH` | `main` |
| `BREVO_API_KEY` | Free Brevo account → SMTP & API → API key – enables password-reset and status emails |
| `MAIL_FROM` | `hello@vibeistic.in` (verify it as a sender in Brevo) |
| `ADMIN_EMAIL` | where new-submission / payout alerts go, e.g. `admin@vibeistic.in` |

Without Brevo, contributors who forget a password email you, and you create a reset link in **Admin → Contributors → Create password reset link**.

## 4. Test on your Mac first

```bash
npx wrangler d1 migrations apply vibe-tribe --local
printf 'ADMIN_SETUP_KEY=test-setup-key\nDATA_KEY=local-test-data-key\n' > .dev.vars
npm run build
npx wrangler dev
```
Open **http://localhost:8787/tribe-admin/** (not 4321 – `npm run dev` does not run the API).

## 5. Deploy

GitHub Desktop → Summary `Vibe Tribe portal` → **Commit to main → Push origin**. Wait for **Success** in Cloudflare → Workers & Pages → Deployments.

## 6. Create your admin account (once)

1. Open **https://vibeistic.in/tribe-admin/**.
2. Enter the `ADMIN_SETUP_KEY`, your name, an admin email (use **admin@vibeistic.in**, not your contributor email) and a 12+ character password.
3. Open your authenticator (Apple Passwords, Google or Microsoft Authenticator) → **Add → Enter setup key** → name `Vibeistic Admin`, paste the key shown, time-based. Save the key in Passwords as a backup.
4. Type the 6-digit code → **Enable**. From now on, admin login always asks for a code.

Setup locks itself after the first admin is created.

## 7. Test everything before going live

Copy the **preview link** from Admin → Overview and open it in a private window (or on your phone) to act as a visitor.

- [ ] Join Us page: all sections, reward text, levels table, links to Terms and Privacy
- [ ] Register a test contributor on the phone → Contributor ID shows (VT-0002 …)
- [ ] New review → pick pillar → type, close the tab mid-way, reopen → draft is still there
- [ ] Upload 2+ photos from iPhone and from the laptop; remove one
- [ ] Submit with a missing field → clear error list; submit properly → status “Under review” with Review ID
- [ ] Admin queue → **Request changes** → contributor sees the note → edit & resubmit
- [ ] Admin → **Approve** with 90 points + reel bonus → contributor sees points, ₹ and level progress
- [ ] Admin → Contributors → adjust points to cross ₹300 → **Request Reward Money** unlocks → submit UPI
- [ ] Admin → Payouts → Pay → **Mark as paid** with reference → contributor sees “Paid” + reference
- [ ] Publish (GitHub) or Download Markdown → page shows “Reader review by …”
- [ ] Reach a gift level (lower it temporarily in Settings) → contributor sees 🎁 message; Admin → Gifts shows it
- [ ] Settings: change points range / ₹ per point / minimum payout → Join Us page updates
- [ ] Logged-out visitor without the preview link still sees “Our team is working on it”
- [ ] Delete the test accounts' data: Admin → Contributors → Anonymise account

Then **Admin → Overview → Go live**.

## 8. Rewards (defaults – all editable in Admin → Rewards & settings)

| Setting | Default |
|---|---|
| Points per approved review | 80–100 (default 90) |
| Reel / Short bonus | 50 points |
| ₹ per point | 0.5 → 10 points = ₹5, so 80–100 points ≈ ₹40–50 |
| Minimum payout | ₹300 |
| Levels | 1 Explorer (0) · 2 Local Guide (5) 🎁 · 3 Vibe Curator (15) 🎁 · 4 Tribe Legend (30) |
| Minimum words / photos | 250 words · 2–8 photos |

Changing the rate affects balances shown from then on (points are the source of truth). Announce changes before applying them.

## 9. Security & compliance built in

- Passwords hashed (PBKDF2-SHA256), HttpOnly secure cookies, CSRF protection, login rate-limits.
- Admin requires 2-factor authentication; every admin action is in the audit log.
- 18+ confirmation and Terms consent at sign-up; five declarations + Terms consent (version-stamped) on every submission.
- Photos are resized in the browser and re-encoded, which removes GPS/location data; photos are private until published.
- UPI / bank details are AES-encrypted and erased automatically when a payout is paid or rejected.
- Points are awarded for approval, never for positive ratings; published pages say so and are labelled “Reader review”.
- Contributors can request account deletion; admins can anonymise accounts (DPDP Act 2023).
- Dashboard and admin pages are `noindex` and excluded from the sitemap and robots.

**Update your Privacy Policy** (Admin editor → Pages → Privacy Policy) – add under “Information we collect”:

> **Vibe Tribe contributors:** if you create a contributor account we collect your name, email, password (stored only as a secure hash), and optionally your phone, city, Instagram handle and delivery address. When you request reward money we collect your UPI ID or bank details, which are encrypted and deleted once the payment is completed. We use this information only to run the programme, credit you, pay rewards and send gifts. You can ask us to delete your account at any time.

**Talk to a CA** before regular payouts: rewards may need TDS and PAN collection depending on amounts. Keep the Payouts CSV for your records.

## 10. Free-plan limits (check Cloudflare's current pricing)

- Only `/api/*` and `/vibe-tribe/*` run the Worker; the rest of the site stays free static hosting.
- Workers Free allows ~100,000 Worker requests/day and short CPU time per request. Password checks and “Publish to website” are the heaviest operations. If you see “exceeded CPU” errors in Cloudflare logs, move to **Workers Paid (about US$5/month)**.
- Photos are stored in D1 by default (fine for a few hundred). For more, create an R2 bucket and uncomment the `r2_buckets` block in `wrangler.jsonc` (new photos then go to R2; old ones keep working).

## 11. Troubleshooting

| Problem | Fix |
|---|---|
| Build fails: `run_worker_first` | `npm install -D wrangler@latest`, commit `package.json` + lock file |
| `D1_ERROR: no such table` | Run `npx wrangler d1 migrations apply vibe-tribe --remote` |
| `/vibe-tribe/` shows the old page | Delete `src/pages/vibe-tribe.astro` |
| Admin setup says not enabled | `npx wrangler secret put ADMIN_SETUP_KEY`, then reload |
| 2FA code always wrong | Phone time must be automatic; re-add the key exactly |
| Lost the authenticator | `npx wrangler d1 execute vibe-tribe --remote --command "UPDATE users SET totp_enabled=0, totp_secret=NULL WHERE role='admin'"`, then log in and set it up again |
| Payout says “not switched on” | `DATA_KEY` secret is missing |
| iPhone photo won't upload in Chrome on Mac | HEIC – use Safari, or set iPhone Camera → Formats → Most Compatible |
