// @ts-check
import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

const PRIVATE = ['/admin', '/tribe-admin', '/vibe-tribe/dashboard', '/vibe-tribe-soon'];

export default defineConfig({
  site: 'https://vibeistic.in',
  output: 'static',
  integrations: [sitemap({ filter: (page) => !PRIVATE.some((p) => page.includes(p)) })],
});
