---
title: "Manbhavan Premium Thali Restaurant, Wakad, Pune"
pillar: eat
area: "Wakad, Pune"
seoTitle: "Manbhavan Thali Wakad: Price, Timings & Review"
seoDescription: "Manbhavan Premium Thali, Phoenix Mall of the Millennium, Wakad: unlimited Gujarati-Rajasthani thali, what's on the plate, timings, price for two and wait times."
quickAnswer: "Manbhavan Premium Thali is on the **3rd floor of Phoenix Mall of the Millennium, Wakad**. It serves an **unlimited, pure-veg Gujarati–Rajasthani thali** with **hot rotis and parathas served fresh at the table**. It is open for **lunch and dinner** (roughly 12–4 pm and 7–10:30 pm). Our bill for **two thalis was about ₹1,523**. Weekdays have **no waiting**; weekends are busier but the wait is short."
badge: "Unlimited veg thali"
price: "About ₹1,523 for two (our bill)"
verdict: "Tasty, generous unlimited thali with hot rotis and caring serving staff. Pricier than standalone thali places, and billing help at the counter could be friendlier."
extraInfo:
  - { icon: "🕒", label: "Lunch", value: "About 12 – 4 pm (from 11 am Fri–Sun)" }
  - { icon: "🌙", label: "Dinner", value: "About 7 – 10:30 pm" }
  - { icon: "🍛", label: "Format", value: "Unlimited thali, 100% vegetarian" }
  - { icon: "⏳", label: "Wait time", value: "None on weekdays; short on weekends" }
  - { icon: "🚗", label: "Parking", value: "Mall parking" }
  - { icon: "💳", label: "Payment", value: "Cards, UPI, District app" }
timings: ""
station: "Inside Phoenix Mall of the Millennium (3rd floor)"
bestFor: "Families, proper lunch or dinner, big appetites"
address: "T-50, 3rd Floor, Phoenix Mall of the Millennium, Wakad, Pune 411057"
score1: 8.5
score2: 7.0
score3: 8.0
image: "/uploads/manbhavan-thali-wakad-ambience.webp"
imageAlt: "Interior of Manbhavan Premium Thali in Wakad with a basket ceiling, chandeliers, carved arches and blue chairs"
gallery: []
galleryAfterParagraph: 0
faqs:
  - { question: "Where is Manbhavan Premium Thali in Wakad?", answer: "Unit T-50 on the 3rd floor of Phoenix Mall of the Millennium, Wakad, Pune." }
  - { question: "What are the Manbhavan Thali Wakad timings?", answer: "It serves lunch from about 12 pm to 4 pm (from 11 am on Friday to Sunday) and dinner from about 7 pm to 10:30 pm. Listings differ slightly, so check before you go." }
  - { question: "How much does the thali cost?", answer: "Our bill for two unlimited thalis on a Tuesday was about ₹1,523. Prices can change and may differ on weekends, so check the current price at the counter." }
  - { question: "Is the thali unlimited?", answer: "Yes. Staff keep refilling the dishes, and rotis and parathas come hot to your table on request." }
  - { question: "Is it pure vegetarian?", answer: "Yes, it serves a 100% vegetarian Gujarati–Marwari thali." }
  - { question: "Is there a waiting time?", answer: "On weekdays we were seated straight away. Weekends are busier in the mall, but the wait at the restaurant is usually short except on festivals and holidays." }
published: 2026-11-05
sample: false
draft: true
---

If you are in Wakad and want a **proper, sit-down lunch or dinner** rather than mall fast food, Manbhavan Premium Thali is the place I would point you to. I went on a **Tuesday**, and it turned into a relaxed, filling meal.

## My experience

The restaurant is on the third floor of Phoenix Mall of the Millennium, and the space itself makes a good first impression. Look up and the **ceiling is covered in woven baskets and greenery**, with chandeliers hanging between them. The walls have carved Rajasthani-style arches with paintings, and the comfortable blue chairs are spaced well, so you never feel squeezed.

I chose a **front seat with a view of the mall**, which made the meal feel quite relaxed — good food on one side and the mall buzz on the other.

The **serving staff were the highlight**. They kept coming back to the table and adding more to the thali, the way our mothers do at home. The **rotis and parathas were brought hot**, straight to the plate, so you are always eating fresh food and can simply ask for more.

![The full Manbhavan thali with sabzis, dal, kadhi, sweets, farsan, paratha and rotis](/uploads/manbhavan-thali-wakad-thali.webp)

## Taste and food quality

The taste was **good across the board**, and there is a **lot of variety** on one plate — sabzis, dal, kadhi, two sweets, farsan, chutneys and breads. Everything tasted fresh, and the quality felt consistent from the first dish to the last refill. This is a meal for when you are properly hungry; you will leave full.

## What's on the thali

![Labelled Manbhavan thali showing 18 items: sabzis, dal, kadhi, sweets, farsan, breads, chutneys and salad](/uploads/manbhavan-thali-wakad-thali-items.webp)

On my visit the thali had:

- **Sabzis:** bhindi masala, mixed veg sabzi, a paneer/gravy sabzi and a seasonal sabzi
- **Dal and kadhi**
- **Sweets:** jalebi with rabdi, halwa, churma and a sweet bowl (aamras/shrikhand)
- **Farsan:** dhokla and kachori
- **Breads:** stuffed paratha and phulka rotis (refilled hot)
- **Sides:** fried papad/khichiya, onion-cucumber salad, green and red chutney, pickle

The menu changes with the day and season, so your plate may differ a little.

## Price and value

Our bill for **two thalis came to about ₹1,523**. I paid through the **District app** and got **₹137 cashback**, which helped. Because it is inside a premium mall, it is **a bit more expensive than standalone thali restaurants**. For the variety, taste and unlimited refills, I still felt it was fair — just don't expect a budget meal. Check the dining offers on District, Zomato or Swiggy before you pay; they can bring the price down.

## Service at the counter

One thing did not go well. I had a small issue while paying through the app and asked the person at the counter for help. He said it was my problem and did not help, which did not feel very welcoming, especially at the end of a good meal. It was a contrast with the table staff, who were warm and attentive throughout. If you plan to pay through an app, keep a backup payment option handy.

## Timings

| Meal | Time |
|---|---|
| Lunch (Mon–Thu) | About 12:00 pm – 4:00 pm |
| Lunch (Fri–Sun) | About 11:00 am – 4:00 pm |
| Dinner | About 7:00 pm – 10:30 pm |

Timings are from the restaurant's website; delivery apps list dinner until 11 pm. Confirm before a late visit.

## Crowd and waiting time

- **Weekdays:** calm — we were seated straight away with no wait.
- **Weekends:** the mall gets crowded, but the restaurant usually has little or no waiting time.
- **Festivals and holidays:** expect a wait; booking ahead is a good idea.

## Who it suits

- **Families** who want a full, traditional meal in comfortable seating
- **Big appetites** — the unlimited format and hot breads are the main attraction
- **Shoppers** looking for a proper lunch or dinner instead of fast food

## Our verdict

Manbhavan Premium Thali gets the important things right: **tasty, varied food, hot rotis at the table and staff who keep your plate full**. It costs more than a standalone thali place because of the mall location, and the help at the billing counter could be friendlier. For a relaxed, filling lunch or dinner in Wakad — especially on a weekday — I'd happily go back.
