---
title: "Privacy Policy"
description: "How Vibeistic collects, uses and protects information, including cookies, advertising, analytics and embedded content."
noAds: true
---

**Last updated:** 5 November 2026

This Privacy Policy explains how Vibeistic ("we", "us", "our") handles information when you visit **vibeistic.in** (the "Site"). By using the Site, you agree to this policy.

## 1. Information we collect

**You don't need an account to use Vibeistic.** We collect very little information:

- **When you email us:** your email address, name (if you include it) and the content of your message.
- **Basic visit information:** like most websites, our hosting and analytics providers process technical data such as your IP address, browser type, device type, pages visited and time of visit. We use this only in summarised form to understand how the Site is used.
- **Cookies and similar technologies** used by third-party services described below.

We do not knowingly collect sensitive personal information.

## 2. How we use information

We use information to:

- reply to your messages and suggestions
- correct and improve our reviews
- understand which pages are useful and keep the Site working and secure
- show advertising that helps keep the Site free (see section 4)

We do **not** sell your personal information.

## 3. Hosting and analytics

The Site is hosted on **Cloudflare**, which processes technical data (such as IP addresses) to deliver pages securely and protect against abuse. We may use **Cloudflare Web Analytics**, which provides summarised visitor statistics and does not use cookies to track you across websites.

## 4. Advertising and cookies

We may show ads served by **Google AdSense**. Google and its partners use cookies to serve ads based on your previous visits to this and other websites. Google's use of advertising cookies enables it and its partners to serve ads to you based on your visits to our Site and/or other sites on the internet.

- You can opt out of personalised advertising in **Google's Ads Settings** (adssettings.google.com).
- You can learn how Google uses information at **policies.google.com/technologies/partner-sites**.
- Other third-party vendors may also use cookies; you can opt out of some of them at **www.aboutads.info**.

Visitors from regions that require consent (such as the EU or UK) will be shown a consent message before personalised ads are used.

You can block or delete cookies in your browser settings. Some features may not work as intended if you do.

## 5. Embedded content

Review pages may include **Google Maps** and **YouTube** videos. These services may collect data and set cookies when you view or interact with them, under their own privacy policies.

## 6. Links to other websites

Our reviews may link to other websites (for example, official temple or restaurant sites). We are not responsible for their content or privacy practices.

## 7. How long we keep information

We keep emails only as long as needed to respond and for our records, and then delete them. Summarised analytics data does not identify you personally.

## 8. Your rights

Under applicable law, including India's **Digital Personal Data Protection Act, 2023**, you may ask us to access, correct or delete personal information you have shared with us (such as your emails). Email us and we will respond within a reasonable time.

## 9. Children

The Site is intended for a general audience and is not directed at children under 18. We do not knowingly collect personal information from children.

## 10. Changes to this policy

We may update this policy from time to time. The "Last updated" date at the top shows the latest version.

## 11. Contact

For any privacy questions or requests, email **[hello@vibeistic.in](mailto:hello@vibeistic.in)**.
