---
title: "How We Rate"
description: "How Vibeistic scores places: three factors per pillar, scored out of 10 after an in-person visit, with no paid ratings."
noAds: false
---

Every score on Vibeistic comes from **a real visit, paid for by us**. This page explains how we score places so you can compare them fairly.

## Our promise

- **We visit every place in person** before writing about it.
- **We pay our own bills.** No free meals, stays or entry in exchange for a review or a higher score.
- **Scores are never for sale.** Businesses cannot pay to change a score or remove a review.
- **Sponsored content is always labelled.** If we ever publish a sponsored post or use affiliate links, we will say so clearly at the top of the page.
- **We use our own photos**, unless clearly stated otherwise.

## The three scores

Different places matter for different reasons, so each pillar has its own three factors. Each factor is scored **out of 10**, and the **overall score is the average** of the three.

| Pillar | Factor 1 | Factor 2 | Factor 3 |
|---|---|---|---|
| 🍛 Eat | Taste | Value | Hygiene |
| ☕ Sip | Brew | Vibe | Value |
| 🧭 Travel | Experience | Access | Value |
| 🛕 Pray | Darshan | Cleanliness | Calm |
| ⚽ Play | Facilities | Crowd | Value |
| 🏨 Stay | Room | Location | Value |

## What the numbers mean

| Score | Meaning |
|---|---|
| **9 – 10** | Outstanding. Worth a special trip. |
| **7.5 – 8.9** | Very good. We'd happily go back and recommend it. |
| **6 – 7.4** | Good, with some drawbacks worth knowing. |
| **4 – 5.9** | Average. Only if it's convenient. |
| **Below 4** | Poor. We'd suggest looking elsewhere. |

## What we check on every visit

- **Practical details:** timings, prices, parking, waiting time and how to get there
- **Cleanliness:** dining areas, washrooms and general upkeep
- **Crowd:** how busy it is on weekdays, weekends and festivals
- **Service:** how staff treat visitors, both the good and the not-so-good
- **Who it suits:** families, couples, seniors, solo visitors or groups

## Keeping reviews up to date

Places change. We revisit our top places when we can and update timings, prices and scores. The **"Updated"** date on each review shows when it was last checked. Prices and timings can still change between visits, so please confirm before you go.

## Spotted something wrong?

If a review has outdated or incorrect information, email us at [hello@vibeistic.in](mailto:hello@vibeistic.in) and we'll check and correct it.
