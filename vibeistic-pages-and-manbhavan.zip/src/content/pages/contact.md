---
title: "Contact Vibeistic"
description: "Contact Vibeistic: suggest a place, report a change, or get in touch about collaborations. Email hello@vibeistic.in."
noAds: true
---

We'd love to hear from you. Whether you want to suggest a place, tell us that timings or prices have changed, or simply share your own experience, get in touch.

## Email

**[hello@vibeistic.in](mailto:hello@vibeistic.in)**

We read every message and usually reply within 2–3 working days.

## Follow us

- **Instagram:** [@_vibeistic](https://instagram.com/_vibeistic) — reels, stories and new places first
- **YouTube:** [@vibeistic](https://youtube.com/@vibeistic) — short videos from our visits

## What to write to us about

| Topic | What to include |
|---|---|
| **Suggest a place** | Name, area/city and why you love it |
| **Report a change** | The review link and what has changed (timings, prices, closed, moved) |
| **Correction** | The review link and the correct information |
| **Collaborations** | Who you are and what you have in mind |

## For businesses

We're happy to hear from restaurants, cafés, temples, hotels, gyms and venues. Please note:

- **We don't accept payment, free meals or free services in exchange for a review or a score.**
- We visit places independently and decide ourselves what to review.
- Any sponsored content or partnership will always be clearly labelled on the site.

If you believe a review contains a factual error about your business, email us with the details and we'll review it promptly.
