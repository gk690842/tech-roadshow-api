VIBEISTIC – Pages + Manbhavan review

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy into your project (replace when asked):
     src/content/pages/about.md, how-we-rate.md, contact.md, privacy-policy.md, disclaimer.md
     src/content/reviews/manbhavan-premium-thali-wakad-pune.md   (saved as draft: true)
     public/uploads/manbhavan-thali-wakad-*.webp   (4 photos)
3. src/config.ts → set   instagram: 'https://instagram.com/_vibeistic',
                         youtube: 'https://youtube.com/@vibeistic',
                         contactEmail: 'hello@vibeistic.in',
4. Terminal: npm run build  (must end with "Complete!")
5. Commit → Push origin. When ready, untick Draft on the review in /admin.
6. Search Console → URL inspection → request indexing for the new review.
