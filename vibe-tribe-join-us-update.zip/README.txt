VIBE TRIBE – Join Us page (updated)

1. Copy into vibeistic-astro (replace):
     src/pages/vibe-tribe/index.astro
     public/brand/vibe-tribe-banner.webp   (new)
2. npm run build → npx wrangler dev → http://localhost:8787/vibe-tribe/
3. Commit "Update Join Us page" → Push origin. The page stays hidden until Admin → Overview → Go live.

Apply the new rewards in Admin → Rewards & settings (no code change needed):
   ₹ value of 1 point = 0.5      (2 points = ₹1)
   Levels:
     1 Explorer      0    (no gift)
     2 Local Guide   25   (no gift)
     3 Vibe Curator  50   (no gift)
     4 Tribe Star    75   🎁 gift ticked
     5 Tribe Legend  100  🎁 gift ticked
   → Save settings. The Join Us page, earnings table, calculator and dashboard update automatically.

Optional text updates:
   src/pages/vibe-tribe/terms.astro  → change "for example, 10 points = ₹5" to "for example, 2 points = ₹1"
