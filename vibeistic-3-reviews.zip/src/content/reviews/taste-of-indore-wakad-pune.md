---
title: "Taste of Indore, Wakad, Pune"
pillar: eat
area: "Wakad, Pune"
seoTitle: "Taste of Indore Wakad: Poha, Kachori & Prices"
seoDescription: "Taste of Indore, Wakad: authentic Indori poha, kachori, samosa and ghee jalebi for about ₹300 for two. Timings, parking, weekend queue tips and what to order."
quickAnswer: "Taste of Indore near **Utkarsh Chowk on Datta Mandir Road, Wakad** is a busy breakfast and snacks spot serving **Indori poha, kachori, samosa, jalebi, gulab jamun and dhokla**. It opens early (about **7:30–8 am**) and closes around **10–10:30 pm**. We paid **about ₹300 for two**. Weekends are crowded, but the queue moves fast — our food arrived in about **10 minutes**. Bike parking is hit-or-miss; car parking is hard."
badge: "Breakfast & snacks"
price: "About ₹300 for two (our bill)"
verdict: "Authentic Indori poha, kachori and jalebi served hot and quick, even in the weekend rush. Great value for breakfast; parking is the only real hassle."
extraInfo:
  - { icon: "🕒", label: "Open", value: "About 7:30 am – 10:30 pm (confirm locally)" }
  - { icon: "🥞", label: "Best for", value: "Breakfast and evening snacks" }
  - { icon: "⏳", label: "Weekend wait", value: "About 3 min to order, 7 min for food" }
  - { icon: "🛵", label: "Bike parking", value: "Sometimes available, depends on crowd" }
  - { icon: "🚗", label: "Car parking", value: "Difficult – park nearby and walk" }
  - { icon: "🥡", label: "Takeaway", value: "Separate takeaway queue at the counter" }
timings: ""
station: "Main road near Utkarsh Chowk signal, Wakad"
bestFor: "Quick breakfast, snacks with friends, takeaway"
address: "Near Utkarsh Chowk, opposite Ozone Spring, Datta Mandir Road, Wakad, Pune 411057"
score1: 9.0
score2: 9.0
score3: 7.5
image: "/uploads/taste-of-indore-wakad-outlet.webp"
imageAlt: "Taste of Indore outlet on Datta Mandir Road, Wakad, with the order counter"
gallery:
  - { image: "/uploads/taste-of-indore-wakad-poha-jalebi.webp", caption: "Indori poha and hot jalebi", alt: "Plate of Indori poha with sev and crispy jalebi at Taste of Indore Wakad" }
  - { image: "/uploads/taste-of-indore-wakad-kachori-samosa.webp", caption: "Kachori and samosa with chutneys", alt: "Kachori and samosa with green and red chutney at Taste of Indore Wakad" }
galleryAfterParagraph: 4
faqs:
  - { question: "What are Taste of Indore Wakad timings?", answer: "It opens early for breakfast, around 7:30–8 am, and closes around 10–10:30 pm. Listings differ slightly, so confirm before an early or late visit." }
  - { question: "How much does it cost?", answer: "We spent about ₹300 for two people on poha, jalebi, kachori, samosa and gulab jamun." }
  - { question: "What should I order?", answer: "Indori poha with sev, dal kachori, samosa and hot jalebi. Finish with gulab jamun." }
  - { question: "Is it crowded?", answer: "Weekends are very busy, especially in the morning, but the counter moves quickly. Weekdays are calmer." }
  - { question: "Is parking available?", answer: "Bike parking is sometimes available depending on the crowd. Car parking is difficult on the main road, so park nearby and walk." }
  - { question: "Is takeaway available?", answer: "Yes. The ticket counter has separate lines for takeaway and dine-in." }
published: 2026-11-06
sample: false
draft: true
---

If you've ever had breakfast in Indore, you know poha and jalebi are a way of life. Taste of Indore in Wakad brings that same morning ritual to Pune — and judging by the weekend crowd, plenty of people already know it.

## My experience

We went on a **weekend**, and the place was **packed**. There was a queue at the ticket counter and another for collecting food. At the counter there are **two lines — one for takeaway and one for dine-in** — which keeps things moving.

The counter person was clearly experienced. Despite the crowd, **we were in line for only about 3 minutes** before placing our order. Collecting the food took a little longer because of the rush, but **our order arrived in about 7 minutes**.

And it was **served hot**. One bite of the poha and we knew every second of waiting was worth it.

## What to order

The menu is all about **Indori breakfast and snacks**:

- **Indori poha** — soft, lightly spiced and topped with sev
- **Kachori** — crisp outside, flavourful filling, with chutneys
- **Samosa** — hot and generously stuffed
- **Jalebi** — crispy and sweet; the outlet advertises it as made in pure ghee
- **Gulab jamun** — a soft, sweet finish
- **Dhokla** — light and spongy, if you want something less fried

The name says Taste of Indore, and it genuinely **tasted like Indore**.

## Price

| What we ordered (2 people) | Cost |
|---|---|
| Poha, jalebi, kachori, samosa, gulab jamun | About ₹300 total |

For a filling breakfast for two, that's excellent value.

## Crowd and best time to go

- **Weekends:** completely full, especially in the morning. Expect a queue, but it moves fast.
- **Weekdays:** noticeably calmer — the easiest time to sit and eat.
- **Tip:** if you're in a hurry, use the **takeaway line** and eat at home.

## Timings

| Day | Time |
|---|---|
| All days | About 7:30 am – 10:30 pm |

Online listings vary between 7:30–8 am for opening and 10–10:30 pm for closing. Confirm locally before a very early or late visit.

## Parking and getting there

The outlet is on the **main road near the Utkarsh Chowk traffic signal**, so it's easy to find.

- **Bikes:** sometimes you'll find a spot right outside, sometimes not — it depends on the crowd.
- **Cars:** parking is **difficult**. Park on a nearby side street and walk over.

## Who it suits

- **Breakfast lovers** looking for something different from idli-dosa
- **Friends and families** grabbing a quick snack
- **People from Madhya Pradesh** missing a taste of home

## Our verdict

Taste of Indore delivers exactly what it promises: **authentic, hot Indori snacks at a fair price**. The weekend rush and parking are the only real drawbacks, but the experienced counter staff keep the wait short. If you're nearby, make it your breakfast stop. For a full meal in Wakad, see our [Naivedya Thali review](/review/naivedya-thali-wakad-pune/).
