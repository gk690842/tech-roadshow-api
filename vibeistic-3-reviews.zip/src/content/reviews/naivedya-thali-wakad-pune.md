---
title: "Naivedya Thali, Wakad, Pune"
pillar: eat
area: "Wakad, Pune"
seoTitle: "Naivedya Thali Wakad: Price, Menu & Review"
seoDescription: "Naivedya Thali, Wakad: unlimited veg thali at about ₹450 per person, free underground parking, hot breads, chukandar poori and dahi chaat. Timings and tips."
quickAnswer: "Naivedya Thali in the Stellar Complex on Laxmi Chowk Road, Wakad serves an **unlimited vegetarian Maharashtrian–Gujarati–Rajasthani thali**. Our dinner for two cost **about ₹900 (₹450 per person)**, parking is **free and underground** for bikes and cars, and it is open for **lunch (about 11:30 am–3:30 pm) and dinner (about 7–10:30 pm)**. Don't miss the **chukandar poori and dahi chaat**."
badge: "Value for money"
price: "About ₹900 for two (our bill)"
verdict: "Warm welcome, colourful unlimited thali served hot, standout chukandar poori and dahi chaat, and free parking. Excellent value at around ₹450 a head."
extraInfo:
  - { icon: "🕒", label: "Lunch", value: "About 11:30 am – 3:30 pm" }
  - { icon: "🌙", label: "Dinner", value: "About 7 – 10:30 pm" }
  - { icon: "🍛", label: "Format", value: "Unlimited thali, pure veg, menu changes daily" }
  - { icon: "🚗", label: "Parking", value: "Free underground, bikes & cars" }
  - { icon: "👨‍👩‍👧", label: "Kids", value: "Child thali listed on official site" }
  - { icon: "📞", label: "Phone", value: "+91 90490 20020" }
timings: ""
station: "On the main Laxmi Chowk Road, Wakad – easy by car, bike or auto"
bestFor: "Families, groups, big appetites on a budget"
address: "First Floor, A Wing, The Stellar Complex, Bhumkar Nagar, Laxmi Chowk Road, Wakad, Pune 411057"
score1: 8.8
score2: 9.0
score3: 8.5
image: "/uploads/naivedya-thali-wakad-dining-hall.webp"
imageAlt: "Dining hall at Naivedya Thali restaurant in Wakad, Pune"
gallery:
  - { image: "/uploads/naivedya-thali-wakad-full-thali.webp", caption: "The full unlimited thali", alt: "Naivedya unlimited veg thali with sabzis, dal, sweets and breads" }
  - { image: "/uploads/naivedya-thali-wakad-chukandar-poori.webp", caption: "Chukandar poori and dahi chaat – our favourites", alt: "Pink beetroot (chukandar) poori and dahi chaat at Naivedya Thali Wakad" }
galleryAfterParagraph: 4
faqs:
  - { question: "How much does Naivedya Thali Wakad cost?", answer: "Our dinner for two came to about ₹900, around ₹450 per person including taxes. The official website lists the adult thali at ₹400 and a child thali (ages 4–8) at ₹250, before taxes. Prices can change." }
  - { question: "What are Naivedya Thali Wakad timings?", answer: "Lunch is about 11:30 am to 3:30 pm and dinner about 7 pm to 10:30 pm. Check before a late visit." }
  - { question: "Is parking available?", answer: "Yes. There is free underground parking for both two-wheelers and four-wheelers." }
  - { question: "Is the thali unlimited?", answer: "Yes. Staff keep refilling every item, and breads are served hot to your table." }
  - { question: "Is it pure vegetarian?", answer: "Yes, it is a pure vegetarian thali restaurant serving Maharashtrian, Gujarati and Rajasthani dishes." }
  - { question: "What should I try?", answer: "The chukandar (beetroot) poori and the dahi chaat were our favourites. The menu changes daily, and the official website shows the day's menu." }
published: 2026-11-06
sample: false
draft: true
---

Looking for an unlimited thali in Wakad that doesn't burn a hole in your pocket? We went to Naivedya Thali for dinner and walked out with full stomachs and big smiles. At around **₹450 per person**, it is one of the best-value thalis we have had in the area.

## My experience

Getting there was easy. The restaurant is on the **main Laxmi Chowk Road**, and the **underground parking is free** for both bikes and cars, which is a relief in Wakad.

The welcome set the tone. Staff **greeted us at the entrance** and seated us right away. The hall is **spacious**, with room for a good number of guests, so even on a busy evening it doesn't feel cramped.

Within minutes they started setting up the thali, filling the bowls **one by one**. What stood out was how **colourful and fresh** everything looked, and how smoothly the serving went. They paid the same attention to every table, wherever you were sitting.

The **breads came hot**, straight to the plate, and refills kept coming without us having to ask twice. The service felt well trained and genuinely friendly.

## What we loved most

Two things stood out on our plate:

- **Chukandar (beetroot) poori** — bright pink, soft and slightly sweet. Something you don't find in most thalis.
- **Dahi chaat** — cool, tangy and the perfect break between the spicier sabzis.

The menu at Naivedya **changes every day**, with a rotating mix of sweets, farsan, sabzis, dal, kadhi, rotis, rice and khichdi, plus buttermilk, pickle and chutneys. The official website publishes the daily menu, so you can check what's on before you go.

## Price and value

| What | Price |
|---|---|
| Our bill (2 thalis, dinner) | About ₹900 (≈ ₹450 per person) |
| Adult thali (official website) | ₹400 + taxes |
| Child thali, ages 4–8 (official website) | ₹250 + taxes |

For the number of dishes, unlimited refills and hot breads, **₹450 a head is genuinely good value** — noticeably cheaper than mall-based thali restaurants in Wakad. If you want to compare, read our [Manbhavan Premium Thali review](/review/manbhavan-premium-thali-wakad-pune/).

## A lovely goodbye

As we were leaving, the staff thanked us again. We were trying to take a photo together, and **the owner himself came over and took it for us**. It's a small gesture, but it made the evening feel personal. We left smiling.

## Timings

| Meal | Time |
|---|---|
| Lunch | About 11:30 am – 3:30 pm |
| Dinner | About 7:00 pm – 10:30 pm |

Timings are from online listings; call **+91 90490 20020** to confirm before a late visit.

## Tips before you go

- **Go hungry** — it's unlimited, and the breads keep coming.
- **Ask for the chukandar poori** if it's on the day's menu.
- **Check the daily menu** on the official website if you have favourite dishes.
- **Bringing kids?** The website lists a separate, cheaper child thali for ages 4–8.

## Who it suits

- **Families and groups** — spacious seating and easy parking
- **Value seekers** — a full unlimited thali at a fair price
- **Anyone who loves home-style food** served hot and with care

## Our verdict

Naivedya Thali gets the important things right: a **warm welcome, colourful and fresh food, hot breads and staff who look after every table**. Add free parking and a price of around ₹450 per person, and it's an easy recommendation for dinner in Wakad. We'd happily go back for that chukandar poori.
