VIBEISTIC – 3 new reviews (Naivedya Thali, Taste of Indore, Cafe Buddy's Espresso)

1. GitHub Desktop → Fetch origin → Pull origin.
2. Copy src/content/reviews/*.md  →  vibeistic-astro/src/content/reviews/
   Copy public/uploads/*.webp      →  vibeistic-astro/public/uploads/
3. npm run build  (must end with "Complete!") → Commit → Push origin.
4. All three are draft: true. Preview with npm run dev (if you added the dev-draft change).

REPLACING THE PLACEHOLDER PHOTOS
Convert your photo to WebP (squoosh.app, ~1600px, under ~200 KB) and give it the SAME file name,
then overwrite the file in public/uploads/. No change to the review is needed.
  Main photos should be LANDSCAPE (they become the homepage card).
  Gallery photos look best in PORTRAIT.

  naivedya-thali-wakad-dining-hall.webp        main – dining hall / entrance
  naivedya-thali-wakad-full-thali.webp         gallery – full thali
  naivedya-thali-wakad-chukandar-poori.webp    gallery – chukandar poori & dahi chaat
  taste-of-indore-wakad-outlet.webp            main – outlet / counter
  taste-of-indore-wakad-poha-jalebi.webp       gallery – poha & jalebi
  taste-of-indore-wakad-kachori-samosa.webp    gallery – kachori & samosa
  cafe-buddys-espresso-nigdi-exterior.webp     main – café exterior / seating
  cafe-buddys-espresso-nigdi-pink-sauce-pasta.webp  gallery – pasta
  cafe-buddys-espresso-nigdi-affogato.webp     gallery – affogato & tiramisu shake
  cafe-buddys-espresso-nigdi-open-kitchen.webp gallery – open kitchen

Don't publish (untick Draft) until the real photos are in – placeholders look unprofessional.
